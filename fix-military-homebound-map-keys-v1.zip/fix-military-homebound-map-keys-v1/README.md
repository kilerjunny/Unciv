# 군수 시장 자동 귀환 기록 ClassCastException 수정 (mobile-dev)

## 원인

저장된 `GameInfo.militaryMarketReturnHomeUnits`는 JSON 객체입니다. JSON 객체 키는 문자열이지만 과거 Kotlin 코드는 이를 `HashMap<Int, String>`으로 선언하여, 저장 게임을 불러온 다음 턴의 `MilitaryMarket.reconcile`에서 `String cannot be cast to Integer`가 발생할 수 있었습니다.

## 변경

- `GameInfo.kt`: 필드 이름을 유지한 채 `HashMap<String,String>`으로 변경. 기존 저장 진행 상황과 귀환 기록 보존을 의도합니다.
- `MilitaryMarket.kt`: 새 군수 구매 유닛 ID를 문자열 키로 저장하며, 이미 저장된 키는 `toIntOrNull()`로 안전하게 검사하여 잘못된 키만 제거합니다.
- `MilitaryMarketReturnHome.kt`: 조회·삭제에 문자열 유닛 ID 사용. 기록이 없으면 즉시 반환합니다.
- 군수 계약 결제, 유닛 생성/소유권, 전쟁 AI, 해군 전략 배치 v2 규칙은 변경하지 않습니다.

## 적용

Codespaces의 `mobile-dev` 브랜치에 ZIP을 업로드한 후, 프로젝트 최상위 디렉터리에서:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o fix-military-homebound-map-keys-v1.zip -d /tmp
python3 /tmp/fix-military-homebound-map-keys-v1/apply_fix_military_homebound_map_keys_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

빌드 성공한 경우:

```bash
git add core/src/com/unciv/logic/GameInfo.kt core/src/com/unciv/logic/market/MilitaryMarket.kt core/src/com/unciv/logic/market/MilitaryMarketReturnHome.kt
git rm --ignore-unmatch fix-military-homebound-map-keys-v1.zip
git diff --cached --check
git commit -m "Fix military market return-home save key crash"
git push origin mobile-dev
```

그다음 GitHub Actions에서 새 APK를 빌드해 설치하세요. **중요: 기존 게임 저장파일을 먼저 별도 백업하세요.** 이번 패치는 저장파일을 직접 수정하지 않습니다. 실제 게임 로딩과 턴 진행 확인은 필요합니다.
