#!/usr/bin/env python3
"""Fix Android save reload ClassCastException in MilitaryMarket.reconcile.

Keep the serialized field name unchanged, store map keys as decimal strings,
and parse keys safely only when comparing against MapUnit.id.
No saved progress or completed contracts are deleted.
"""
from pathlib import Path
import subprocess
import sys

ROOT = Path.cwd()
FILES = {
    'core/src/com/unciv/logic/GameInfo.kt': [
        (
            '    // GS_MILITARY_MARKET_HOMEBOUND_V1: global unique unit ID -> buyer civ ID.\n'
            '    var militaryMarketReturnHomeUnits = HashMap<Int, String>()',
            '    // GS_MILITARY_MARKET_HOMEBOUND_KEY_FIX_V1: JSON object keys are strings.\n'
            '    // Keep this property name so existing saved games retain return orders.\n'
            '    var militaryMarketReturnHomeUnits = HashMap<String, String>()',
        ),
    ],
    'core/src/com/unciv/logic/market/MilitaryMarket.kt': [
        (
            '        if (buyer.isAI() && unit.isMilitary())\n'
            '            game.militaryMarketReturnHomeUnits[unit.id] = buyer.civID',
            '        if (buyer.isAI() && unit.isMilitary())\n'
            '            game.militaryMarketReturnHomeUnits[unit.id.toString()] = buyer.civID',
        ),
        (
            '        if (game.militaryMarketReturnHomeUnits.isNotEmpty())\n'
            '            game.militaryMarketReturnHomeUnits.entries.removeAll { (unitId, buyerId) ->\n'
            '                val buyer = game.getCivilizationOrNull(buyerId)\n'
            '                buyer == null || buyer.isDefeated() ||\n'
            '                    buyer.units.getCivUnits().none { it.id == unitId && !it.isDestroyed }\n'
            '            }',
            '        if (game.militaryMarketReturnHomeUnits.isNotEmpty())\n'
            '            game.militaryMarketReturnHomeUnits.entries.removeAll { (unitKey, buyerId) ->\n'
            '                // Existing saves deserialize JSON map keys as String, even if an\n'
            '                // earlier Kotlin declaration incorrectly expected Int keys.\n'
            '                val unitId = unitKey.toIntOrNull()\n'
            '                val buyer = game.getCivilizationOrNull(buyerId)\n'
            '                unitId == null || buyer == null || buyer.isDefeated() ||\n'
            '                    buyer.units.getCivUnits().none { it.id == unitId && !it.isDestroyed }\n'
            '            }',
        ),
    ],
    'core/src/com/unciv/logic/market/MilitaryMarketReturnHome.kt': [
        (
            '        val pending = civ.gameInfo.militaryMarketReturnHomeUnits\n'
            '        val assignedCiv = pending[unit.id] ?: return false',
            '        val pending = civ.gameInfo.militaryMarketReturnHomeUnits\n'
            '        if (pending.isEmpty()) return false\n'
            '        val unitKey = unit.id.toString()\n'
            '        val assignedCiv = pending[unitKey] ?: return false',
        ),
        (
            '        if (assignedCiv != civ.civID || unit.isDestroyed) {\n'
            '            pending.remove(unit.id)',
            '        if (assignedCiv != civ.civID || unit.isDestroyed) {\n'
            '            pending.remove(unitKey)',
        ),
        (
            '        if (unit.getTile().getOwner() == civ) {\n'
            '            pending.remove(unit.id)',
            '        if (unit.getTile().getOwner() == civ) {\n'
            '            pending.remove(unitKey)',
        ),
        (
            '            if (unit.getTile().getOwner() == civ) pending.remove(unit.id)',
            '            if (unit.getTile().getOwner() == civ) pending.remove(unitKey)',
        ),
    ],
}


def main() -> None:
    if not (ROOT / 'gradlew').is_file() or not (ROOT / 'core').is_dir():
        sys.exit('오류: Unciv 프로젝트 최상위 폴더에서 실행해 주세요.')
    branch = subprocess.run(['git', 'branch', '--show-current'], text=True, capture_output=True)
    if branch.returncode != 0 or branch.stdout.strip() != 'mobile-dev':
        sys.exit('오류: mobile-dev 브랜치에서만 적용할 수 있습니다.')

    patches = {}
    already = 0
    for filename, swaps in FILES.items():
        path = ROOT / filename
        if not path.is_file():
            sys.exit(f'오류: 파일을 찾을 수 없습니다: {filename}')
        original = path.read_text(encoding='utf-8')
        modified = original
        for old, new in swaps:
            matches = modified.count(old)
            if matches == 1:
                modified = modified.replace(old, new, 1)
            elif matches == 0 and modified.count(new) == 1:
                already += 1
            else:
                sys.exit(f'오류: 예상하지 못한 소스 버전/중복 패치: {filename} ({matches} matches)\n'
                         '파일을 변경하지 않았습니다. git status와 소스를 확인하세요.')
        patches[path] = (original, modified)

    # All source matches were verified before any file is written.
    changed = 0
    for path, (old, new) in patches.items():
        if old != new:
            path.write_text(new, encoding='utf-8')
            print(f'수정: {path.relative_to(ROOT)}')
            changed += 1
    if changed == 0:
        print('이미 적용된 패치입니다. 추가 변경 없음.')
    else:
        print(f'완료: {changed}개 Kotlin 파일 수정. 저장파일은 변경하지 않았습니다.')
        print('다음 단계: git diff --check && ./gradlew :android:assembleDebug --no-daemon')


if __name__ == '__main__':
    main()
