#!/usr/bin/env python3
"""Make already-known AI city-states visible in World Market and let them list one luxury.

Apply from the repository root: python3 /tmp/citystate-market-fix/apply_citystate_market_fix.py
No changes are made if any expected source anchor is missing.
"""
from pathlib import Path

ROOT = Path.cwd()
AUTO_PATH = ROOT / "core/src/com/unciv/logic/market/WorldMarketAutoSupply.kt"
UI_PATH = ROOT / "core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt"

OLD_RESERVE = """                resource.isStockpiled -> 10
                resource.resourceType == ResourceType.Luxury -> 1
                else -> 2"""
NEW_RESERVE = """                resource.isStockpiled -> 10
                // City-states may offer their one locally produced luxury.
                // Other nations still keep one luxury in reserve.
                seller.isCityState && resource.resourceType == ResourceType.Luxury -> 0
                resource.resourceType == ResourceType.Luxury -> 1
                else -> 2"""

OLD_GROUP = """        val visibleOrders = orders.take(500)
        val bySeller = visibleOrders.groupBy { it.sellerCivId }
        for ((sellerId, sellerOrders) in bySeller.toList().sortedBy { (id, _) ->
            gameInfo.civilizations.firstOrNull { it.civID == id }?.civName?.tr() ?: id
        }) {
            val seller = gameInfo.civilizations.firstOrNull { it.civID == sellerId } ?: continue"""
NEW_GROUP = """        val visibleOrders = orders.take(500)
        val bySeller = visibleOrders.groupBy { it.sellerCivId }
        // Display discovered city-states even with no sell order. This makes it
        // clear that no sellable surplus exists, rather than hiding the nation.
        // Keep the regular search/affordability/strategic filters unchanged.
        val emptyCityStateIds: List<String> = if (
            query.isEmpty() && !affordableOnly && !strategicOnly
        ) gameInfo.civilizations.asSequence()
            .filter { it.isCityState && it.isAI() && !it.isDefeated() }
            .filter { spectator || it.civName in known }
            .map { it.civID }
            .filter { !bySeller.containsKey(it) }
            .toList()
        else emptyList()

        val visibleSellerIds = (bySeller.keys + emptyCityStateIds)
            .distinct()
            .sortedBy { id ->
                gameInfo.civilizations.firstOrNull { it.civID == id }?.civName?.tr() ?: id
            }
        for (sellerId in visibleSellerIds) {
            val sellerOrders = bySeller[sellerId].orEmpty()
            val seller = gameInfo.civilizations.firstOrNull { it.civID == sellerId } ?: continue"""

OLD_EXPAND = """            add(sellerButton).left().growX().padTop(6f).row()
            if (!expanded) continue
            for (order in sellerOrders) {"""
NEW_EXPAND = """            add(sellerButton).left().growX().padTop(6f).row()
            if (!expanded) continue
            if (sellerOrders.isEmpty()) {
                add("현재 등록된 판매 자원이 없습니다 (자원 미확보·비축·거래 제한 가능).".toLabel())
                    .left().growX().row()
                continue
            }
            for (order in sellerOrders) {"""

changes = [
    (AUTO_PATH, [(OLD_RESERVE, NEW_RESERVE)]),
    (UI_PATH, [(OLD_GROUP, NEW_GROUP), (OLD_EXPAND, NEW_EXPAND)]),
]

# Verify all anchors before any file writes, so a mismatch cannot half-apply.
updates = []
for path, replacements in changes:
    if not path.exists():
        raise SystemExit(f"ERROR: missing {path}. Run from /workspaces/Unciv.")
    source = path.read_text(encoding="utf-8")
    output = source
    for old, new in replacements:
        if new in output:
            print(f"Already applied: {path.name}")
            continue
        if output.count(old) != 1:
            raise SystemExit(f"ERROR: expected unique source section not found: {path.name}")
        output = output.replace(old, new, 1)
    updates.append((path, source, output))

for path, old, new in updates:
    if new != old:
        path.write_text(new, encoding="utf-8")
        print(f"Patched: {path.relative_to(ROOT)}")
print("City-state market adjustment complete. Compile and test in game.")
