# City-state resource market fix (Unciv Grand Strategy)

Target: `kilerjunny/Unciv`, branch based on `feature/trade-route-recognition-v1`.

What changes:
- AI city-states can automatically register their **single tradable luxury** (reserve lowered from 1 to 0 **for city-states only**). AI major civilizations retain the previous reserve.
- Already-met city-states without sell orders are visible as `0종` sellers when default filters are enabled. Expand them to see an explanation; no resource is invented.
- Keeps existing resource availability checks, contracts, price, instant settlement, and route records unchanged.

What is *not* changed: trade rights, diplomatic contact requirements, global route logistics, military market, or stockpile rules.

Apply in Codespaces (workspace repository root):

```sh
unzip -o citystate-market-fix.zip -d /tmp
python3 /tmp/citystate-market-fix/apply_citystate_market_fix.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

Run a few turns, then inspect World Market with the text search empty and filter toggles off. If you have discovered a city-state with 1 tradable luxury, it should begin listing 1 unit after that city's AI turn; cities with no sellable stock will display `0종`. Test purchase, treasury, inventory, save/load, and city-state ally bonuses before considering the change final.

Caveats: A city's map resource might not be improved or tradable and its accessible tradable quantity might still be zero. One-luxury sales can also interact with alliance resource-sharing rules. Validate those cases in the running game; these rules have not been runtime-tested here.
