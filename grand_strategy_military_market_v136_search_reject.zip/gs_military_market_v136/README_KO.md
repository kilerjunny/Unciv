# Grand Strategy 군수 시장 v1.3.6 — 검색 · 주문 승인/거부

**기준**: `feature/military-market-v13` 브랜치에 v1.3.5 소스가 반영된 Unciv.
수정 대상: Kotlin 파일 2개. 기존 군수 시장·군수예산·도시국가 기능 보존.

## 기능

1. **상품 검색** — 군수 시장 하단의 `다른 국가의 판매 상품`에서 한글/영문 유닛명·판매국명·도시명을 입력하고 `검색` 클릭. `초기화`로 전체 보기. 검색시에만 최대 500개 후보를 조회하고 최대 100개 결과를 표시하여 일반 UI 성능 유지.
2. **주문 수락/거부** — AI가 플레이어에게 주문하면 `내가 납품할 계약`에 `판매국 승인 대기` 표시. **수락**하면 도시 생산 대기열에 등록. **거부**하면 전액 환불하고 판매 상품 재등록. 주문이 반복해서 들어오는 걸 줄이기 위해 동일 AI·유닛 거절 이후 12턴 동안 재주문 제한.
3. **기존 주문 호환** — 이미 `생산 중`, `인도 대기`인 계약 상태는 그대로 둠. AI 생산국에 플레이어가 발주하는 기존 절차는 자동 생산 시작.
4. **기존 인도 절차** — 완공 후 `인도하기` / `인도받기`, 실제 생산지에서 이동, 통행권 확인, 도시국가 참가와 국방예산 보호 유지.

## 설치

1. 이 ZIP을 GitHub `feature/military-market-v13` 브랜치에 **Upload files → Commit changes**로 업로드.
2. Codespaces에서 다음 실행:

```bash
git switch feature/military-market-v13
git pull --ff-only origin feature/military-market-v13
unzip -o grand_strategy_military_market_v136_search_reject.zip
python3 gs_military_market_v136/install.py --check
python3 gs_military_market_v136/install.py --apply
python3 gs_military_market_v136/install.py --verify
./gradlew :core:compileKotlin --no-daemon --console=plain
```

3. **BUILD SUCCESSFUL**이 나오면 다음 두 파일만 커밋:

```bash
git add core/src/com/unciv/logic/market/MilitaryMarket.kt core/src/com/unciv/ui/screens/overviewscreen/MilitaryMarketSection.kt
git commit -m "Add military market search and seller order approval"
git push origin feature/military-market-v13
```

## 주의

- 주문 거부는 **새로 접수된 `판매국 승인 대기` 상태**에서만 가능. 이전 버전의 이미 생산 중인 주문을 소급 거절하지 않음.
- AI 주문 시 대금이 선예치되므로 거절할 때는 구매자에게 환불됨. 결제/전달/생산이 두 번 일어나지 않도록 상태 전이를 검사함.
- 설치 스크립트는 현재 원본 파일 내용이 일치하지 않으면 변경 없이 멈춤. 두 파일은 `../GS_military_backup/`에 저장됨.
- 실제 Kotlin 컴파일 및 Android APK 실게임 작동은 사용자의 Codespaces에서 확인해야 함.
