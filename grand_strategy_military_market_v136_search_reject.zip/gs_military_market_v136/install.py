#!/usr/bin/env python3
"""Military market v1.3.6: catalogue search and human seller approval/refusal.

The patch applies to the verified v1.3.5 branch source only and never touches
unrelated repository files.  It is safe to re-run.  No Gradle invocation.
"""
import argparse
import datetime
import hashlib
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BRANCH = "feature/military-market-v13"
FILES = {
    "market": "core/src/com/unciv/logic/market/MilitaryMarket.kt",
    "ui": "core/src/com/unciv/ui/screens/overviewscreen/MilitaryMarketSection.kt",
}


def git(*args):
    return subprocess.run(["git", *args], cwd=ROOT, capture_output=True, text=True)


def fingerprint(data):
    return hashlib.sha256(data).hexdigest()[:12]


def validate_repo():
    top = git("rev-parse", "--show-toplevel")
    if top.returncode or Path(top.stdout.strip()).resolve() != ROOT.resolve():
        raise RuntimeError("Extract and run the patch inside the Unciv repository root")
    branch = git("branch", "--show-current")
    if branch.returncode or branch.stdout.strip() != BRANCH:
        raise RuntimeError("Wrong branch. Expected " + BRANCH)


def run(mode):
    validate_repo()
    before = {k: (HERE / "reference" / FILES[k]).read_bytes() for k in FILES}
    after = {k: (HERE / "src" / FILES[k]).read_bytes() for k in FILES}
    current = {k: (ROOT / FILES[k]).read_bytes() for k in FILES}

    if mode == "verify":
        bad = [FILES[k] for k in FILES if current[k] != after[k]]
        if bad:
            raise RuntimeError("VERIFY FAILED: " + ", ".join(bad))
        print("VERIFY OK: search UI and seller acceptance/refusal sources match")
        return

    needs = []
    for k in FILES:
        if current[k] == after[k]:
            continue
        if current[k] == before[k]:
            needs.append(k)
            continue
        raise RuntimeError(
            "Unexpected source modification, no changes made: " + FILES[k] +
            " (sha256=" + fingerprint(current[k]) + ")"
        )

    if mode == "check":
        if not needs:
            print("CHECK OK: patch already applied; run --verify")
        else:
            print("CHECK OK: v1.3.5 sources recognized, " + str(len(needs)) + " file(s) to update")
        return
    if not needs:
        print("APPLY OK: already applied")
        return

    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
    backup = ROOT.parent / "GS_military_backup" / ("v136_" + stamp)
    for k in needs:
        dest = backup / FILES[k]
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(current[k])
    try:
        for k in needs:
            (ROOT / FILES[k]).write_bytes(after[k])
        for k in FILES:
            if (ROOT / FILES[k]).read_bytes() != after[k]:
                raise RuntimeError("Post-write verification failed: " + FILES[k])
    except BaseException:
        for k in needs:
            (ROOT / FILES[k]).write_bytes(current[k])
        raise
    print("APPLY OK: " + str(len(needs)) + " Kotlin files updated; backups: " + str(backup))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    for name in ("check", "apply", "verify"):
        group.add_argument("--" + name, action="store_true")
    args = parser.parse_args()
    try:
        run("check" if args.check else "apply" if args.apply else "verify")
    except (RuntimeError, OSError, ValueError) as exc:
        print("PATCH ERROR: " + str(exc), file=sys.stderr)
        raise SystemExit(1)
