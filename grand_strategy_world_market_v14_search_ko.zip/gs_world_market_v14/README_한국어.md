# 세계 자원 무역 시장 v1.4 UI 개선

기준: `kilerjunny/Unciv`의 2026-10-29 `feature/military-market-v13` 최신 코드 (`WorldMarketTradeSection.kt`). **군수 시장은 수정하지 않습니다.**

변경:
- 자원명·판매국명으로 검색 (한국어/영어)
- 안드로이드에서는 기본 한글 조합을 처리하는 시스템 입력창 사용
- PC에서는 기존 텍스트 입력 유지
- 자원명/가격순 정렬, 구매 가능 금액만 보기, 전략자원만 보기
- 목록에 번역된 자원명·국가명, 비축/턴 공급 표시
- 거래 기록 번역 표시
- 성능 보호: 최대 100건 표시. 더 구체적인 검색 가능

**바뀌지 않는 것:** 실제 거래 엔진, AI 자동 거래, 가격 정책, 세이브 형식, 도시국가 거래, 군수 시장. 안전한 UI 1차 패치입니다.

## 설치

기존 안정 브랜치 `feature/military-market-v13`에서 새 브랜치 `feature/world-market-v14`를 생성하고 그 브랜치에 ZIP을 업로드하고 커밋한 다음 Codespaces에서:

```bash
git pull --ff-only origin feature/world-market-v14
unzip -o grand_strategy_world_market_v14_search_ko.zip
python3 gs_world_market_v14/install.py --check
python3 gs_world_market_v14/install.py --apply
python3 gs_world_market_v14/install.py --verify
./gradlew :core:compileKotlin --no-daemon --console=plain
```

컴파일이 성공하면:

```bash
git add core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git diff --cached --stat
git commit -m "Improve world resource market search and Korean UI"
git push origin feature/world-market-v14
```

APK의 새 `거래 → 세계 시장` 화면에서 자원명 검색, 전략자원 필터, 가격 정렬을 확인하세요.

실제 Kotlin 빌드와 APK 기기 테스트는 사용자의 Codespaces에서 수행해야 합니다. `BUILD SUCCESSFUL` 전에는 커밋하지 마세요.
