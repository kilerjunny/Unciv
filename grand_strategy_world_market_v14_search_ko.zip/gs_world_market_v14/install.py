#!/usr/bin/env python3
"""Grand Strategy world resource market v1.4: UI search/filter/localization.
No changes to trading, prices, contracts, AI or save schema.

Usage: python3 gs_world_market_v14/install.py --check|--apply|--verify
"""
from __future__ import annotations
import argparse
from pathlib import Path
import os
import sys
import tempfile

TARGET = Path('core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt')
MARKER = '// GS_WORLD_MARKET_V14_SEARCH'


def replace_once(src: str, old: str, new: str, context: str) -> str:
    n = src.count(old)
    if n != 1:
        raise RuntimeError(f'{context}: expected 1 occurrence, got {n}. No changes made.')
    return src.replace(old, new, 1)


def transform(original: str) -> str:
    if MARKER in original:
        raise RuntimeError('v1.4 is already installed. No changes made.')
    s = original
    s = replace_once(s,
        'import com.badlogic.gdx.scenes.scene2d.ui.Table\n',
        'import com.badlogic.gdx.Application\n'
        'import com.badlogic.gdx.Gdx\n'
        'import com.badlogic.gdx.Input\n'
        'import com.badlogic.gdx.scenes.scene2d.ui.TextField\n'
        'import com.badlogic.gdx.scenes.scene2d.ui.Table\n',
        'Android keyboard imports')
    s = replace_once(s,
        'import com.unciv.logic.market.WorldMarketHistory\n',
        'import com.unciv.logic.market.WorldMarketHistory\n'
        'import com.unciv.models.ruleset.tile.ResourceType\n'
        'import com.unciv.models.translations.tr\n',
        'Resource type/translation imports')
    s = replace_once(s,
        '    private var militaryMarketOpen = false\n    private var message = ""\n',
        '    private var militaryMarketOpen = false\n'
        '    private var message = ""\n'
        '    // GS_WORLD_MARKET_V14_SEARCH\n'
        '    private var resourceSearch = ""\n'
        '    private var priceSort = false\n'
        '    private var affordableOnly = false\n'
        '    private var strategicOnly = false\n',
        'Search/filter state')
    s = replace_once(s,
        '                val seller = game.getCivilizationOrNull(it.sellerCivId)?.civName ?: "알 수 없음"\n'
        '                val buyer = game.getCivilizationOrNull(it.buyerCivId)?.civName ?: "알 수 없음"\n'
        '                add("턴 ${it.turn}: ${seller} → ${buyer}".toLabel(hideIcons = true)).left().row()\n'
        '                add("${it.resourceName} ${it.quantity}개 · ${it.totalGold}G".toLabel(hideIcons = true)).left().row()\n',
        '                val seller = game.getCivilizationOrNull(it.sellerCivId)?.civName?.tr() ?: "알 수 없음"\n'
        '                val buyer = game.getCivilizationOrNull(it.buyerCivId)?.civName?.tr() ?: "알 수 없음"\n'
        '                add("턴 ${it.turn}: ${seller} → ${buyer}".toLabel(hideIcons = true)).left().row()\n'
        '                add("${it.resourceName.tr()} ${it.quantity}개 · ${it.totalGold}G".toLabel(hideIcons = true)).left().row()\n',
        'Trade history localization')

    old = '''        val known = buyer.getKnownCivs()
            .map { it.civName }.toSet()


        val orders = gameInfo.worldMarketOrders
'''
    new = '''        val known = buyer.getKnownCivs()
            .map { it.civName }.toSet()

        // Native Android text input supports Korean IME composition.
        // The desktop path retains an inline text field.
        val searchBar = Table(BaseScreen.skin)
        if (Gdx.app.type == Application.ApplicationType.Android) {
            val nativeSearch = TextButton("자원·국가 검색 (한글 지원)", BaseScreen.skin)
            nativeSearch.onClick {
                Gdx.input.getTextInput(object : Input.TextInputListener {
                    override fun input(text: String) {
                        resourceSearch = text.trim()
                        render()
                        parentTab.overviewScreen.resizePage(parentTab)
                    }
                    override fun canceled() { }
                }, "세계 자원 시장 검색", resourceSearch, "자원명 / 판매국")
            }
            searchBar.add(nativeSearch).padRight(5f)
            if (resourceSearch.isNotEmpty())
                searchBar.add("검색: $resourceSearch".toLabel(hideIcons = true)).padRight(5f)
        } else {
            val searchField = TextField(resourceSearch, BaseScreen.skin)
            searchField.messageText = "자원명 또는 판매국"
            searchBar.add(searchField).width(260f).padRight(5f)
            val searchButton = TextButton("검색", BaseScreen.skin)
            searchButton.onClick {
                resourceSearch = searchField.text.trim()
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            searchBar.add(searchButton)
        }
        val clearSearch = TextButton("초기화", BaseScreen.skin)
        clearSearch.onClick {
            resourceSearch = ""
            render()
            parentTab.overviewScreen.resizePage(parentTab)
        }
        searchBar.add(clearSearch).padLeft(4f)
        add(searchBar).left().row()

        val filters = Table(BaseScreen.skin)
        val sortButton = TextButton(if (priceSort) "가격순: 낮은 가격" else "정렬: 자원명", BaseScreen.skin)
        sortButton.onClick {
            priceSort = !priceSort
            render()
            parentTab.overviewScreen.resizePage(parentTab)
        }
        filters.add(sortButton)
        val affordable = TextButton(if (affordableOnly) "구매 가능 금액 ✓" else "구매 가능 금액만", BaseScreen.skin)
        affordable.onClick {
            affordableOnly = !affordableOnly
            render()
            parentTab.overviewScreen.resizePage(parentTab)
        }
        filters.add(affordable).padLeft(5f)
        val strategic = TextButton(if (strategicOnly) "전략자원 ✓" else "전략자원만", BaseScreen.skin)
        strategic.onClick {
            strategicOnly = !strategicOnly
            render()
            parentTab.overviewScreen.resizePage(parentTab)
        }
        filters.add(strategic).padLeft(5f)
        add(filters).left().row()

        val query = resourceSearch.trim()
        val orders = gameInfo.worldMarketOrders
'''
    s = replace_once(s, old, new, 'Search/filter UI')

    old = '''                seller != buyer &&
                    seller.isAI() &&
                    !seller.isDefeated() &&
                    (spectator || seller.civName in known)
            }
            .sortedWith(
                compareBy(
                    { it.resourceName },
                    { it.unitPrice },
                    { it.sellerCivId },
                    { it.id }
                )
            )
'''
    new = '''                val resource = gameInfo.ruleset.tileResources[order.resourceName]
                val matchesSearch = query.isEmpty() || listOf(
                    order.resourceName, order.resourceName.tr(),
                    seller.civName, seller.civName.tr()
                ).any { it.contains(query, ignoreCase = true) }

                seller != buyer && seller.isAI() && !seller.isDefeated() &&
                    (spectator || seller.civName in known) &&
                    matchesSearch &&
                    (!affordableOnly || order.unitPrice <= buyer.gold) &&
                    (!strategicOnly || resource?.resourceType == ResourceType.Strategic)
            }
            .sortedWith(
                if (priceSort) compareBy<com.unciv.logic.market.MarketSellOrder>(
                    { it.unitPrice }, { it.resourceName }, { it.id })
                else compareBy<com.unciv.logic.market.MarketSellOrder>(
                    { it.resourceName }, { it.unitPrice }, { it.sellerCivId }, { it.id })
            )
'''
    s = replace_once(s, old, new, 'Search criteria/sorting')
    s = replace_once(s,
        '        if (orders.isEmpty()) {\n            add("현재 등록된 판매 상품이 없습니다.".toLabel())\n',
        '        add("검색 결과 ${orders.size}건 · 자원 유형 및 가격 필터 적용".toLabel()).left().row()\n'
        '        if (orders.isEmpty()) {\n            add((if (query.isEmpty() && !affordableOnly && !strategicOnly)\n'
        '                "현재 등록된 판매 상품이 없습니다." else "조건에 맞는 상품이 없습니다.").toLabel())\n',
        'Empty/filter count messaging')
    s = replace_once(s,
        '        for (order in orders) {\n',
        '        for (order in orders.take(100)) {\n',
        'Display cap')
    s = replace_once(s,
        '                "${order.resourceName} · ${seller.civName}"\n',
        '                "${order.resourceName.tr()} · ${seller.civName.tr()}"\n',
        'Market row localization')
    s = replace_once(s,
        '                "판매 ${order.quantity}개 · 내 가용 ${owned}개"\n',
        '                "판매 ${order.quantity}개 · 내 가용 ${owned}개 · ${if (order.stockpiled) "비축" else "턴 공급"}"\n',
        'Market row extra info')
    s = replace_once(s,
        '                        "${order.resourceName} 1개 구매 완료"\n',
        '                        "${order.resourceName.tr()} 1개 구매 완료"\n',
        'Purchase feedback localization')
    s = replace_once(s,
        '            add(line).growX().row()\n        }\n    }\n}\n',
        '            add(line).growX().row()\n        }\n'
        '        if (orders.size > 100)\n'
        '            add("화면 성능을 위해 상품 100건만 표시합니다. 검색으로 범위를 좁혀주세요.".toLabel()).left().row()\n'
        '    }\n}\n',
        'Capped-list hint')
    return s


def verify(s: str) -> None:
    required = [MARKER,'Gdx.input.getTextInput(', 'resourceSearch = text.trim()',
                '가격순: 낮은 가격', '전략자원만', '검색 결과 ${orders.size}건',
                'order.resourceName.tr()', 'orders.take(100)']
    missing = [x for x in required if x not in s]
    if missing:
        raise RuntimeError(f'v1.4 verification failed: missing {missing}')


def main() -> None:
    parser = argparse.ArgumentParser()
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--check', action='store_true')
    modes.add_argument('--apply', action='store_true')
    modes.add_argument('--verify', action='store_true')
    a = parser.parse_args()
    path = Path.cwd() / TARGET
    if not path.exists():
        raise RuntimeError(f'Run at the root of the Unciv repository. Missing: {path}')
    current = path.read_text(encoding='utf-8')
    if a.verify:
        verify(current)
        print('VERIFY OK: world resource market v1.4 UI patch found')
        return
    result = transform(current)
    verify(result)
    if a.check:
        print('CHECK OK: target file and all patch anchors match. No changes made.')
        return
    fd, tmpname = tempfile.mkstemp(prefix='.gs-world-market-v14-',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='') as f: f.write(result)
        os.replace(tmpname,path)
    except BaseException:
        try: os.unlink(tmpname)
        except OSError: pass
        raise
    print('APPLY OK: updated WorldMarketTradeSection.kt')
    print('Next: python3 gs_world_market_v14/install.py --verify')
    print('Then: ./gradlew :core:compileKotlin --no-daemon --console=plain')

if __name__=='__main__':
    try:
        main()
    except Exception as e:
        print('PATCH ERROR:',e, file=sys.stderr)
        sys.exit(1)
