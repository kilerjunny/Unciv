# England island starts – Android `mobile-dev` v1

This ZIP ports the **same England-only island start preference** already used on the PC `pc-dev` branch to Android `mobile-dev`.

## What this changes

- On **NEW** `Maritime Continents` maps, England preferentially starts on an independent landmass with enough space to develop, when an eligible precomputed starting region exists.
- No eligible island → vanilla/Maritime World coastal start assignment fallback.
- This is a **preference, not a guarantee**; no land is generated or changed just to accommodate England.
- The option **No start bias** must be **off** for the England-specific preference to activate (matches the PC implementation).
- Other nations, other map types, AI logic, military economy, save format, and existing generated maps are unchanged.

## Apply in Codespaces

Upload `england-island-start-mobile-v1.zip` into `/workspaces/Unciv` first.

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
ls -lh england-island-start-mobile-v1.zip
unzip -o england-island-start-mobile-v1.zip -d /tmp
python3 /tmp/england-island-start-mobile-v1/apply_england_island_start_mobile_v1.py --check
python3 /tmp/england-island-start-mobile-v1/apply_england_island_start_mobile_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

After `BUILD SUCCESSFUL`:

```bash
git add core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt
git diff --cached --check
git commit -m "Prefer England island starts on Maritime Continents Android"
git push origin mobile-dev
```

Then use your existing Android GitHub Actions workflow to build/download the APK, or obtain the locally built debug APK.

## Safety and tests

- Patches **one** tracked Kotlin source file only.
- Refuses other branches and refuses to overwrite uncommitted modifications to the target.
- Idempotent: rerunning reports already applied without duplicating code.
- Source markers for Maritime World v3 are required.
- Existing games' maps do not change. Back up saves before installing a new APK.
- `--check` and isolated patch tests are not a full Android build or a gameplay test.
