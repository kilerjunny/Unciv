#!/usr/bin/env python3
"""Atomic, checked Maritime World v3 port to the existing Unciv Windows PC branch.

Source: kilerjunny/Unciv mobile-dev at 1f7c7535ca82396c0795199121cc6b9193d569b8.
Target: grand-strategy-formations (PC) with stock map-generator source blobs.
No mobile-only trade, unit AI, or save data changes are pulled into the PC game.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PATHS = [
    "core/src/com/unciv/logic/map/MapParameters.kt",
    "core/src/com/unciv/logic/map/mapgenerator/MapLandmassGenerator.kt",
    "core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt",
    "core/src/com/unciv/logic/map/mapgenerator/mapregions/RegionStartFinder.kt",
]
# Exact clean PC blobs as of c4e76b2c93abb9a774c7c0258aac1d11c9e1421d.
BASE_BLOBS = {
    PATHS[0]: "4760afe91804f674b30db2b3a1206504f0b08f15",
    PATHS[1]: "9efd9a23878d801e2b7a828c329d9de87329b323",
    PATHS[2]: "bdd93a75cc08de3fbbf55e8f4400bc816bae2afd",
    PATHS[3]: "6f16a2c8775c1d64e7581c78b28d8bafc378c4c2",
}
# Exact final mobile-dev Maritime World v3 source blobs, including v1 coast-start code.
FINAL_BLOBS = {
    PATHS[0]: "aa6cd1a6958a1b51193f608ef8d161c70cfa1bef",
    PATHS[1]: "cfc2fd27cfe86cfa2f7e97323a7bcc6192b89b49",
    PATHS[2]: "18048edaeb24a4c4d1aaa1237fe289099d29604a",
    PATHS[3]: "ca918909efd7b907db10026e4762d3c1abf44671",
}


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def load(name: str):
    spec = importlib.util.spec_from_file_location("pc_maritime_" + name, ROOT / ("_" + name + ".py"))
    if spec is None or spec.loader is None:
        raise RuntimeError("Unable to load bundled " + name + " patch module")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def transform(sources: dict[str, str]) -> dict[str, str]:
    """Apply the exact mobile v1, v2, v3 transforms in memory, then validate."""
    v1, v2, v3 = load("v1"), load("v2"), load("v3")
    output = {
        PATHS[0]: v1.patch_params(sources[PATHS[0]]),
        PATHS[1]: v1.patch_landmass(sources[PATHS[1]]),
        PATHS[2]: v1.patch_regions(sources[PATHS[2]]),
        PATHS[3]: v1.patch_start(sources[PATHS[3]]),
    }
    output[PATHS[1]], v2_changed = v2.transform(output[PATHS[1]])
    if not v2_changed:
        raise RuntimeError("v1 -> v2 upgrade did not run")
    output[PATHS[1]], v3_changed = v3.transform(output[PATHS[1]])
    if not v3_changed:
        raise RuntimeError("v2 -> v3 upgrade did not run")
    return output


def git(*args: str, repo: Path) -> str:
    p = subprocess.run(["git", *args], cwd=repo, capture_output=True, text=True)
    if p.returncode:
        raise RuntimeError("git " + " ".join(args) + ": " + (p.stderr or p.stdout).strip())
    return p.stdout.strip()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Validate without modifying files")
    args = parser.parse_args()
    repo = Path.cwd()
    try:
        branch = git("branch", "--show-current", repo=repo)
        if branch != "grand-strategy-formations":
            raise RuntimeError(f"Expected PC branch 'grand-strategy-formations', found {branch!r}")
        originals = {}
        for rel in PATHS:
            path = repo / rel
            if not path.is_file():
                raise RuntimeError("Missing repository source: " + rel)
            originals[rel] = path.read_bytes()
        blobs = {rel: git_blob_sha(data) for rel, data in originals.items()}
        if blobs == FINAL_BLOBS:
            print("Maritime World v3 is already installed on the PC branch; no changes needed.")
            return 0
        dirty = git("status", "--porcelain", "--", *PATHS, repo=repo)
        if dirty:
            raise RuntimeError("Uncommitted changes in the 4 target Kotlin files; preserve them before applying:\n" + dirty)
        mismatch = [rel for rel in PATHS if blobs[rel] != BASE_BLOBS[rel]]
        if mismatch:
            raise RuntimeError(
                "Unexpected PC source version; safe patch refused. Inspect these paths:\n" +
                "\n".join(f"  {rel}: actual {blobs[rel]}" for rel in mismatch))
        text_sources = {rel: originals[rel].decode("utf-8") for rel in PATHS}
        outputs = transform(text_sources)
        final = {rel: outputs[rel].encode("utf-8") for rel in PATHS}
        bad = [rel for rel in PATHS if git_blob_sha(final[rel]) != FINAL_BLOBS[rel]]
        if bad:
            raise RuntimeError("Final source verification failed (will not write any files): " + ", ".join(bad))
        if args.check:
            print("PASS: PC source versions matched; v1 -> v2 -> v3 transformed in memory; all 4 final blobs verified.")
            return 0
        for rel in PATHS:
            (repo / rel).write_bytes(final[rel])
            print("Patched " + rel)
        print("SUCCESS: PC Maritime World v3 applied. Next: ./gradlew :desktop:dist :desktop:zipWindows64 --no-daemon")
        return 0
    except (RuntimeError, UnicodeError, OSError) as error:
        print("ERROR: " + str(error), file=sys.stderr)
        return 1

if __name__ == "__main__":
    sys.exit(main())
