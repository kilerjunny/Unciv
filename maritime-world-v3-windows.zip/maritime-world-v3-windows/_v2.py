#!/usr/bin/env python3
"""Upgrade Maritime Continents v1 -> v2 in kilerjunny/Unciv mobile-dev.

Changes only the landmass generator method. This does not modify map formats,
start-position code or other map types. Requires already installed v1.
"""
from __future__ import annotations

import argparse
import pathlib
import subprocess
import sys

FILE = pathlib.Path('core/src/com/unciv/logic/map/mapgenerator/MapLandmassGenerator.kt')
OLD_START = '''    /**
     * GS_MARITIME_WORLD_V1
'''
OLD_END = '''    /** Bounded 4-tile island groups, generally within five tiles of existing land. */'''
VERSION = 'GS_MARITIME_WORLD_V2_SMALL_CONTINENTS'

V2 = '''    /**
     * GS_MARITIME_WORLD_V2_SMALL_CONTINENTS
     * Draw geography from the same ridged Perlin landmass field as the stock
     * Small Continents map, NOT the one-sided Continent and Islands transform.
     * Try a bounded number of seeds and favor a spread of medium continents.
     * This only runs at map generation, never during turns.
     *
     * Keep the v1 water-level behavior (65% target at default settings) and
     * the same bounded islands/straits and 85%-target coast-start selection.
     */
    private fun createMaritimeContinents() {
        val tiles = tileMap.values.toList()
        if (tiles.isEmpty()) return
        val waterRatio = (0.65 + tileMap.mapParameters.waterThreshold.toDouble()).coerceIn(0.55, 0.75)
        val targetWater = (tiles.size * waterRatio).toInt().coerceIn(0, tiles.size)

        // Use one seed per candidate, so the selected layout is deterministic
        // for the map seed and the map's shape/size parameters.
        val samples = if (tiles.size >= 18000) 2 else 3
        var bestMask: BooleanArray? = null
        var bestScore = Int.MAX_VALUE
        repeat(samples) {
            val elevationSeed = randomness.RNG.nextInt().toDouble()
            val byElevation = tiles.map { tile ->
                // Exactly the stock Small Continents terrain field. Rank it
                // instead of using the default lowering-water-level retry:
                // this preserves a consistent, predictable 65% sea share.
                val elevation = getRidgedPerlinNoise(tile, elevationSeed, scale = 22.0) +
                    getOceanEdgesTransform(tile)
                tile.zeroBasedIndex to elevation
            }.sortedWith(compareBy<Pair<Int, Double>> { it.second }.thenBy { it.first })

            val land = BooleanArray(tiles.size)
            for (index in targetWater until byElevation.size)
                land[byElevation[index].first] = true

            val score = maritimeLandmassScore(tiles, land)
            if (score < bestScore) {
                bestScore = score
                bestMask = land
            }
        }

        val land = bestMask ?: return
        for (tile in tiles)
            tile.baseTerrain = if (land[tile.zeroBasedIndex]) landTerrainName else waterTerrainName

        // Keep the proven v1 bounded edits, including protection for new
        // island chains. These never rerun during turns or on loaded saves.
        val newIslands = addMaritimeIslandChains()
        carveMaritimeStraits(newIslands)
    }

    /**
     * Score connected landmasses without setting map transients. A single
     * enormous continent and a map made only of tiny isolated specks are both
     * less desirable than several viable medium-sized continents.
     * Bounded O(tiles + edges) flood-fill, run only on the seed candidates.
     */
    private fun maritimeLandmassScore(tiles: List<Tile>, land: BooleanArray): Int {
        val visited = BooleanArray(land.size)
        val componentSizes = ArrayList<Int>()
        val queue = ArrayDeque<Tile>()
        for (tile in tiles) {
            val index = tile.zeroBasedIndex
            if (!land[index] || visited[index]) continue
            visited[index] = true
            queue.add(tile)
            var size = 0
            while (queue.isNotEmpty()) {
                val current = queue.removeFirst()
                size++
                for (neighbor in current.neighbors) {
                    val neighborIndex = neighbor.zeroBasedIndex
                    if (!land[neighborIndex] || visited[neighborIndex]) continue
                    visited[neighborIndex] = true
                    queue.add(neighbor)
                }
            }
            componentSizes.add(size)
        }
        val totalLand = land.count { it }.coerceAtLeast(1)
        val largestPercent = ((componentSizes.maxOrNull() ?: 0) * 100) / totalLand
        val mediumThreshold = (totalLand / 70).coerceAtLeast(8)
        val mediumCount = componentSizes.count { it >= mediumThreshold }

        val giantPenalty = (largestPercent - 28).coerceAtLeast(0) * 12
        val tooFewPenalty = (4 - mediumCount).coerceAtLeast(0) * 35
        val tooManyPenalty = (mediumCount - 18).coerceAtLeast(0) * 12
        return giantPenalty + tooFewPenalty + tooManyPenalty + kotlin.math.abs(largestPercent - 19)
    }

'''


def check_repo():
    cp = subprocess.run(['git', 'branch', '--show-current'], capture_output=True,
                        text=True, check=True)
    branch = cp.stdout.strip()
    if branch != 'mobile-dev':
        raise RuntimeError(f"Required branch mobile-dev, found {branch!r}")
    if not FILE.is_file():
        raise RuntimeError('Missing ' + str(FILE))
    worktree = subprocess.run(['git', 'diff', '--name-only', '--', str(FILE)],
                              capture_output=True, text=True, check=True)
    if worktree.stdout.strip():
        raise RuntimeError(f'Uncommitted changes in {FILE}; commit or revert before applying')


def transform(source: str) -> tuple[str, bool]:
    if VERSION in source:
        if source.count(VERSION) < 1:
            raise RuntimeError('Unexpected partial v2 marker')
        return source, False
    if source.count(OLD_START) != 1 or source.count(OLD_END) != 1:
        raise RuntimeError('Expected exactly one Maritime World v1 method and island helper')
    before, remainder = source.split(OLD_START, 1)
    original_method, after = remainder.split(OLD_END, 1)
    if ('private fun createMaritimeContinents()' not in original_method or
            'getContinentAndIslandsTransform' not in original_method or
            'addMaritimeIslandChains()' not in original_method or
            'carveMaritimeStraits(newIslands)' not in original_method):
        raise RuntimeError('Existing generator differs from v1: refusing to overwrite edits')
    # Verify the v1 helper methods stay intact, with no extra map-type changes.
    if source.count('MapType.maritimeContinents -> createMaritimeContinents()') != 1:
        raise RuntimeError('Maritime map type not installed or has been modified')
    return before + V2 + OLD_END + after, True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='verify anchors, no modifications')
    args = parser.parse_args()
    try:
        check_repo()
        original = FILE.read_text(encoding='utf-8')
        updated, changed = transform(original)
        if not changed:
            print('Already upgraded to Maritime World v2. No changes made.')
        elif args.check:
            print('OK: Maritime World v1 found; v2 patch can be applied safely.')
        else:
            FILE.write_text(updated, encoding='utf-8')
            print(f'Upgraded: {FILE}')
            print('Next: git diff --check && ./gradlew :android:assembleDebug --no-daemon')
    except (OSError, RuntimeError, subprocess.CalledProcessError) as error:
        print('ERROR:', error, file=sys.stderr)
        raise SystemExit(1)


if __name__ == '__main__':
    main()
