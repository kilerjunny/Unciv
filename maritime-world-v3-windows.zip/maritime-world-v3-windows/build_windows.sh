#!/usr/bin/env bash
# Run from /workspaces/Unciv on the grand-strategy-formations branch.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f ./gradlew ]] || [[ ! -f desktop/build.gradle.kts ]]; then
  echo "ERROR: run this script from the Unciv repository root (/workspaces/Unciv)" >&2
  exit 1
fi
python3 "$SCRIPT_DIR/apply_maritime_world_v3_windows.py" --check
python3 "$SCRIPT_DIR/apply_maritime_world_v3_windows.py"
git diff --check
./gradlew :desktop:dist :desktop:zipWindows64 --no-daemon
if [[ ! -s deploy/Unciv-Windows64.zip ]]; then
  echo "ERROR: Gradle reported success, but deploy/Unciv-Windows64.zip is missing or empty" >&2
  exit 1
fi
echo
printf 'Windows build created: '
ls -lh deploy/Unciv-Windows64.zip
