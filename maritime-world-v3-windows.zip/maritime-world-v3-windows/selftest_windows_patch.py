#!/usr/bin/env python3
"""Offline smoke tests of the atomic PC migration (synthetic Kotlin anchors)."""
import importlib.util
from pathlib import Path
from tempfile import TemporaryDirectory
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("pc_main", root / "apply_maritime_world_v3_windows.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

mock = {
 module.PATHS[0]: '''object MapType {
    const val continentAndIslands = "Continent and Islands"
    val allValues = listOf(
        continentAndIslands,
    )
}
''',
 module.PATHS[1]: '''class MapLandmassGenerator {
    fun generateLand() {
      when (type) {
            MapType.continentAndIslands -> createContinentAndIslands()
      }
    }
    private fun createTwoContinents() { }
}
''',
 module.PATHS[2]: '''import com.unciv.logic.map.MapShape
class MapRegions {
  fun assignRegions() {
        val sortedRegions = regions.sortedBy { it.totalFertility }
        for (region in sortedRegions) RegionStartFinder.findStart(region, tileData)
  }
}
''',
 module.PATHS[3]: '''object RegionStartFinder {
    internal fun findStart(region: Region, tileData: TileDataMap) {
    }
    private fun findGoodPosition(centerTiles: Set<Tile>, region: Region, tileData: TileDataMap, fallbackTiles: HashSet<Tile>): Boolean { return false }
}
'''
}
final = module.transform(mock)
assert 'GS_MARITIME_WORLD_V3_OPEN_OCEANS' in final[module.PATHS[1]]
assert 'maritimeContinents' in final[module.PATHS[0]]
assert 'preferCoast' in final[module.PATHS[2]]
assert 'tryFindMaritimeCoast' in final[module.PATHS[3]]
assert final[module.PATHS[1]].count('private fun createMaritimeContinents()') == 1
assert 'addMaritimeIslandChains(protectedOceanCore: Set<Tile>)' in final[module.PATHS[1]]

old_base, old_final = module.BASE_BLOBS, module.FINAL_BLOBS
module.BASE_BLOBS = {p: module.git_blob_sha(v.encode()) for p,v in mock.items()}
module.FINAL_BLOBS = {p: module.git_blob_sha(v.encode()) for p,v in final.items()}

with TemporaryDirectory() as td:
 repo = Path(td)
 subprocess.run(['git','init','-q','-b','grand-strategy-formations'],cwd=repo,check=True)
 for p,src in mock.items():
  f=repo/p; f.parent.mkdir(parents=True,exist_ok=True); f.write_text(src)
 subprocess.run(['git','add','.'],cwd=repo,check=True)
 subprocess.run(['git','-c','user.name=Testing','-c','user.email=tests@example.invalid','commit','-qm','initial'],cwd=repo,check=True)
 oldcwd=os.getcwd(); os.chdir(repo)
 try:
  saved=sys.argv
  sys.argv=['pc_script','--check']
  assert module.main()==0
  for p,src in mock.items(): assert (repo/p).read_text()==src
  sys.argv=['pc_script']
  assert module.main()==0
  for p,src in final.items(): assert (repo/p).read_text()==src
  # Re-running the identical patch is safe even before commit.
  assert module.main()==0
  first = module.PATHS[0]
  (repo/first).write_text((repo/first).read_text() + "\n// unexpected modification\n")
  assert module.main()==1
  (repo/first).write_text(final[first])
  subprocess.run(['git','add','.'],check=True)
  subprocess.run(['git','-c','user.name=Testing','-c','user.email=tests@example.invalid','commit','-qm','v3'],check=True)
  assert module.main()==0
  subprocess.run(['git','switch','-q','-c','wrong-branch'],check=True)
  assert module.main()==1
  sys.argv=saved
 finally:
  os.chdir(oldcwd)
module.BASE_BLOBS, module.FINAL_BLOBS = old_base, old_final
print('PASS: v1→v2→v3 transform, check-only, repeated run, dirty guard, PC branch guard, source markers')
