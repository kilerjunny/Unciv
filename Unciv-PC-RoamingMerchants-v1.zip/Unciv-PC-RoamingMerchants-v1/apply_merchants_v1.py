#!/usr/bin/env python3
"""Apply roaming merchant v1 in the isolated Unciv checkout.

Run with cwd at Unciv repository root and the package directory as argv[1].
Raises on source drift instead of silently producing an incomplete build.
"""
import json
import pathlib
import sys

repo = pathlib.Path.cwd()
bundle = pathlib.Path(sys.argv[1]).resolve()

def replace_once(rel, before, after):
    path = repo / rel
    src = path.read_text(encoding='utf-8')
    n = src.count(before)
    if n != 1:
        raise RuntimeError(f'{rel}: anchor count expected 1; found {n}: {before[:75]!r}')
    path.write_text(src.replace(before, after, 1), encoding='utf-8')
    print('patched:', rel)

# Preserve merchant journey metadata with ordinary GameInfo/MapUnit save cloning.
mapunit = 'core/src/com/unciv/logic/map/mapunit/MapUnit.kt'
replace_once(mapunit,
    '    var automated: Boolean = false\n',
    '''    var automated: Boolean = false

    // GS_ROAMING_MERCHANTS_V1: persisted optional state (safe defaults for old saves).
    var merchantHomeCityName: String = ""
    var merchantTargetCivId: String = ""
    var merchantTargetCityName: String = ""
    var merchantLastCityCivId: String = ""
    var merchantLastCityName: String = ""
    var merchantTripStartTurn: Int = 0
    var merchantNoProgressTurns: Int = 0
    var merchantFeesThisTrip: Int = 0
    var merchantTripsCompleted: Int = 0
    var merchantIncomeEarned: Int = 0
    var merchantTotalFeesPaid: Int = 0
    var merchantFeeKeys: ArrayList<String> = ArrayList()
''')
replace_once(mapunit,
    '        toReturn.automated = automated\n',
    '''        toReturn.automated = automated
        toReturn.merchantHomeCityName = merchantHomeCityName
        toReturn.merchantTargetCivId = merchantTargetCivId
        toReturn.merchantTargetCityName = merchantTargetCityName
        toReturn.merchantLastCityCivId = merchantLastCityCivId
        toReturn.merchantLastCityName = merchantLastCityName
        toReturn.merchantTripStartTurn = merchantTripStartTurn
        toReturn.merchantNoProgressTurns = merchantNoProgressTurns
        toReturn.merchantFeesThisTrip = merchantFeesThisTrip
        toReturn.merchantTripsCompleted = merchantTripsCompleted
        toReturn.merchantIncomeEarned = merchantIncomeEarned
        toReturn.merchantTotalFeesPaid = merchantTotalFeesPaid
        toReturn.merchantFeeKeys = ArrayList(merchantFeeKeys)
''')

turn = 'core/src/com/unciv/logic/civilization/managers/TurnManager.kt'
replace_once(turn,
    'import com.unciv.logic.market.WorldMarketOrders\n',
    'import com.unciv.logic.market.WorldMarketOrders\nimport com.unciv.logic.market.RoamingMerchantAutomation\n')
replace_once(turn,
    '''        GrandStrategyPerf.measure("turn_start_units") {
            for (unit in civInfo.units.getCivUnits()) UnitTurnManager(unit).startTurn()
        }
''',
    '''        GrandStrategyPerf.measure("turn_start_units") {
            for (unit in civInfo.units.getCivUnits()) UnitTurnManager(unit).startTurn()
        }
        // Civilian merchants move once on their owner's turn, for human and AI alike.
        GrandStrategyPerf.measure("turn_start_roaming_merchants") {
            RoamingMerchantAutomation.processTurn(civInfo)
        }
''')

nextturn = 'core/src/com/unciv/logic/automation/civilization/NextTurnAutomation.kt'
replace_once(nextturn,
    'import com.unciv.logic.market.WorldMarketAI\n',
    'import com.unciv.logic.market.WorldMarketAI\nimport com.unciv.logic.market.RoamingMerchantAutomation\n')
path = repo / nextturn
src = path.read_text(encoding='utf-8')
needle = '.filterNot { MilitaryMarket.isReservedUnit(it) }'
if src.count(needle) != 2:
    raise RuntimeError(f'{nextturn}: expected 2 AI filtering anchors, got {src.count(needle)}')
src = src.replace(needle,
    '.filterNot { MilitaryMarket.isReservedUnit(it) || it.name == RoamingMerchantAutomation.UnitName }')
path.write_text(src, encoding='utf-8')

merchant_tab = 'core/src/com/unciv/ui/screens/overviewscreen/MerchantOverviewTab.kt'
replace_once(merchant_tab,
    '        add(WorldMarketTradeSection(viewingPlayer, this, merchantMode = true)).growX().row()\n',
    '''        add(RoamingMerchantSection(viewingPlayer)).growX().row()
        add(WorldMarketTradeSection(viewingPlayer, this, merchantMode = true)).growX().row()
''')

# Place full new Kotlin files; cannot overwrite unexpected existing implementations.
for rel in (
    'core/src/com/unciv/logic/market/RoamingMerchantAutomation.kt',
    'core/src/com/unciv/ui/screens/overviewscreen/RoamingMerchantSection.kt',
):
    path = repo / rel
    if path.exists():
        raise RuntimeError(f'Existing merchant implementation at {rel}; refusing to overwrite')
    source = bundle / 'patch' / rel
    if not source.is_file():
        raise FileNotFoundError(source)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(source.read_bytes())
    print('added:', rel)

# Both base ruleset choices must know the new on-map civilian class.
new_unit = '''  {
    "name": "Trade Caravan",
    "unitType": "Civilian",
    "movement": 3,
    "cost": 0,
    "requiredTech": "Currency",
    "uniques": ["Unbuildable", "Cannot be purchased", "Uncapturable"]
  },
'''
for rel in (
    'android/assets/jsons/Civ V - Gods & Kings/Units.json',
    'android/assets/jsons/Civ V - Vanilla/Units.json',
):
    path = repo / rel
    data = path.read_text(encoding='utf-8')
    if '"name": "Trade Caravan"' in data:
        raise RuntimeError(f'Already contains Trade Caravan: {rel}')
    # JSON with comments; insert new unit immediately after the opening array.
    leading = data.index('[')
    data = data[:leading+1] + '\n' + new_unit + data[leading+1:]
    path.write_text(data, encoding='utf-8')
    print('registered unit:', rel)

# Assertions catch partial changes before a multi-minute Gradle build.
assert 'merchantFeeKeys = ArrayList(merchantFeeKeys)' in (repo / mapunit).read_text()
assert 'RoamingMerchantAutomation.processTurn(civInfo)' in (repo / turn).read_text()
assert 'RoamingMerchantSection(viewingPlayer)' in (repo / merchant_tab).read_text()
assert 'ForeignSeaPassageGold = 5' in (repo / 'core/src/com/unciv/logic/market/WorldMarketCashTolls.kt').read_text()
print('Merchant source patch applied and invariants verified.')
