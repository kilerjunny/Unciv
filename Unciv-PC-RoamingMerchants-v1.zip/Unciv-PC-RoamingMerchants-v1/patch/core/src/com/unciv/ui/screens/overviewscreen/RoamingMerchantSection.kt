package com.unciv.ui.screens.overviewscreen

import com.badlogic.gdx.scenes.scene2d.ui.Table
import com.unciv.logic.market.RoamingMerchantAutomation
import com.unciv.models.translations.tr
import com.unciv.ui.components.extensions.toLabel
import com.unciv.ui.screens.basescreen.BaseScreen
import com.unciv.view.CivView

/** Compact live overview for actual on-map roaming merchant units. */
class RoamingMerchantSection(private val playerView: CivView) : Table(BaseScreen.skin) {
    init {
        top().left()
        defaults().pad(4f)
        val viewer = playerView.getCiv()
        val game = viewer.gameInfo
        val all = game.civilizations.sumOf { civ ->
            civ.units.getCivUnits().count { it.name == RoamingMerchantAutomation.UnitName }
        }
        val mine = viewer.units.getCivUnits()
            .filter { it.name == RoamingMerchantAutomation.UnitName }.toList()
        add("일반 상단 (자원 거래와 별개) · 전 세계 ${all}개 / 내 상단 ${mine.size}개".toLabel(hideIcons = true))
            .left().growX().row()
        if (mine.isEmpty()) {
            add("상단은 문명별 일정 주기에 자동 생성되며 도시를 방문합니다.".toLabel(hideIcons = true))
                .left().growX().row()
        }
        for (unit in mine.take(12)) {
            val goal = unit.merchantTargetCityName.ifEmpty { "자유 이동" }
            val country = game.getCivilizationOrNull(unit.merchantTargetCivId)?.civName?.tr() ?: ""
            add("상단 #${unit.id} · 현재 ${unit.currentTile.position} → $goal $country".toLabel(hideIcons = true))
                .left().growX().row()
            add("완료 ${unit.merchantTripsCompleted}회 · 영업 수입 ${unit.merchantIncomeEarned}G · 통행료 지출 ${unit.merchantTotalFeesPaid}G".toLabel(hideIcons = true))
                .left().growX().row()
        }
    }
}
