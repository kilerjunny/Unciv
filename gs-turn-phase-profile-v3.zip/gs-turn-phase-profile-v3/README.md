# Grand Strategy — Turn Phase Diagnostic v3

Base: `kilerjunny/Unciv` `mobile-dev`, inspected 2026-11-06, commit `bef752acc207a7f3b580a4dd1a5ec2d9a9287a96` (AI path precheck v2).

## Scope

**Diagnostic only.** Adds timer scopes to `TurnManager.startTurn` and `TurnManager.endTurn`, plus per-phase breakdown to existing `상단 → 성능 진단` view. Does not alter AI decisions, saves, rules, marketplace, pathfinding, or turn order.

**Turn start**: formations, research progress, resources, market sell orders, construction, civ stats, religion, vision, capital connections, flags/revolts, city turn starts, unit turn starts.

**Turn end**: city auto-bombard, triggers, stats, policies, income, research, religion, espionage, city turn ends, temporary effects/happiness, unit turn ends, diplomacy changes.

Times for detailed steps are subsets of their parent `턴 시작/종료 갱신` times. `기타·미계측` contains the remaining code and profiler overhead. Counts represent invocation counts across the completed turn's multiple civilizations. No gameplay optimization is applied by this version.

## Apply

1. Upload the ZIP to `mobile-dev` on GitHub and commit.
2. In Codespaces, run:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o gs-turn-phase-profile-v3.zip -d /tmp
python3 /tmp/gs-turn-phase-profile-v3/apply_gs_turn_phase_profile_v3.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

3. If Android build passes:

```bash
git add core/src/com/unciv/logic/civilization/managers/TurnManager.kt
git add core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt
git rm --ignore-unmatch gs-turn-phase-profile-v3.zip
git diff --cached --check
git commit -m "Profile turn start and end phase costs v3"
git push origin mobile-dev
```

4. Build APK from GitHub Actions on `mobile-dev`, install, advance 1–3 turns, open `상단 → 성능 진단`, and share the lower detailed results.

If the apply script encounters an unexpected source layout, it refuses the patch with an error **before editing either file**. If the patch reports `ALREADY APPLIED`, don't apply twice. If Android build fails, **do not commit**; capture the first `e:` Kotlin compiler errors from a fresh build log.

## Verification limitations

The script validates exact source anchors and prevents repeat application; Android compilation and real in-game timings must be verified in Codespaces and on the device. The profiler measures elapsed wall time, so device load/temperature and turn conditions affect comparisons.
