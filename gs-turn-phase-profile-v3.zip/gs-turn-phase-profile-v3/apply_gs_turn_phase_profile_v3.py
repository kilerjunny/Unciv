#!/usr/bin/env python3
"""GS Turn Start/End phase profiler v3. Apply to kilerjunny/Unciv mobile-dev after AI v2.
Diagnostic only: no gameplay or save format changes. Preflight all anchors before writing.
"""
from pathlib import Path
import sys

ROOT = Path.cwd()
TM = Path('core/src/com/unciv/logic/civilization/managers/TurnManager.kt')
PERF = Path('core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt')
MARK = 'GS_TURN_PHASE_PROFILE_V3'

class Patch:
    def __init__(self, rel):
        self.rel = rel
        self.file = ROOT / rel
        self.old = self.file.read_text(encoding='utf-8')
        self.text = self.old
    def replace(self, old, new):
        n = self.text.count(old)
        if n != 1:
            raise RuntimeError(f'{self.rel}: expected exactly one match; found {n} for {old[:100]!r}')
        self.text = self.text.replace(old, new, 1)

def main():
    t = Patch(TM)
    p = Patch(PERF)
    if MARK in t.old and MARK in p.old:
        print('ALREADY APPLIED: turn phase profile v3; no changes.')
        return
    if MARK in t.old or MARK in p.old:
        raise RuntimeError('Partially patched source detected. Refusing to modify.')
    if 'GS_AI_PATH_PRECHECK_V2' not in p.old:
        raise RuntimeError('Expected military AI path precheck v2 in GrandStrategyPerf.kt; update mobile-dev first.')

    # One common, constant label is emitted once per completed turn, not each frame.
    t.replace('import com.unciv.logic.automation.civilization.NextTurnAutomation\n',
              'import com.unciv.logic.automation.civilization.NextTurnAutomation\n'
              'import com.unciv.logic.automation.civilization.GrandStrategyPerf\n')
    t.replace('class TurnManager(val civInfo: Civilization) {\n',
              'class TurnManager(val civInfo: Civilization) {\n'
              '    // GS_TURN_PHASE_PROFILE_V3: scoped diagnostic timers only.\n')
    t.replace('''        val formationManager = grandstrategy.formations.FormationManager(civInfo.grandStrategyFormations)
        formationManager.reconcileLiveUnits(civInfo.units.getCivUnits().map { it.id.toString() }.toSet())
        civInfo.grandStrategyFormations = formationManager.snapshot()
''', '''        GrandStrategyPerf.measure("turn_start_formations") {
            val formationManager = grandstrategy.formations.FormationManager(civInfo.grandStrategyFormations)
            formationManager.reconcileLiveUnits(civInfo.units.getCivUnits().map { it.id.toString() }.toSet())
            civInfo.grandStrategyFormations = formationManager.snapshot()
        }
''')
    t.replace('''        if (civInfo.cities.isNotEmpty() && civInfo.gameInfo.ruleset.technologies.isNotEmpty())
            civInfo.tech.updateResearchProgress()
''','''        if (civInfo.cities.isNotEmpty() && civInfo.gameInfo.ruleset.technologies.isNotEmpty())
            GrandStrategyPerf.measure("turn_start_research") { civInfo.tech.updateResearchProgress() }
''')
    t.replace('''        civInfo.cache.updateCivResources() // If you offered a trade last turn, this turn it will have been accepted/declined
        for (stockpiledResource in civInfo.getCivResourceSupply().filter { it.resource.isStockpiled })
            civInfo.gainStockpiledResource(stockpiledResource.resource, stockpiledResource.amount)
''','''        GrandStrategyPerf.measure("turn_start_resources") {
            civInfo.cache.updateCivResources() // If you offered a trade last turn, this turn it will have been accepted/declined
            for (stockpiledResource in civInfo.getCivResourceSupply().filter { it.resource.isStockpiled })
                civInfo.gainStockpiledResource(stockpiledResource.resource, stockpiledResource.amount)
        }
''')
    t.replace('''        WorldMarketOrders.reconcileSellerOrders(civInfo)
''','''        GrandStrategyPerf.measure("turn_start_market_orders") { WorldMarketOrders.reconcileSellerOrders(civInfo) }
''')
    t.replace('''        civInfo.civConstructions.startTurn()
''','''        GrandStrategyPerf.measure("turn_start_constructions") { civInfo.civConstructions.startTurn() }
''')
    t.replace('''        civInfo.updateStatsForNextTurn() // for things that change when turn passes e.g. golden age, city state influence
''','''        GrandStrategyPerf.measure("turn_start_stats") {
            civInfo.updateStatsForNextTurn() // for things that change when turn passes e.g. golden age, city state influence
        }
''')
    t.replace('''            civInfo.religionManager.startTurn()
''','''            GrandStrategyPerf.measure("turn_start_religion") { civInfo.religionManager.startTurn() }
''')
    t.replace('''        civInfo.cache.updateViewableTiles() // adds explored tiles so that the units will be able to perform automated actions better
        civInfo.cache.updateCitiesConnectedToCapital()
''','''        GrandStrategyPerf.measure("turn_start_vision") {
            civInfo.cache.updateViewableTiles() // adds explored tiles so that the units will be able to perform automated actions better
        }
        GrandStrategyPerf.measure("turn_start_city_connections") { civInfo.cache.updateCitiesConnectedToCapital() }
''')
    t.replace('''        startTurnFlags()
        updateRevolts()
''','''        GrandStrategyPerf.measure("turn_start_flags_revolts") {
            startTurnFlags()
            updateRevolts()
        }
''')
    t.replace('''        for (city in civInfo.cities) {
            progressBar?.increment()
            CityTurnManager(city).startTurn()  // Most expensive part of startTurn
        }
''','''        GrandStrategyPerf.measure("turn_start_cities") {
            for (city in civInfo.cities) {
                progressBar?.increment()
                CityTurnManager(city).startTurn()  // Most expensive part of startTurn
            }
        }
''')
    t.replace('''        for (unit in civInfo.units.getCivUnits()) UnitTurnManager(unit).startTurn()
''','''        GrandStrategyPerf.measure("turn_start_units") {
            for (unit in civInfo.units.getCivUnits()) UnitTurnManager(unit).startTurn()
        }
''')
    # End-turn timings, measured across all processed AI civs and the human civ.
    t.replace('''        if (UncivGame.Current.settings.citiesAutoBombardAtEndOfTurn)
            NextTurnAutomation.automateCityBombardment(civInfo) // Bombard with all cities that haven't, maybe you missed one
''','''        if (UncivGame.Current.settings.citiesAutoBombardAtEndOfTurn)
            GrandStrategyPerf.measure("turn_end_bombard") {
                NextTurnAutomation.automateCityBombardment(civInfo) // Bombard with all cities that haven't, maybe you missed one
            }
''')
    t.replace('''        civInfo.forEachTriggeredUnique(UniqueType.TriggerUponTurnEnd, civInfo.state, ignoreCities = true) { unique ->
            UniqueTriggerActivation.triggerUnique(unique, civInfo)
        }
''','''        GrandStrategyPerf.measure("turn_end_triggers") {
            civInfo.forEachTriggeredUnique(UniqueType.TriggerUponTurnEnd, civInfo.state, ignoreCities = true) { unique ->
                UniqueTriggerActivation.triggerUnique(unique, civInfo)
            }
        }
''')
    t.replace('''        var nextTurnStats =
            if (civInfo.isBarbarian)
                Stats()
            else {
                civInfo.updateStatsForNextTurn()
                civInfo.stats.statsForNextTurn
            }
''','''        var nextTurnStats = GrandStrategyPerf.measure("turn_end_stats") {
            if (civInfo.isBarbarian)
                Stats()
            else {
                civInfo.updateStatsForNextTurn()
                civInfo.stats.statsForNextTurn
            }
        }
''')
    t.replace('''        civInfo.policies.endTurn(nextTurnStats.culture.toInt())
''','''        GrandStrategyPerf.measure("turn_end_policies") { civInfo.policies.endTurn(nextTurnStats.culture.toInt()) }
''')
    t.replace('''        civInfo.addGold(nextTurnStats.gold.toInt() )
''','''        GrandStrategyPerf.measure("turn_end_income") { civInfo.addGold(nextTurnStats.gold.toInt() ) }
''')
    t.replace('''        if (civInfo.cities.isNotEmpty() && civInfo.gameInfo.ruleset.technologies.isNotEmpty())
            civInfo.tech.endTurn(nextTurnStats.science.toInt())
''','''        if (civInfo.cities.isNotEmpty() && civInfo.gameInfo.ruleset.technologies.isNotEmpty())
            GrandStrategyPerf.measure("turn_end_research") { civInfo.tech.endTurn(nextTurnStats.science.toInt()) }
''')
    t.replace('''        civInfo.religionManager.endTurn(nextTurnStats.faith.toInt())
''','''        GrandStrategyPerf.measure("turn_end_religion") { civInfo.religionManager.endTurn(nextTurnStats.faith.toInt()) }
''')
    t.replace('''        civInfo.espionageManager.endTurn()
''','''        GrandStrategyPerf.measure("turn_end_espionage") { civInfo.espionageManager.endTurn() }
''')
    t.replace('''        for (city in civInfo.cities.sortedByDescending { it.isBeingRazed }) {
            progressBar?.increment()
            CityTurnManager(city).endTurn()
        }
''','''        GrandStrategyPerf.measure("turn_end_cities") {
            for (city in civInfo.cities.sortedByDescending { it.isBeingRazed }) {
                progressBar?.increment()
                CityTurnManager(city).endTurn()
            }
        }
''')
    t.replace('''        civInfo.temporaryUniques.endTurn()

        civInfo.goldenAges.endTurn(civInfo.getHappiness())
''','''        GrandStrategyPerf.measure("turn_end_temporary_happiness") {
            civInfo.temporaryUniques.endTurn()
            civInfo.goldenAges.endTurn(civInfo.getHappiness())
        }
''')
    t.replace('''        civInfo.units.getCivUnits().forEach { UnitTurnManager(it).endTurn() }  // This is the most expensive part of endTurn
''','''        GrandStrategyPerf.measure("turn_end_units") {
            civInfo.units.getCivUnits().forEach { UnitTurnManager(it).endTurn() }  // This is the most expensive part of endTurn
        }
''')
    t.replace('''        civInfo.diplomacy.values.toList().forEach { it.nextTurn() } // we copy the diplomacy values so if it changes in-loop we won't crash
''','''        GrandStrategyPerf.measure("turn_end_diplomacy") {
            civInfo.diplomacy.values.toList().forEach { it.nextTurn() } // we copy the diplomacy values so if it changes in-loop we won't crash
        }
''')
    # Detailed diagnostic display; all rows are children of phase_turn_start / end.
    p.replace('''        lines.add("턴 시작 갱신: ${ms(start)} ms")
        lines.add("턴 종료 갱신: ${ms(end)} ms")
''','''        lines.add("턴 시작 갱신: ${ms(start)} ms")
        lines.add("턴 종료 갱신: ${ms(end)} ms")
        // GS_TURN_PHASE_PROFILE_V3: all values below are INCLUDED in the phase totals above.
        val startDetails = listOf(
            "편제 유닛 정리" to "turn_start_formations",
            "연구 진행" to "turn_start_research",
            "자원·비축 갱신" to "turn_start_resources",
            "시장 주문 조정" to "turn_start_market_orders",
            "건설 처리" to "turn_start_constructions",
            "문명 턴 통계" to "turn_start_stats",
            "종교 시작" to "turn_start_religion",
            "시야·탐색 갱신" to "turn_start_vision",
            "수도 연결 도시" to "turn_start_city_connections",
            "국가 상태·반란" to "turn_start_flags_revolts",
            "도시 시작 갱신" to "turn_start_cities",
            "유닛 시작 갱신" to "turn_start_units"
        )
        val endDetails = listOf(
            "도시 자동 포격" to "turn_end_bombard",
            "종료 트리거" to "turn_end_triggers",
            "문명 통계 재계산" to "turn_end_stats",
            "정책 처리" to "turn_end_policies",
            "금 수입 정산" to "turn_end_income",
            "연구 종료" to "turn_end_research",
            "종교 종료" to "turn_end_religion",
            "첩보 종료" to "turn_end_espionage",
            "도시 종료 갱신" to "turn_end_cities",
            "임시 효과·행복" to "turn_end_temporary_happiness",
            "유닛 종료 갱신" to "turn_end_units",
            "외교 관계 갱신" to "turn_end_diplomacy"
        )
        lines.add("---- 턴 시작 상세 (턴 시작 갱신에 포함) ----")
        for ((label, key) in startDetails) item(label, key)
        val measuredStart = startDetails.sumOf { (_, key) -> result.durations[key] ?: 0L }
        lines.add("시작 기타·미계측: ${ms((start - measuredStart).coerceAtLeast(0L))} ms")
        lines.add("---- 턴 종료 상세 (턴 종료 갱신에 포함) ----")
        for ((label, key) in endDetails) item(label, key)
        val measuredEnd = endDetails.sumOf { (_, key) -> result.durations[key] ?: 0L }
        lines.add("종료 기타·미계측: ${ms((end - measuredEnd).coerceAtLeast(0L))} ms")
        lines.add("※ 상세 계측은 소량의 오버헤드를 포함합니다. 상위 시간과 합산하지 마세요.")
''')

    edits = [x for x in (t, p) if x.text != x.old]
    # Preflight is complete; only now make writes. No game-save schema changes.
    for x in edits:
        tmp = x.file.with_name(x.file.name + '.gs_turn_phase_v3.tmp')
        tmp.write_text(x.text, encoding='utf-8')
        tmp.replace(x.file)
        print('PATCHED', x.rel)
    print('GS turn start/end phase profiler v3 complete. Modified', len(edits), 'Kotlin files.')
    print('Next: git diff --check && ./gradlew :android:assembleDebug --no-daemon')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('ERROR:', exc, file=sys.stderr)
        sys.exit(1)
