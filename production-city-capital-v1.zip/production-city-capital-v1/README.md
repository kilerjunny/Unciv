# Grand Strategy: production-city → buyer-capital routes v1

Target branch: `mobile-dev` (based on economic-trade-routes-v1).

### Gameplay logic
- For each *completed* market deal, determine candidate source cities using Unciv's `city.getResourcesGeneratedByCity().sumBy(resourceName) > 0`. This includes tile and city-generated resources, not imported resources or unworked deposits that do not actually yield the resource.
- If multiple cities produce the resource, Dijkstra selects whichever offers the cheapest observed transportation path to **the purchasing civilization's capital**.
- When no current producing city can be identified (e.g., stockpiles from older turns, imported resources), the seller's capital is used as an **explicitly labelled fallback**. If one of the capitals is missing, route may be `UNRESOLVED`; the actual trade still completes.
- This is **observation-only**, just like the current route system: original national resource pooling, immediate market settlement, prices, and AI purchases are unchanged. No per-city inventory, cargo, or animated vessel is created.
- Route cache now includes resource name so different commodities traded by the same pair can select different starting cities.
- Old saves keep old route records unchanged; new routes record origin-kind metadata and show labels in the trade history. The true provenance of each unit from a **national stockpile** is unknowable from currently available data; 'producing city' is therefore an inference from **current city output**.

### Apply
1. Download this ZIP and upload it to the **root** of your GitHub repository on `mobile-dev` via *Add file → Upload files*. Commit.
2. Codespaces terminal (from repository root):

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o production-city-capital-v1.zip -d /tmp
python3 /tmp/production-city-capital-v1/apply_production_city_capital_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

3. On `BUILD SUCCESSFUL`:

```bash
git add core/src/com/unciv/logic/market/WorldMarketRoutePlanner.kt \
  core/src/com/unciv/logic/market/WorldMarketHistory.kt \
  core/src/com/unciv/logic/market/MarketTradeRecord.kt \
  core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git commit -m "Route market goods from producing cities to buyer capitals"
git push origin mobile-dev
```

4. GitHub Actions Android build, select `mobile-dev` and install the artifact.

### Test
- Make a *new* transaction and open **개요 → 거래 → 세계 시장 → 거래 내역**. Expect origin city and destination city name + origin selection label.
- Test a buyer with inland capital, a country with multiple producing cities, and a stockpiled/imported commodity without a current source.
- Validate money/resources settle immediately, and map/performance are still fine.
- **Runtime/Android build not yet tested** in this environment. The patch script checks all expected source anchors before writing.
