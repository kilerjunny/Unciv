#!/usr/bin/env python3
"""Apply production-city -> buyer-capital observational route selection to mobile-dev.
All transformations are checked before writing; safe to rerun only if nothing changed.
"""
from pathlib import Path
import sys

ROOT = Path.cwd()
MARKER = 'GS_PRODUCTION_CITY_CAPITAL_V1'
FILES = {
    'planner': 'core/src/com/unciv/logic/market/WorldMarketRoutePlanner.kt',
    'history': 'core/src/com/unciv/logic/market/WorldMarketHistory.kt',
    'record': 'core/src/com/unciv/logic/market/MarketTradeRecord.kt',
    'ui': 'core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt',
}


def replace_once(text, old, new, name):
    count = text.count(old)
    if count != 1:
        raise ValueError(f'{name}: expected exactly one match, got {count}: {old[:100]!r}')
    return text.replace(old, new, 1)


def patch_planner(s):
    s = replace_once(s,
        '        val estimatedTransportCost: Int = -1 // GS_ECONOMIC_TRADE_ROUTES_V1\n',
        '        val estimatedTransportCost: Int = -1, // GS_ECONOMIC_TRADE_ROUTES_V1\n'
        '        val originKind: String = "UNKNOWN" // GS_PRODUCTION_CITY_CAPITAL_V1\n', 'planner.Route')
    s = replace_once(s,
        '    fun plan(seller: Civilization, buyer: Civilization): Route {\n',
        '    // GS_PRODUCTION_CITY_CAPITAL_V1: resource-specific route, observational only.\n'
        '    fun plan(seller: Civilization, buyer: Civilization, resourceName: String = ""): Route {\n', 'planner.plan')
    s = replace_once(s,
        '        val key = "${game.gameId}|${game.turns}|${seller.civID}|${buyer.civID}"\n',
        '        val key = "${game.gameId}|${game.turns}|${seller.civID}|${buyer.civID}|$resourceName"\n', 'planner.cache')
    s = replace_once(s,
        '            val result = calculate(seller, buyer)\n',
        '            val result = calculate(seller, buyer, resourceName)\n', 'planner.calculateCall')
    old = '''    private fun calculate(seller: Civilization, buyer: Civilization): Route {
        // Using the actual tile as key prevents misleading straight-line pairing.
        val startCities = LinkedHashMap<Tile, City>()
        val endCities = LinkedHashMap<Tile, City>()
        for (city in seller.cities) {
            val tile = city.getCenterTile()
            if (tile.isLand && !tile.isImpassible()) startCities[tile] = city
        }
        for (city in buyer.cities) {
            val tile = city.getCenterTile()
            if (tile.isLand && !tile.isImpassible()) endCities[tile] = city
        }

        if (startCities.isEmpty() || endCities.isEmpty()) return unresolved(seller, buyer)
'''
    new = '''    private fun calculate(seller: Civilization, buyer: Civilization, resourceName: String): Route {
        // GS_PRODUCTION_CITY_CAPITAL_V1: Choose CURRENT net-producing cities as origins.
        // The national resource pool does not track which specific unit of stockpiled
        // cargo was produced where. In that case, use the seller's capital as a
        // clearly labelled fallback; never fabricate an origin from a random city.
        // No resource balances or trade settlement code is changed.
        val producingCities = if (resourceName.isBlank()) emptyList<City>() else
            seller.cities.filter { it.getResourcesGeneratedByCity().sumBy(resourceName) > 0 }
        val originKind = if (producingCities.isNotEmpty()) "PRODUCTION" else "CAPITAL_FALLBACK"
        val sourceCities = if (producingCities.isNotEmpty()) producingCities
            else seller.getCapital()?.let { listOf(it) }.orEmpty()

        val startCities = LinkedHashMap<Tile, City>()
        val endCities = LinkedHashMap<Tile, City>()
        for (city in sourceCities) {
            val tile = city.getCenterTile()
            if (tile.isLand && !tile.isImpassible()) startCities[tile] = city
        }
        // Only the BUYER'S CAPITAL is the destination, including landlocked capitals.
        // The existing city-harbor rule handles coastal loading and inland legs.
        val buyerCapital = buyer.getCapital()
        if (buyerCapital != null) {
            val tile = buyerCapital.getCenterTile()
            if (tile.isLand && !tile.isImpassible()) endCities[tile] = buyerCapital
        }

        if (startCities.isEmpty() || endCities.isEmpty()) return unresolved(seller, buyer)
'''
    s = replace_once(s, old, new, 'planner.selectCities')
    s = replace_once(s,
        '                path.map { it.position }, cheapest.estimatedCost)\n',
        '                path.map { it.position }, cheapest.estimatedCost, originKind)\n', 'planner.weightedReturn')
    s = replace_once(s,
        '                    path.map { it.position }\n                )\n',
        '                    path.map { it.position }, -1, originKind\n                )\n', 'planner.bfsReturn')
    return s


def patch_history(s):
    s = replace_once(s,
        '            val route = WorldMarketRoutePlanner.plan(seller, buyer)\n',
        '            val route = WorldMarketRoutePlanner.plan(seller, buyer, resource) // GS_PRODUCTION_CITY_CAPITAL_V1\n', 'history.plan')
    s = replace_once(s,
        '            item.estimatedTransportCost = route.estimatedTransportCost // GS_ECONOMIC_TRADE_ROUTES_V1\n',
        '            item.estimatedTransportCost = route.estimatedTransportCost // GS_ECONOMIC_TRADE_ROUTES_V1\n'
        '            item.originKind = route.originKind // GS_PRODUCTION_CITY_CAPITAL_V1\n', 'history.originKind')
    return s


def patch_record(s):
    return replace_once(s,
        '    var estimatedTransportCost: Int = -1 // GS_ECONOMIC_TRADE_ROUTES_V1: optional for older saves\n',
        '    var estimatedTransportCost: Int = -1, // GS_ECONOMIC_TRADE_ROUTES_V1: optional for older saves\n'
        '    var originKind: String = "UNKNOWN" // GS_PRODUCTION_CITY_CAPITAL_V1: old saves stay UNKNOWN\n', 'record.originKind')


def patch_ui(s):
    old = '''                    add("무역로: $endpoints$routeLabel$steps".toLabel(hideIcons = true)).left().row()
'''
    new = '''                    add("무역로: $endpoints$routeLabel$steps".toLabel(hideIcons = true)).left().row()
                    // GS_PRODUCTION_CITY_CAPITAL_V1: Explain origin selection, not physical delivery.
                    when (it.originKind) {
                        "PRODUCTION" -> add("출발: 현재 생산 도시(추정) · 도착: 구매국 수도".toLabel(hideIcons = true)).left().row()
                        "CAPITAL_FALLBACK" -> add("출발: 판매국 수도(생산지 미확인) · 도착: 구매국 수도".toLabel(hideIcons = true)).left().row()
                    }
'''
    return replace_once(s, old, new, 'ui.tradeHistory')


def main():
    original = {}
    for key, rel in FILES.items():
        path = ROOT / rel
        if not path.is_file():
            sys.exit(f'PATCH STOPPED: missing {rel}; run from the Unciv repository root.')
        original[key] = path.read_text(encoding='utf-8-sig')
    if any(MARKER in text for text in original.values()):
        sys.exit('PATCH STOPPED: Already applied or partly applied; no changes made.')
    try:
        modified = {
            'planner': patch_planner(original['planner']),
            'history': patch_history(original['history']),
            'record': patch_record(original['record']),
            'ui': patch_ui(original['ui']),
        }
    except ValueError as e:
        sys.exit(f'PATCH STOPPED: base code does not match expected mobile-dev version: {e}\nNo files changed.')
    for key, rel in FILES.items():
        (ROOT / rel).write_text(modified[key], encoding='utf-8')
        print('MODIFIED:', rel)
    print('GS production-city -> buyer-capital v1 applied. Run git diff --check and Gradle build.')


if __name__ == '__main__':
    main()
