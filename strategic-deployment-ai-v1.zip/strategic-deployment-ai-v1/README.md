# Unciv Strategic Deployment AI v1 — mobile-dev

**Purpose:** Give AI major civilizations a limited peacetime defensive deployment plan. No changes to combat odds, unit stats, save format, or wartime unit AI.

## Behavior

- Replan defensive **assignments** once every 5 game turns (or when city count changes).
- Priority: border cities, capitals, overseas cities (different land continent), and naval ports. Higher-priority combinations receive more attention.
- Land units cover land/city-center garrison slots; naval units cover coastal waters. Assignment uses approximate map distance and prefers same-continent troops for land positions.
- An assigned unit moves using normal Unciv pathfinding, with at most 3 reachability checks in a turn. Units already near their assigned defended city hold instead of pointless exploration.
- Failed route targets are not retried during the same 5-turn plan. No teleports and no global unit reassignment every turn.
- **No war:** defensive placement. **War:** the original combat AI. Health/urgent defense/attack/encampment actions, which run before this hook, still take precedence.
- Only a limited number of defensive slots are assigned per city. Nonassigned military units continue the existing AI.
- No new save-game fields; plan is transient and will be rebuilt after reload.
- AI majors only. Human-controlled, civilian, air, nuclear, special settler/work-builder, transported/escorting units, and military-market reserved units are excluded.

## Installation

Use on branch `mobile-dev` after the performance profiling v3 patch. Upload `strategic-deployment-ai-v1.zip` via GitHub web into the branch, then in Codespaces from the repository root:

```sh
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o strategic-deployment-ai-v1.zip -d /tmp
python3 /tmp/strategic-deployment-ai-v1/apply_strategic_deployment_ai_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

**Do not commit if the Android build fails.** After success:

```sh
git add core/src/com/unciv/logic/automation/unit/UnitAutomation.kt
git add core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt
git add core/src/com/unciv/logic/automation/civilization/StrategicDeploymentAI.kt
git rm --ignore-unmatch strategic-deployment-ai-v1.zip
git diff --cached --check
git commit -m 'Add peacetime strategic military deployment AI v1'
git push origin mobile-dev
```

## Diagnostics

The `상단 -> 성능 진단` report adds:
- `평시 전략 배치 판단` time (nested under the AI unit time)
- `전략 배치 계획 갱신`, `배정 유닛`
- `전략 주둔 유지`, `전략 재배치 이동`, `경로 불가`

Compare turn processing time and unit actions before and after in the same save scenario. This is a behavior change; some units will move less, deliberately holding garrisons.

## Compatibility / military-market return home

This patch does **not** itself add Military Market buyer-unit homecoming; that separate `military-market-homebound-v1` patch is compatible and has priority earlier in `UnitAutomation.automateUnitMoves`. If not applied, apply that previous package separately first. This patch deliberately leaves combat and wartime automation untouched.

## Source / validation

Source anchors matched the repository's `mobile-dev` branch. Standalone Kotlin syntax/type compilation used local API stubs; that is **not** a full Unciv Android build. Repeat execution is a no-op; partial/conflicting installation is rejected prior to any writes.
