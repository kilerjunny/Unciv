#!/usr/bin/env python3
"""Install Strategic Deployment AI v1 in an Unciv mobile-dev checkout.

Only touches two existing Kotlin files and creates one new Kotlin file.
Validate all anchors before writes; repeat execution is a no-op.
"""
from pathlib import Path
import sys

ROOT = Path.cwd()
AI = Path('core/src/com/unciv/logic/automation/unit/UnitAutomation.kt')
PERF = Path('core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt')
NEW = Path('core/src/com/unciv/logic/automation/civilization/StrategicDeploymentAI.kt')
MARKER = 'GS_STRATEGIC_DEPLOYMENT_AI_V1'

NEW_SOURCE = r'''package com.unciv.logic.automation.civilization

import com.unciv.logic.city.City
import com.unciv.logic.civilization.Civilization
import com.unciv.logic.market.MilitaryMarket
import com.unciv.logic.map.mapunit.MapUnit
import com.unciv.logic.map.mapunit.movement.UnitMovement
import com.unciv.logic.map.tile.Tile
import com.unciv.models.ruleset.unique.UniqueType
import java.util.WeakHashMap

/**
 * GS_STRATEGIC_DEPLOYMENT_AI_V1
 * Peacetime defensive deployment for AI major civilizations.
 *
 * Assign a bounded number of garrisons to capitals, border cities and
 * overseas cities. Units not assigned a defensive slot use ordinary Unciv AI.
 * Plans are transient, derived from the current map, and renewed every 5 turns.
 * The plan stores IDs only (no tile/unit references or save-file changes).
 */
object StrategicDeploymentAI {
    private const val PLAN_INTERVAL = 5
    private const val MAX_REACH_CHECKS_PER_DECISION = 3

    private data class Goal(
        val city: City,
        val priority: Int,
        val landSlots: Int,
        val navalSlots: Int,
        val continent: Int
    )

    private class Plan(
        val turn: Int,
        val cityCount: Int,
        val assignments: Map<Int, String>
    ) {
        // Failed paths are only remembered until the next plan refresh.
        val unreachable = HashSet<Int>()
    }

    // Weak keys prevent leaked plans when a GameInfo is discarded or cloned.
    private val plans = WeakHashMap<Civilization, Plan>()

    private fun eligible(unit: MapUnit): Boolean =
        unit.isMilitary() && !unit.isDestroyed && unit.id >= 0 &&
            !unit.baseUnit.isAirUnit() && !unit.isNuclearWeapon() &&
            !unit.isTransported && !unit.isEscorting() &&
            !unit.hasUnique(UniqueType.FoundCity) &&
            !unit.hasUnique(UniqueType.BuildImprovements) &&
            !unit.isExploring() && !MilitaryMarket.isReservedUnit(unit)

    @Synchronized
    private fun planFor(civ: Civilization): Plan {
        val turn = civ.gameInfo.turns
        val old = plans[civ]
        if (old != null && turn >= old.turn && turn - old.turn < PLAN_INTERVAL &&
            old.cityCount == civ.cities.size) return old

        val capital = civ.getCapital()?.getCenterTile()
        val capitalContinent = capital?.getContinent() ?: -1
        val goals = civ.cities.map { city ->
            val center = city.getCenterTile()
            val continent = center.getContinent()
            val overseas = capitalContinent >= 0 && continent >= 0 &&
                continent != capitalContinent
            val border = center.getTilesInDistance(5).any { tile ->
                val owner = tile.getOwner()
                owner != null && owner != civ && owner.isMajorCiv()
            }
            val priority = (if (city.isCapital()) 30 else 0) +
                (if (border) 35 else 0) +
                (if (overseas) 25 else 0) +
                (if (city.isNaval()) 10 else 0)
            val landSlots = if (border) 3 else if (city.isCapital() || overseas) 2 else 1
            val navalSlots = if (city.isNaval()) {
                if (border || overseas) 2 else 1
            } else 0
            Goal(city, priority, landSlots, navalSlots, continent)
        }.sortedWith(compareByDescending<Goal> { it.priority }.thenBy { it.city.id })

        val military = civ.units.getCivUnits().filter(::eligible).toList()
        val land = military.filterNot { it.baseUnit.isWaterUnit }.toMutableList()
        val naval = military.filter { it.baseUnit.isWaterUnit }.toMutableList()
        val assigned = HashMap<Int, String>()

        // Assign scarce units to important goals first, preferring units already
        // nearby or on the same continent. No path search during this planning pass.
        fun assignTo(goal: Goal, pool: MutableList<MapUnit>, slots: Int) {
            repeat(slots) {
                val center = goal.city.getCenterTile()
                val closest = pool.minWithOrNull(compareBy<MapUnit> { unit ->
                    val otherContinent = !unit.baseUnit.isWaterUnit &&
                        goal.continent >= 0 && unit.currentTile.getContinent() >= 0 &&
                        unit.currentTile.getContinent() != goal.continent
                    unit.currentTile.aerialDistanceTo(center) + if (otherContinent) 15 else 0
                }.thenBy { it.id }) ?: return@repeat
                assigned[closest.id] = goal.city.id
                pool.remove(closest)
            }
        }
        for (goal in goals) assignTo(goal, land, goal.landSlots)
        for (goal in goals) assignTo(goal, naval, goal.navalSlots)

        val plan = Plan(turn, civ.cities.size, assigned)
        plans[civ] = plan
        GrandStrategyPerf.addCount("strategic_deploy_replans", 1)
        GrandStrategyPerf.addCount("strategic_deploy_assigned", assigned.size)
        return plan
    }

    /**
     * Return true when a defensive assignment handled the unit's decision.
     * Combat, healing and hostile-camp behavior are checked earlier by
     * UnitAutomation, and any wartime uses the stock military AI.
     */
    fun tryDeploy(unit: MapUnit): Boolean {
        val civ = unit.civ
        if (!civ.isAI() || !civ.isMajorCiv() || civ.isAtWar() ||
            !eligible(unit) || civ.cities.isEmpty()) return false
        val plan = planFor(civ)
        val destinationCityId = plan.assignments[unit.id] ?: return false
        val city = civ.cities.firstOrNull { it.id == destinationCityId } ?: return false
        val center = city.getCenterTile()
        val origin = unit.currentTile
        val naval = unit.baseUnit.isWaterUnit

        // A garrison in the assigned city's local area holds position. For land
        // units, fill the city centre first when it is empty, then guard nearby.
        val inArea = origin.aerialDistanceTo(center) <= 2 &&
            (origin.getOwner() == civ || naval && origin.getOwner() == null) &&
            (if (naval) origin.isWater else origin.isLand)
        val unoccupiedLandGarrison = !naval && center.militaryUnit == null
        if (inArea && !unoccupiedLandGarrison) {
            GrandStrategyPerf.addCount("strategic_deploy_holding", 1)
            return true
        }
        if (!unit.hasMovement() || unit.id in plan.unreachable) return false

        val destinations = center.getTilesInDistance(2)
            .filter { tile ->
                !tile.isImpassible() &&
                    (tile.militaryUnit == null || tile.militaryUnit == unit) &&
                    (if (naval) tile.isWater &&
                        (tile.getOwner() == civ || tile.getOwner() == null)
                    else tile.isLand && tile.getOwner() == civ)
            }
            .sortedWith(compareBy<Tile>({ if (it == center) 0 else 1 },
                { it.aerialDistanceTo(origin) }, { it.aerialDistanceTo(center) }))
            .toList()

        var checks = 0
        for (tile in destinations) {
            if (tile == origin || !unit.movement.canMoveTo(tile)) continue
            if (checks >= MAX_REACH_CHECKS_PER_DECISION) break
            checks++
            if (!unit.movement.canReach(tile)) continue
            try {
                val before = unit.currentTile
                unit.movement.headTowards(tile)
                if (unit.currentTile != before) {
                    GrandStrategyPerf.addCount("strategic_deploy_moves", 1)
                    return true
                }
            } catch (_: UnitMovement.UnreachableDestinationException) {
                // Tile occupancy may change between path query and movement.
            }
        }
        // Don't repeatedly search unreachable overseas or blocked goals.
        plan.unreachable.add(unit.id)
        GrandStrategyPerf.addCount("strategic_deploy_unreachable", 1)
        return false // Existing AI may find a different useful action.
    }
}
'''


def replace_once(source: str, old: str, new: str, filename: str) -> str:
    n = source.count(old)
    if n != 1:
        raise RuntimeError(f'{filename}: expected one anchor, got {n}; NO files changed')
    return source.replace(old, new, 1)


def main() -> None:
    for p in (AI, PERF):
        if not (ROOT / p).is_file():
            raise RuntimeError(f'Not an Unciv repository root: missing {p}')
    source = {p: (ROOT / p).read_text(encoding='utf-8') for p in (AI, PERF)}
    markers = [MARKER in source[p] for p in (AI, PERF)]
    if all(markers) and (ROOT / NEW).is_file() and MARKER in (ROOT / NEW).read_text(encoding='utf-8'):
        print('Strategic Deployment AI v1 already applied. No changes.')
        return
    if any(markers) or (ROOT / NEW).exists():
        raise RuntimeError('Partial installation or existing file conflict; NO files changed')

    s = source[AI]
    s = replace_once(s,
        'import com.unciv.logic.automation.civilization.GrandStrategyPerf\n',
        'import com.unciv.logic.automation.civilization.GrandStrategyPerf\n'
        'import com.unciv.logic.automation.civilization.StrategicDeploymentAI\n', str(AI))
    s = replace_once(s,
        '        if (tryHeadTowardsEncampment(unit)) return\n\n'
        '        if (tryGarrisoningLandUnit(unit)) return\n',
        '        if (tryHeadTowardsEncampment(unit)) return\n\n'
        '        // GS_STRATEGIC_DEPLOYMENT_AI_V1: after combat, before default garrison/exploration.\n'
        '        if (unit.civ.isAI() && !unit.civ.isAtWar() &&\n'
        '            GrandStrategyPerf.measure("unit_strategic_deployment") { StrategicDeploymentAI.tryDeploy(unit) }) return\n\n'
        '        if (tryGarrisoningLandUnit(unit)) return\n', str(AI))
    source[AI] = s

    s = source[PERF]
    s = replace_once(s,
        '        item("적 접근 판단", "unit_attack_advance")\n',
        '        item("적 접근 판단", "unit_attack_advance")\n'
        '        // GS_STRATEGIC_DEPLOYMENT_AI_V1: included within regular unit AI time.\n'
        '        item("평시 전략 배치 판단", "unit_strategic_deployment")\n'
        '        lines.add("전략 배치 계획 갱신: ${result.counts["strategic_deploy_replans"] ?: 0}회 / " +\n'
        '            "배정 유닛: ${result.counts["strategic_deploy_assigned"] ?: 0}기")\n'
        '        lines.add("전략 주둔 유지: ${result.counts["strategic_deploy_holding"] ?: 0}회 / " +\n'
        '            "전략 재배치 이동: ${result.counts["strategic_deploy_moves"] ?: 0}회 / " +\n'
        '            "경로 불가: ${result.counts["strategic_deploy_unreachable"] ?: 0}회")\n', str(PERF))
    source[PERF] = s

    # No writes until both preflight checks and replacements succeed.
    for p in (AI, PERF):
        (ROOT / p).write_text(source[p], encoding='utf-8')
        print('PATCHED', p)
    (ROOT / NEW).write_text(NEW_SOURCE, encoding='utf-8')
    print('CREATED', NEW)
    print('Strategic Deployment AI v1 applied. Please compile before committing.')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('PATCH ABORTED:', exc, file=sys.stderr)
        sys.exit(1)
