# Grand Strategy 군수 시장 v1.3.7 한글 입력 수정

대상: feature/military-market-v13 브랜치의 군수 시장 v1.3.6

문제: libGDX TextField가 Android 한국어 IME 조합 입력을 안정적으로 처리하지 못할 수 있음.

수정: 군수 시장 검색에서 Android는 시스템 기본 한글 입력 다이얼로그(EditText)를 사용한다.
기존 검색 키워드는 유지되며 취소 버튼을 누르면 이전 키워드를 그대로 둔다.
PC에서는 기존 인라인 검색 필드를 유지한다.

**범위**: 군수 시장 검색창 한 곳. 도시 이름 변경 등 다른 Unciv 입력창은 아직 수정하지 않음.

## 사용법
1. ZIP을 GitHub의 feature/military-market-v13 브랜치에 업로드해 커밋
2. Codespaces에서 git pull --ff-only origin feature/military-market-v13
3. unzip -o grand_strategy_military_market_v137_korean_input.zip
4. python3 gs_military_market_v137/install.py --check
5. python3 gs_military_market_v137/install.py --apply
6. python3 gs_military_market_v137/install.py --verify
7. ./gradlew :core:compileKotlin --no-daemon --console=plain
8. git add core/src/com/unciv/ui/screens/overviewscreen/MilitaryMarketSection.kt
9. git commit -m "Fix Android Korean IME in military market search"
10. git push origin feature/military-market-v13

기존 코드와 정확히 일치하지 않으면 검사/적용을 중단하므로 기존 기능을 무심코 덮어쓰지 않는다.
