#!/usr/bin/env python3
"""v1.3.7: Native Android Hangul-safe military market search dialog."""
import argparse
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent.parent
TARGET = ROOT / 'core/src/com/unciv/ui/screens/overviewscreen/MilitaryMarketSection.kt'

OLD = '        val searchBar = Table(BaseScreen.skin)\n        val searchField = TextField(searchQuery, BaseScreen.skin)\n        searchField.messageText = "유닛명 / 국가 / 도시 검색"\n        searchBar.add(searchField).width(260f).padRight(4f)\n        val searchButton = TextButton("검색", BaseScreen.skin)\n        searchButton.onClick {\n            searchQuery = searchField.text.trim()\n            refresh()\n        }\n        searchBar.add(searchButton)\n        val clearButton = TextButton("초기화", BaseScreen.skin)\n        clearButton.onClick {\n            searchQuery = ""\n            refresh()\n        }\n        searchBar.add(clearButton)\n        add(searchBar).left().row()\n'
NEW = '        val searchBar = Table(BaseScreen.skin)\n        if (Gdx.app.type == Application.ApplicationType.Android) {\n            // libGDX TextField doesn\'t reliably support Korean IME composition on Android.\n            // Native Android EditText composes Hangul before passing back the full string.\n            val nativeSearchButton = TextButton("검색어 입력 (한글 지원)", BaseScreen.skin)\n            nativeSearchButton.onClick {\n                Gdx.input.getTextInput(object : Input.TextInputListener {\n                    override fun input(text: String) {\n                        searchQuery = text.trim()\n                        refresh()\n                    }\n                    override fun canceled() { /* keep the previous query */ }\n                }, "군수 시장 검색", searchQuery, "유닛명 / 국가 / 도시")\n            }\n            searchBar.add(nativeSearchButton).padRight(4f)\n            if (searchQuery.isNotEmpty())\n                searchBar.add("검색: $searchQuery".toLabel(hideIcons = true)).left().padRight(4f)\n        } else {\n            // Desktop keeps ordinary inline typing and Enter-independent search.\n            val searchField = TextField(searchQuery, BaseScreen.skin)\n            searchField.messageText = "유닛명 / 국가 / 도시 검색"\n            searchBar.add(searchField).width(260f).padRight(4f)\n            val searchButton = TextButton("검색", BaseScreen.skin)\n            searchButton.onClick {\n                searchQuery = searchField.text.trim()\n                refresh()\n            }\n            searchBar.add(searchButton)\n        }\n        val clearButton = TextButton("초기화", BaseScreen.skin)\n        clearButton.onClick {\n            searchQuery = ""\n            refresh()\n        }\n        searchBar.add(clearButton)\n        add(searchBar).left().row()\n'
NEEDED_IMPORTS = (
    'import com.badlogic.gdx.Application\n'
    'import com.badlogic.gdx.Gdx\n'
    'import com.badlogic.gdx.Input\n'
)
IMPORT_ANCHOR = 'import com.badlogic.gdx.scenes.scene2d.ui.Table\n'
MARKER = 'val nativeSearchButton = TextButton("검색어 입력 (한글 지원)", BaseScreen.skin)'


def status(text):
    if text.count(OLD) == 1 and MARKER not in text:
        return 'ready'
    if text.count(NEW) == 1 and text.count('import com.badlogic.gdx.Gdx\n') == 1 and text.count('import com.badlogic.gdx.Input\n') == 1 and text.count('import com.badlogic.gdx.Application\n') == 1:
        return 'applied'
    return 'invalid'


def main():
    parser = argparse.ArgumentParser()
    flags = parser.add_mutually_exclusive_group(required=True)
    flags.add_argument('--check', action='store_true')
    flags.add_argument('--apply', action='store_true')
    flags.add_argument('--verify', action='store_true')
    args = parser.parse_args()
    if not TARGET.is_file():
        raise SystemExit(f'ERROR: missing {TARGET}')
    if not (ROOT / '.git').exists():
        raise SystemExit('ERROR: repository root not found. Extract ZIP at the repo root.')
    text = TARGET.read_text(encoding='utf-8')
    state = status(text)
    if args.check:
        if state == 'invalid':
            raise SystemExit('CHECK ERROR: expected v1.3.6 search block is missing or has changed. No changes made.')
        print(f'CHECK OK: {state}. Android Korean native search can be installed.')
        return
    if args.verify:
        if state != 'applied':
            raise SystemExit('VERIFY ERROR: the Korean native search fix is not fully installed.')
        print('VERIFY OK: native Korean input on Android, inline TextField retained on desktop.')
        return
    if state == 'applied':
        print('APPLY OK: already installed. No changes made.')
        return
    if state != 'ready':
        raise SystemExit('APPLY ERROR: unexpected source version. No changes made.')
    if text.count(IMPORT_ANCHOR) != 1:
        raise SystemExit('APPLY ERROR: import insertion point mismatch. No changes made.')
    import_lines = []
    for line in NEEDED_IMPORTS.splitlines(keepends=True):
        if line not in text:
            import_lines.append(line)
    patched = text.replace(IMPORT_ANCHOR, ''.join(import_lines) + IMPORT_ANCHOR, 1).replace(OLD, NEW, 1)
    if status(patched) != 'applied':
        raise SystemExit('APPLY ERROR: final source failed verification. No changes made.')
    backup_dir = Path('/tmp/gs_military_market_v137_backup')
    backup_dir.mkdir(parents=True, exist_ok=True)
    (backup_dir / 'MilitaryMarketSection.kt').write_text(text, encoding='utf-8')
    TARGET.write_text(patched, encoding='utf-8')
    print('APPLY OK: Android uses native Hangul-safe text dialog; desktop unchanged.')
    print('Backup: /tmp/gs_military_market_v137_backup/MilitaryMarketSection.kt')


if __name__ == '__main__':
    main()
