#!/usr/bin/env python3
"""Conservative AI path cache patch for kilerjunny/Unciv.

Base: feature/android-thermal-monitor-v1.
- Up to 4 successful destination paths remembered per automated unit decision.
- Expire paths on movement changes, tile changes, or new game turn.
- Decision reset prevents reuse across other units' actions.
- Preserve gameplay: no path choice, traversal, AI decision, or economy changes.
"""
from pathlib import Path

ROOT = Path.cwd()
MOVEMENT = ROOT / "core/src/com/unciv/logic/map/mapunit/movement/UnitMovement.kt"
AUTOMATION = ROOT / "core/src/com/unciv/logic/automation/unit/UnitAutomation.kt"
PERF = ROOT / "core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt"
MARKER = "GS_UNIT_PATH_CACHE_V1"

for source in (MOVEMENT, AUTOMATION, PERF):
    if not source.exists():
        raise SystemExit(f"Missing expected source: {source}. Run at Unciv repository root.")
texts = {p: p.read_text(encoding="utf-8-sig") for p in (MOVEMENT, AUTOMATION, PERF)}
if any(MARKER in t for t in texts.values()):
    raise SystemExit("Already applied: marker found; no files changed.")


def replace_once(data: str, old: str, new: str, label: str) -> str:
    count = data.count(old)
    if count != 1:
        raise SystemExit(f"Patch stopped safely: expected 1 match for {label}; found {count}. No files changed.")
    return data.replace(old, new, 1)

# Must match the baseline's original one-destination cache exactly: this ensures
# code changes aren't silently applied to a different upstream implementation.
old_cache = '''class PathfindingCache(private val unit: MapUnit) {
    private var shortestPathCache = listOf<Tile>()
    private var destination: Tile? = null
    private var movement = -1f
    private var currentTile: Tile? = null

    /** Check if the caches are valid (only checking if the unit has moved or consumed movement points;
     * the isPlayerCivilization check is performed in the functions because we want isValid() == false
     * to have a specific behavior) */
    @Readonly private fun isValid(): Boolean = (movement == unit.currentMovement) && (unit.getTile() == currentTile)

    fun getShortestPathCache(destination: Tile): List<Tile> {
        if (unit.civ.isHuman()) return listOf()
        if (isValid() && this.destination == destination) {
            return shortestPathCache
        }
        return listOf()
    }

    fun setShortestPathCache(destination: Tile, newShortestPath: List<Tile>) {
        if (unit.civ.isHuman()) return
        if (isValid()) {
            shortestPathCache = newShortestPath
            this.destination = destination
        }
    }

    fun clear() {
        movement = unit.currentMovement
        currentTile = unit.getTile()
        destination = null
        shortestPathCache = listOf()
    }
}'''
new_cache = '''class PathfindingCache(private val unit: MapUnit) {
    // GS_UNIT_PATH_CACHE_V1: Keep a tiny LRU of positive routes within ONE AI decision.
    // Negative paths are deliberately not reused; obstacles can change as units move.
    private val shortestPaths = LinkedHashMap<Tile, List<Tile>>(4, 0.75f, true)
    private var movement = -1f
    private var currentTile: Tile? = null
    private var turn = -1
    private val maxPaths = 4

    @Readonly private fun isValid(): Boolean =
        movement == unit.currentMovement &&
            currentTile == unit.getTile() &&
            turn == unit.civ.gameInfo.turns

    fun getShortestPathCache(destination: Tile): List<Tile> {
        if (unit.civ.isHuman()) return emptyList()
        if (!isValid()) clear()
        val result = shortestPaths[destination] ?: return emptyList()
        if (result.isNotEmpty())
            GrandStrategyPerf.addCount("unit_path_cache_hits", 1)
        return result
    }

    fun setShortestPathCache(destination: Tile, newShortestPath: List<Tile>) {
        if (unit.civ.isHuman()) return
        if (!isValid()) clear()
        // An empty result is not safe to remember across changing unit occupancy.
        if (newShortestPath.isEmpty()) {
            shortestPaths.remove(destination)
            return
        }
        shortestPaths[destination] = newShortestPath
        if (shortestPaths.size > maxPaths) {
            val oldest = shortestPaths.keys.iterator()
            oldest.next()
            oldest.remove()
        }
    }

    fun clear() {
        movement = unit.currentMovement
        currentTile = unit.getTile()
        turn = unit.civ.gameInfo.turns
        shortestPaths.clear()
    }
}'''
texts[MOVEMENT] = replace_once(texts[MOVEMENT],old_cache,new_cache,"replace one-route cache")
# Avoid purging A* caches: only the BFS shortest-path cache is scoped to the current decision.
old_clear = '''    fun clearPathfindingCache() {
        pathfindingCache.clear()'''
new_clear = '''    /** GS_UNIT_PATH_CACHE_V1: Invalidate cached BFS routes at the start of each AI decision.
     *  This avoids reusing paths after other units moved, without clearing A* caches. */
    fun resetPathCacheForAiDecision() {
        pathfindingCache.clear()
    }

    fun clearPathfindingCache() {
        pathfindingCache.clear()'''
texts[MOVEMENT] = replace_once(texts[MOVEMENT],old_clear,new_clear,"add scoped invalidation")
old_entry = '''    fun automateUnitMoves(unit: MapUnit):Unit = timeThis("automateUnitMoves") {
        check(!unit.civ.isBarbarian) { "Barbarians is not allowed here." }
'''
new_entry = '''    fun automateUnitMoves(unit: MapUnit):Unit = timeThis("automateUnitMoves") {
        check(!unit.civ.isBarbarian) { "Barbarians is not allowed here." }
        // GS_UNIT_PATH_CACHE_V1: Other units may have moved since this unit last acted.
        // Reset only the small cached BFS routes, never movement points or decisions.
        if (unit.civ.isAI()) unit.movement.resetPathCacheForAiDecision()
'''
texts[AUTOMATION] = replace_once(texts[AUTOMATION],old_entry,new_entry,"decision-scoped cache reset")
old_perf = '''        item("경로 탐색 (중첩 제외)", "unit_pathfinding")'''
new_perf = '''        item("경로 탐색 (중첩 제외)", "unit_pathfinding")
        // GS_UNIT_PATH_CACHE_V1: Diagnostics only; no extra full path searches.
        lines.add("최단경로 캐시 적중: ${result.counts["unit_path_cache_hits"] ?: 0}회 (판단당 최대 4개 경로)")'''
texts[PERF] = replace_once(texts[PERF],old_perf,new_perf,"cache hit diagnostic")

# Validate ALL target markers and edits before writing any file.
assert "LinkedHashMap<Tile, List<Tile>>" in texts[MOVEMENT]
assert "if (unit.civ.isAI()) unit.movement.resetPathCacheForAiDecision()" in texts[AUTOMATION]
assert "최단경로 캐시 적중" in texts[PERF]
for p, t in texts.items():
    p.write_text(t,encoding="utf-8")
    print("Patched:",p.relative_to(ROOT))
print("Unit AI route cache v1 applied. Review git diff and compile Android.")
