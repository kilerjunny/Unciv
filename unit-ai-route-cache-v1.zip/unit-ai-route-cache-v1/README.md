# Unciv: 유닛 AI 경로 탐색 캐시 v1

## 목적

유닛 AI가 한 번의 판단에서 여러 목적지로 경로를 탐색할 때, 바로 앞 목적지의 계산 결과를 덮어쓰는 현상을 완화합니다. **턴/유닛 위치·이동력 변경/새 AI 판단**이 시작되면 이전 결과가 무효화됩니다.

- 최대 4개의 **성공한** 최단경로만 저장하며 가장 오래 쓰지 않은 경로부터 제거합니다.
- 실패한 경로는 저장하지 않아 다른 유닛의 이동으로 생긴 길을 차단하지 않습니다.
- 유닛 전투력, AI 전략, 이동 목적지 선정, 무역, 지도 표시, 저장파일 형식은 수정하지 않습니다.
- 기본 설정인 비-A* 경로 탐색에만 적용됩니다. A* 설정 ON 상태의 최단경로 루틴은 기존대로 유지됩니다.
- 성능 진단에 `최단경로 캐시 적중` 횟수가 추가됩니다. **적중 횟수 증가가 무조건 턴 처리 향상을 의미하지는 않습니다.**

## GitHub Add file 방식

`feature/android-thermal-monitor-v1` 브랜치에서 ZIP 업로드 후 Codespaces에서 아래 명령으로 적용합니다.

```bash
git switch feature/android-thermal-monitor-v1
git pull --ff-only origin feature/android-thermal-monitor-v1
git switch -c feature/unit-ai-route-cache-v1
unzip -o unit-ai-route-cache-v1.zip -d /tmp
python3 /tmp/unit-ai-route-cache-v1/apply_unit_ai_route_cache_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

빌드 성공 시:

```bash
git add core/src/com/unciv/logic/map/mapunit/movement/UnitMovement.kt core/src/com/unciv/logic/automation/unit/UnitAutomation.kt core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt
git commit -m "Optimize unit AI shortest path cache"
git push -u origin feature/unit-ai-route-cache-v1
```

GitHub Actions `Android build`에서 **feature/unit-ai-route-cache-v1** 선택하고 APK 빌드.

## 게임 실험

같은 저장파일과 비슷한 게임 상태에서 이전 APK와 새 APK로 5~10턴의 처리 시간을 비교하세요. `개요 → 거래 → 성능 진단`에서 전체 턴·유닛 AI·경로 탐색 시간과 `최단경로 캐시 적중` 횟수를 확인하세요. 발열 비교는 충전/밝기/시간을 가능한 한 일치시켜야 합니다.

**검증 제한:** 독립 스크립트 검사만 수행. 전체 Android 빌드와 실제 유닛 AI 정상 동작 및 성능 개선은 사용자 Codespaces/기기에서 확인 필요.
