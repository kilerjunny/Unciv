Unciv PC 실통항료/환적료 강화 빌드 (v2)

이 ZIP은 게임 실행 파일이 아닌 Codespaces용 PC 빌드 도구입니다.
기존 통합 빌드처럼 pc-dev에 최신 mobile-dev 변경사항을 합치되,
임시 작업 공간에서 WorldMarketCashTolls.kt의 실제 금화 징수액을 변경합니다.
PC 브랜치 원본, 저장파일, 이전 Windows ZIP은 수정하지 않습니다.

변경 값 (실제 징수 G):
- 해상 통항료 2 -> 5G
- 항구 환적료 4 -> 10G
- 중립국 육상 통행료 2 -> 4G
- 우호국 육상 통행료 1 -> 2G
- 거래당 최대 수수료 6 -> 30G
- 판매금액 상한 8% -> 25%

주의 사항:
- 수수료는 제3국 통과/환적 거래에만 기존 요건대로 부과됩니다.
- 제한을 적용하므로 명목요금 전체가 반드시 징수되지는 않습니다.
- 이미 끝난 과거 거래/세이브 기록에 새 요금은 소급 적용되지 않습니다.
- '도시별 통항료 수입 순위'는 아직 구현되지 않았습니다. 기존 도시 무역수지 통계도 그대로입니다.
- 테스트하지 않은 게임경제 밸런스 수치이며 플레이테스트가 필요합니다.

GitHub 웹에서 기존 pc-dev 브랜치 루트에 이 ZIP 업로드 후,
Codespaces 터미널에서 다음 명령을 순서대로 실행하세요:

  cd /workspaces/Unciv
  git switch pc-dev
  git pull --ff-only origin pc-dev
  unzip -o Unciv-PC-Fees-v2.zip
  bash Unciv-PC-Fees-v2/build_pc_fees_v2.sh

완료되면 생성되는 게임 ZIP:
  /workspaces/Unciv/deploy/Unciv-Windows64-TradeFees-v2-PC.zip

포트 다운로드(8765):
  cd /workspaces/Unciv/deploy
  python3 -m http.server 8765 --bind 0.0.0.0

기존 게임 진행을 유지하려면 이전 버전의 SaveFiles와 mods를 백업하고
새 게임 폴더에 옮겨야 할 수 있습니다.
