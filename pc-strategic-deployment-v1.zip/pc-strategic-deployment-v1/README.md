# Strategic Deployment AI v1 — PC

Target: `kilerjunny/Unciv` branch **`grand-strategy-formations`** (NOT Android `mobile-dev` or `master`).

## Behavior
- AI major civilizations in peace plan defensive garrisons (capital, borders, overseas cities, ports).
- Assign existing military units (land and naval separately) to capped city slots, every 5 turns.
- Movement only for assigned units; normal AI remains the fallback.
- Attack, healing, enemy-city pursuit, barbarian camps, and full wartime military behavior keep their original priority.
- No teleportation; uses `UnitMovement.canReach` and `headTowards`.
- Not for human units, civilians, air units, or nuclear units.
- No military-market dependency, new serialization fields, or UI changes.
- The existing `GrandStrategyAI.assess()` remains unchanged.

## Apply in Codespaces
Upload `pc-strategic-deployment-v1.zip` to the repository `grand-strategy-formations` branch, then from repo root:

```bash
git switch grand-strategy-formations
git pull --ff-only origin grand-strategy-formations
unzip -o pc-strategic-deployment-v1.zip -d /tmp
python3 /tmp/pc-strategic-deployment-v1/apply_pc_strategic_deployment_v1.py
git diff --check
./gradlew :core:compileKotlin --no-daemon
```

If build passes, commit:

```bash
git add core/src/com/unciv/logic/automation/unit/UnitAutomation.kt \
        core/src/com/unciv/logic/automation/civilization/StrategicDeploymentAI.kt
git rm --ignore-unmatch pc-strategic-deployment-v1.zip
git diff --cached --check
git commit -m "Add PC peacetime strategic deployment AI v1"
git push origin grand-strategy-formations
```

## Test
Back up a save; test 5+ peaceful turns with a multi-city AI empire, checking land garrisons at border cities and naval garrisons at ports. Start a war; normal combat behavior should resume. With no movement route, fallback to original AI.

## Notes
PC source is structurally different from Android. This patch intentionally doesn't use Android-specific `GrandStrategyPerf` or military-market code. Building/running in a full PC checkout is **not yet verified**.
