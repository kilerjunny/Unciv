# Unciv 모바일 AI 성능 개선 v1

적용 대상: `kilerjunny/Unciv`의 **`mobile-dev`** 브랜치. 기존 상단 탭/경제 모드 유지.

## 변경 사항

1. 특수 유닛(우주선 부품/개척자) 처리 시 전체 유닛 우선순위 정렬 대신, 해당 유닛만 정렬. 원래의 상대적 처리 순서 유지.
2. 호위할 개척자/위인이 없으면 비싼 유닛 이동 범위 탐색 생략. 호위 대상이 있을 때 선택 순서와 판단은 동일.
3. 적 도시 공략의 동일한 반경 4칸 후보 타일 계산을 근접 유닛당 반복하지 않고 한 번만 계산.
4. 경제 Dijkstra 경로 탐색 시 이미 확인한 주무역로 여부를 재사용하고 불필요한 Score 객체 할당 줄임. 경로 우선순위와 비용은 동일.
5. 기존 `성능 진단`에 `특수 이동 우선순위 정렬 대상`, `호위 대상 없음: 이동 경로 탐색 생략` 계측 추가.

## 설치

GitHub UI에서 ZIP을 `mobile-dev`에 업로드/커밋하고 Codespaces에서:

```sh
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o gs-performance-safe-v1.zip -d /tmp
python3 /tmp/gs-performance-safe-v1/apply_gs_performance_safe_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

빌드 성공 시:

```sh
git add core/src/com/unciv/logic/automation/civilization/NextTurnAutomation.kt \
        core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt \
        core/src/com/unciv/logic/automation/unit/UnitAutomation.kt \
        core/src/com/unciv/logic/market/WorldMarketEconomicRoutePlanner.kt
git rm gs-performance-safe-v1.zip
git commit -m "Avoid redundant AI path and priority work"
git push origin mobile-dev
```

## 테스트

같은 저장파일의 같은 턴에서 개선 전·후 `전체 턴 처리`, `유닛 AI`, `유닛 경로 탐색`, `경제 경로 탐색`, `성능 진단의 생략 횟수`, 가능하면 발열 수치를 비교. 유닛 이동/공략, 시장 구매, 무역 지도, 기존 저장파일 로드도 확인.

이 패치는 게임 데이터 형식이나 거래 계산을 바꾸지 않음. 성능 개선 폭은 실제 대규모 저장파일에서 확인 필요. 턴 진행이 난수·동일 저장 상태에 민감하므로 단일 턴 결과만으로 정확한 개선율 단정 금지.
