#!/usr/bin/env python3
"""Safe, idempotent source patch for Unciv mobile-dev.

All anchor checks happen in memory before writing any files; existing game rules,
AI relative dispatch priority, treasury settlements and save formats remain unchanged.
"""
from pathlib import Path
import sys

ROOT = Path.cwd()
SRC = Path('core/src/com/unciv')
MARKER = 'GS_AI_PERF_SAFE_V1'

FILES = {
    'logic/automation/civilization/NextTurnAutomation.kt': [
        (
            '''        GrandStrategyPerf.measure("unit_special_moves") {
            for (unit in unitsInPriorityOrder()) {
                // settlers need to move before automateSettlerEscorting(),
                // move spaceship parts before that to make sure we're not blocking them
                if (!unit.hasUnique(UniqueType.SpaceshipPart) && !unit.hasUnique(UniqueType.FoundCity)) continue
                if (!isStillOurUnit(unit, civInfo)) continue
                UnitAutomation.automateUnitMoves(unit)
            }
        }
''',
            '''        GrandStrategyPerf.measure("unit_special_moves") {
            // GS_AI_PERF_SAFE_V1: Sort only the units this pass can dispatch.
            // Filtering a stable priority sort preserves the original relative order,
            // including mods where a non-civilian has FoundCity.
            val specialUnits = unitsAtStart.asSequence()
                .filter { it.hasUnique(UniqueType.SpaceshipPart) || it.hasUnique(UniqueType.FoundCity) }
                .filterNot { MilitaryMarket.isReservedUnit(it) }
                .toList()
                .sortedBy { getUnitPriority(it, isAtWar) }
            GrandStrategyPerf.addCount("unit_special_candidates", specialUnits.size)
            for (unit in specialUnits) {
                // settlers need to move before automateSettlerEscorting(),
                // move spaceship parts before that to make sure we're not blocking them
                if (!isStillOurUnit(unit, civInfo)) continue
                UnitAutomation.automateUnitMoves(unit)
            }
        }
'''
        ),
        (
            '''        val meleeUnits = ourUnitsInRange(5).filter { it.baseUnit.isMelee() }
        for (unit in meleeUnits.sortedByDescending { it.baseUnit.getForceEvaluation() }) {
''',
            '''        val meleeUnits = ourUnitsInRange(5).filter { it.baseUnit.isMelee() }
        // GS_AI_PERF_SAFE_V1: The city's radius-4 geographic tile set is immutable
        // during this assault pass; calculate it once, not once for each melee unit.
        val tilesToTarget = if (meleeUnits.isEmpty()) emptyList()
            else city.getCenterTile().getTilesInDistance(4).toList()
        for (unit in meleeUnits.sortedByDescending { it.baseUnit.getForceEvaluation() }) {
'''
        ),
        (
            '''            val tilesToTarget = city.getCenterTile().getTilesInDistance(4).toList()
            
            val attackableEnemies''',
            '''            val attackableEnemies'''
        ),
    ],
    'logic/automation/unit/UnitAutomation.kt': [
        (
            '''    private fun tryAccompanySettlerOrGreatPerson(unit: MapUnit): Boolean {
        val distanceToTiles = unit.movement.getDistanceToTiles()
        val settlerOrGreatPersonToAccompany = unit.civ.units.getCivUnits()
            .firstOrNull {
                val tile = it.currentTile
                it.isCivilian() &&
                        (it.hasUnique(UniqueType.FoundCity) || it.isGreatPerson())
                        && !it.hasUnique(UniqueType.StrengthBonusInRadius) // Exlude great generals, as they move independently after all military units
                        && (tile == unit.currentTile || tile.militaryUnit == null && unit.movement.canMoveTo(tile))
                        && distanceToTiles.containsKey(tile)
            } ?: return false
''',
            '''    private fun tryAccompanySettlerOrGreatPerson(unit: MapUnit): Boolean {
        // GS_AI_PERF_SAFE_V1: The original search computed a full movement flood-fill
        // for every military unit even when there was no eligible civilian to escort.
        // Preserve the original unit ordering and tile/movement predicates.
        val candidates = unit.civ.units.getCivUnits().filter {
            it.isCivilian() &&
                (it.hasUnique(UniqueType.FoundCity) || it.isGreatPerson()) &&
                !it.hasUnique(UniqueType.StrengthBonusInRadius)
        }
        if (candidates.isEmpty()) {
            GrandStrategyPerf.addCount("unit_escort_paths_skipped", 1)
            return false
        }
        val distanceToTiles = unit.movement.getDistanceToTiles()
        val settlerOrGreatPersonToAccompany = candidates.firstOrNull {
            val tile = it.currentTile
            (tile == unit.currentTile || tile.militaryUnit == null && unit.movement.canMoveTo(tile)) &&
                distanceToTiles.containsKey(tile)
        } ?: return false
'''
        ),
    ],
    'logic/automation/civilization/GrandStrategyPerf.kt': [
        (
            '''        item("승급 처리", "unit_promotions")
        item("특수 유닛 이동", "unit_special_moves")
''',
            '''        item("승급 처리", "unit_promotions")
        item("특수 유닛 이동", "unit_special_moves")
        // GS_AI_PERF_SAFE_V1: only counters, not an additional timed phase.
        lines.add("특수 이동 우선순위 정렬 대상: ${result.counts["unit_special_candidates"] ?: 0}기")
        lines.add("호위 대상 없음: 이동 경로 탐색 ${result.counts["unit_escort_paths_skipped"] ?: 0}회 생략")
'''
        ),
    ],
    'logic/market/WorldMarketEconomicRoutePlanner.kt': [
        (
            '''                val nextMain = current.mainSteps +
                    (if (edge(current.tile.position, next.position) in main) 1 else 0)
''',
            '''                // GS_AI_PERF_SAFE_V1: Reuse the membership result from above.
                val nextMain = current.mainSteps + (if (isMain) 1 else 0)
'''
        ),
        (
            '''            if (best[current.tile] != Score(current.cost, current.mainSteps)) continue // stale queue entry
''',
            '''            // GS_AI_PERF_SAFE_V1: Avoid a temporary Score object per queue poll.
            val currentBest = best[current.tile]
            if (currentBest == null || currentBest.cost != current.cost ||
                currentBest.mainSteps != current.mainSteps) continue // stale queue entry
'''
        )
    ],
}


def transform(path: Path, rules):
    if not path.is_file():
        raise RuntimeError(f'Missing file: {path}. Run in the Unciv repository root on mobile-dev.')
    old = path.read_text(encoding='utf-8')
    # Each target file gets the marker when the patch is successfully installed.
    if MARKER in old:
        # Verify all target new anchors, so a partially applied file cannot silently pass.
        if all(new in old for _, new in rules):
            return old, False
        raise RuntimeError(f'Partial or conflicting {MARKER} code in {path}; no files changed.')
    new_text = old
    for before, after in rules:
        n = new_text.count(before)
        if n != 1:
            raise RuntimeError(f'Anchor expected once, found {n}: {path}: {before[:82]!r}; no files changed.')
        new_text = new_text.replace(before, after, 1)
    return new_text, new_text != old


def main():
    candidates = {}
    for relative, rules in FILES.items():
        path = ROOT / SRC / relative
        candidates[path] = transform(path, rules)
    modified = 0
    for path, (contents, changed) in candidates.items():
        if changed:
            path.write_text(contents, encoding='utf-8')
            print(f'PATCHED {path.relative_to(ROOT)}')
            modified += 1
        else:
            print(f'ALREADY APPLIED {path.relative_to(ROOT)}')
    print(f'GS AI safe performance v1 complete: {modified} files modified.')
    print('Next: git diff --check && ./gradlew :android:assembleDebug --no-daemon')


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError) as exc:
        print(f'PATCH FAILED: {exc}', file=sys.stderr)
        sys.exit(1)
