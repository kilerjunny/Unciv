#!/usr/bin/env python3
"""Apply observational virtual carrier network v1 on mobile-dev. Fail closed."""
from pathlib import Path
import sys

ROOT = Path.cwd()
BASE = Path(__file__).resolve().parent
NEW = ROOT / 'core/src/com/unciv/logic/market/WorldMarketVirtualCarriers.kt'
UI = ROOT / 'core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt'
ACTOR = ROOT / 'core/src/com/unciv/ui/screens/overviewscreen/WorldMarketRouteMapActor.kt'
MARK = 'GS_VIRTUAL_MERCHANT_NETWORK_V1'


def replace_unique(text, old, new, label):
    found = text.count(old)
    if found != 1:
        raise RuntimeError(f'{label}: expected one anchor; found {found}')
    return text.replace(old, new, 1)


def patch_ui(s):
    s = replace_unique(s,
        'import com.unciv.logic.market.WorldMarketMainRoutes\n',
        'import com.unciv.logic.market.WorldMarketMainRoutes\nimport com.unciv.logic.market.WorldMarketVirtualCarriers\n', 'ui import')
    s = replace_unique(s,
        '    private var tradeMapMainOnly = false // GS_WORLD_MAIN_ROUTES_V1\n',
        '    private var tradeMapMainOnly = false // GS_WORLD_MAIN_ROUTES_V1\n'
        '    private var tradeMapCarrierView = false // GS_VIRTUAL_MERCHANT_NETWORK_V1\n', 'ui state')
    s = replace_unique(s,
        '                tradeMapMainOnly = !tradeMapMainOnly\n                render()\n',
        '                tradeMapMainOnly = !tradeMapMainOnly\n'
        '                if (tradeMapMainOnly) tradeMapCarrierView = false\n'
        '                render()\n', 'ui main-only toggle')
    s = replace_unique(s,
        '            add(mainOnlyButton).left().row()\n\n            val knownIds',
        '''            add(mainOnlyButton).left().row()
            // GS_VIRTUAL_MERCHANT_NETWORK_V1: display only; no new routes or units.
            val carrierButton = TextButton(
                if (tradeMapCarrierView) "가상 상선망 ✓" else "가상 상선망 보기", BaseScreen.skin
            )
            carrierButton.onClick {
                tradeMapCarrierView = !tradeMapCarrierView
                if (tradeMapCarrierView) tradeMapMainOnly = false
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            add(carrierButton).left().row()

            val knownIds''', 'ui carrier toggle')
    s = replace_unique(s,
        '            add(WorldMarketRouteMapActor(game, viewer, spectator, visible, tradeMapLowPower, mainRoutes))\n',
        '            add(WorldMarketRouteMapActor(game, viewer, spectator, visible, tradeMapLowPower, mainRoutes, tradeMapCarrierView))\n',
        'ui map invocation')
    s = replace_unique(s,
        '            add("육로: 노랑 · 항로: 하늘색 · 복합: 분홍 · 세계 주무역로: 굵은 연두색".toLabel(hideIcons = true))\n',
        '''            val routeLegend = if (tradeMapCarrierView)
                "육상 상단: 노랑 · 연안 상선: 연한 파랑 · 원양 상선: 하늘색 · 환적: 분홍 · 주무역로: 연두색"
            else "육로: 노랑 · 항로: 하늘색 · 복합: 분홍 · 세계 주무역로: 굵은 연두색"
            add(routeLegend.toLabel(hideIcons = true))
''', 'ui legend')
    s = replace_unique(s,
        '        if (historyOpen) {\n            val game = playerView.getCiv().gameInfo\n            val records = WorldMarketHistory.recent(game)\n',
        '''        if (historyOpen) {
            val game = playerView.getCiv().gameInfo
            val records = WorldMarketHistory.recent(game)
            // GS_VIRTUAL_MERCHANT_NETWORK_V1: calculate once on tab opening.
            val backbone = WorldMarketVirtualCarriers.mainEdges(
                WorldMarketMainRoutes.select(game, WorldMarketRouteStats.windowRows(game))
            )
''', 'ui history setup')
    s = replace_unique(s,
        '''                    if (it.estimatedTransportCost >= 0)
                        add("추정 운송지수: ${it.estimatedTransportCost} (최단거리 아닌 최소 운송비)".toLabel(hideIcons = true)).left().row()
''',
        '''                    if (it.estimatedTransportCost >= 0)
                        add("추정 운송지수: ${it.estimatedTransportCost} (최단거리 아닌 최소 운송비)".toLabel(hideIcons = true)).left().row()
                    // GS_VIRTUAL_MERCHANT_NETWORK_V1: classification of recorded legs.
                    if (it.routeTiles.size >= 2) {
                        val legs = WorldMarketVirtualCarriers.summarize(game, it.routeTiles, backbone)
                        add("가상 운송 구간: 원양 ${legs.ocean} · 연안 ${legs.coast} · 육상 ${legs.land} · 환적 ${legs.transfers}".toLabel(hideIcons = true)).left().row()
                        add("현재 세계 주무역로 ${legs.main}칸 · 지선 ${legs.branches}칸".toLabel(hideIcons = true)).left().row()
                    }
''', 'ui history report')
    return s


def patch_actor(s):
    s = replace_unique(s,
        'import com.unciv.logic.market.MarketRouteStat\n',
        'import com.unciv.logic.market.MarketRouteStat\nimport com.unciv.logic.market.WorldMarketVirtualCarriers\n', 'actor import')
    s = replace_unique(s,
        '    mainRoutes: List<MainTradeCorridor> = emptyList(), // GS_WORLD_MAIN_ROUTES_V1\n',
        '    mainRoutes: List<MainTradeCorridor> = emptyList(), // GS_WORLD_MAIN_ROUTES_V1\n'
        '    private val carrierView: Boolean = false, // GS_VIRTUAL_MERCHANT_NETWORK_V1\n', 'actor constructor')
    s = replace_unique(s,
        '    private val mainPath = Color(0.48f, 1f, 0.55f, 1f)\n',
        '    private val mainPath = Color(0.48f, 1f, 0.55f, 1f)\n'
        '    private val coastalCarrier = Color(0.72f, 0.88f, 1f, 1f)\n', 'actor color')
    s = replace_unique(s,
        '''                val ordered = a.x < b.x || (a.x == b.x && a.y <= b.y)
                val key = if (ordered) EdgeKey(route.routeMode, a, b)
                    else EdgeKey(route.routeMode, b, a)
                val existing = edges[key]
                if (existing == null) {
                    edges[key] = PaintedRoute(
                        route.routeMode, route.tradeCount.coerceAtLeast(1),
''',
        '''                // GS_VIRTUAL_MERCHANT_NETWORK_V1: color by tile water class.
                val type = if (carrierView) WorldMarketVirtualCarriers.mode(tileA, tileB) else route.routeMode
                val ordered = a.x < b.x || (a.x == b.x && a.y <= b.y)
                val key = if (ordered) EdgeKey(type, a, b)
                    else EdgeKey(type, b, a)
                val existing = edges[key]
                if (existing == null) {
                    edges[key] = PaintedRoute(
                        type, route.tradeCount.coerceAtLeast(1),
''', 'actor route classify')
    s = replace_unique(s,
        '''            batch.color = when (route.type) {
                "LAND" -> landPath
                "SEA" -> seaPath
                else -> mixedPath
            }
''',
        '''            batch.color = when (route.type) {
                "LAND", WorldMarketVirtualCarriers.LAND -> landPath
                "SEA", WorldMarketVirtualCarriers.OCEAN -> seaPath
                WorldMarketVirtualCarriers.COAST -> coastalCarrier
                else -> mixedPath
            }
''', 'actor draw colors')
    return s


def main():
    try:
        if not UI.is_file() or not ACTOR.is_file():
            raise RuntimeError('Run from repository root /workspaces/Unciv')
        if NEW.exists():
            raise RuntimeError('New Kotlin file already exists; patch may already be applied')
        raw_ui, raw_actor = UI.read_text(encoding='utf-8'), ACTOR.read_text(encoding='utf-8')
        if MARK in raw_ui or MARK in raw_actor:
            raise RuntimeError('Patch already applied or incomplete; no changes made')
        updated_ui, updated_actor = patch_ui(raw_ui), patch_actor(raw_actor)
        new_source = (BASE / 'WorldMarketVirtualCarriers.kt').read_text(encoding='utf-8')
        assert 'object WorldMarketVirtualCarriers' in new_source
        # All anchors must match before ANY files are written.
        UI.write_text(updated_ui, encoding='utf-8')
        ACTOR.write_text(updated_actor, encoding='utf-8')
        NEW.write_text(new_source, encoding='utf-8')
        print('GS virtual merchant network v1 applied to mobile-dev (3 Kotlin files).')
    except Exception as e:
        print(f'PATCH STOPPED: {e}', file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
