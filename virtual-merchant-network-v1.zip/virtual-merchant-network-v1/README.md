# Grand Strategy — Virtual Merchant Network v1

Target branch: **mobile-dev**, after Production City → Buyer Capital v1.

This is an **observational/visualization-only** stage. No new merchant unit is spawned, no cargo travels, and existing immediate gold/resource settlement is unchanged.

## Contents
- `WorldMarketVirtualCarriers.kt`: classify each **existing** trade route's tile edges into ocean merchant, coastal merchant, inland caravan, port transfer. Separately count edges belonging to **current** global main corridors vs feeder branches.
- `WorldMarketTradeSection.kt`: `가상 상선망 보기` switch on trade-map panel, with updated legend; trade history shows leg breakdown + current global trunk/branch counts.
- `WorldMarketRouteMapActor.kt`: color existing recorded path edges according to virtual carriers when in carrier view. Draw workload is still bounded by current map settings. Main trade corridors retain their green highlight and exploration visibility.
- **Not implemented**: true fleet movement, freight capacity, customs, blockades, insurance, resource delivery, or shipments to buyers. Ordinary routes still use existing economic pathfinder and world market settlement.

## Setup
1. On GitHub, switch to **mobile-dev** and upload `virtual-merchant-network-v1.zip` via Add file > Upload files > Commit changes.
2. Codespaces shell, from repo root:
```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o virtual-merchant-network-v1.zip -d /tmp
python3 /tmp/virtual-merchant-network-v1/apply_virtual_merchant_network_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```
3. If BUILD SUCCESSFUL:
```bash
git add core/src/com/unciv/logic/market/WorldMarketVirtualCarriers.kt
git add core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git add core/src/com/unciv/ui/screens/overviewscreen/WorldMarketRouteMapActor.kt
git rm virtual-merchant-network-v1.zip
git commit -m "Add virtual ocean coastal and land merchant network view"
git push origin mobile-dev
```
4. GitHub Actions androidBuild.yml > Run workflow > mobile-dev > download APK.

## Test checklist
1. Overview > Trading > World Market > Trade Map > `가상 상선망 보기`: different colors for ocean/coast/land/port transfers; green global main routes stay visible.
2. Trading History: `가상 운송 구간` and `현재 세계 주무역로 / 지선` counts for recorded routes. Old routes can also display counts, based on the current map.
3. Check market, trading, AI and turns unchanged. Android heat/perf.

This version does NOT increase the number of pathfinding calls per turn; summary computes from existing routeTiles only when opening a tab. If GitHub's upload created a tracked ZIP, remove it at the indicated `git rm` step.
