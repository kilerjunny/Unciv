#!/usr/bin/env python3
"""Maritime World v1 patch for kilerjunny/Unciv mobile-dev.

Run in a clean Codespaces checkout. Only edits 4 exact source files;
verifies all anchors before writing to avoid partial application.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess
import sys

MARKER = "GS_MARITIME_WORLD_V1"
REPO_FILES = [
    "core/src/com/unciv/logic/map/MapParameters.kt",
    "core/src/com/unciv/logic/map/mapgenerator/MapLandmassGenerator.kt",
    "core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt",
    "core/src/com/unciv/logic/map/mapgenerator/mapregions/RegionStartFinder.kt",
]


def replace_once(src: str, old: str, new: str, filename: str) -> str:
    found = src.count(old)
    if found != 1:
        raise RuntimeError(f"{filename}: expected one anchor, got {found}: {old[:75]!r}")
    return src.replace(old, new, 1)


def patch_params(s: str) -> str:
    f = "MapParameters.kt"
    s = replace_once(s,
        '    const val continentAndIslands = "Continent and Islands"\n',
        '    const val continentAndIslands = "Continent and Islands"\n'
        '    // GS_MARITIME_WORLD_V1: opt-in naval-focused generator; existing maps unchanged.\n'
        '    const val maritimeContinents = "Maritime Continents"\n', f)
    s = replace_once(s,
        '        continentAndIslands,\n',
        '        continentAndIslands,\n        maritimeContinents,\n', f)
    return s


MARITIME_METHODS = r'''    /**
     * GS_MARITIME_WORLD_V1
     * Continent-and-islands geography, deterministic 65% water coverage at the
     * landmass stage, plus bounded small-island and narrow-strait edits.
     * The original map types and their RNG sequences are not changed.
     * This runs once when creating a map, NEVER during game turns.
     */
    private fun createMaritimeContinents() {
        val isNorth = randomness.RNG.nextDouble() < 0.5
        val isLatitude = if (tileMap.mapParameters.shape == MapShape.hexagonal ||
            tileMap.mapParameters.shape == MapShape.flatEarth)
            randomness.RNG.nextDouble() > 0.5
        else if (tileMap.mapParameters.mapSize.height > tileMap.mapParameters.mapSize.width) true
        else if (tileMap.mapParameters.mapSize.width > tileMap.mapParameters.mapSize.height) false
        else randomness.RNG.nextDouble() > 0.5

        val elevationSeed = randomness.RNG.nextInt().toDouble()
        val detailSeed = randomness.RNG.nextInt().toDouble()
        val elevations = tileMap.values.map { tile ->
            val broad = randomness.getPerlinNoise(tile, elevationSeed)
            val mass = getContinentAndIslandsTransform(tile, isNorth, isLatitude)
            val detail = getRidgedPerlinNoise(tile, detailSeed, nOctaves = 4, scale = 17.0)
            val value = broad * 0.46 + mass * 0.48 + detail * 0.06 +
                getOceanEdgesTransform(tile) * 0.12
            tile to value
        }.sortedBy { it.second }

        // Sorting is stable: ties retain TileMap iteration order, and a fixed
        // seed + parameters yield the same landmass on repeated generation.
        // The existing advanced Water level slider remains meaningful:
        // -0.1 means about 55% water, +0.1 about 75% (65% by default).
        val waterRatio = (0.65 + tileMap.mapParameters.waterThreshold.toDouble()).coerceIn(0.55, 0.75)
        val targetWater = (elevations.size * waterRatio).toInt()
        for ((index, entry) in elevations.withIndex())
            entry.first.baseTerrain = if (index < targetWater) waterTerrainName else landTerrainName

        val newIslands = addMaritimeIslandChains()
        carveMaritimeStraits(newIslands)
    }

    /** Bounded 4-tile island groups, generally within five tiles of existing land. */
    private fun addMaritimeIslandChains(): Set<Tile> {
        val createdIslands = HashSet<Tile>()
        val budget = (tileMap.values.size / 320).coerceAtMost(160)
        if (budget < 4) return createdIslands

        val candidates = tileMap.values.filter { it.baseTerrain == waterTerrainName }
            .shuffled(randomness.RNG)
        for (center in candidates) {
            if (createdIslands.size + 4 > budget) break
            if (center.baseTerrain != waterTerrainName) continue
            val neighbors = center.neighbors.toList()
            if (neighbors.size != 6 || neighbors.any { it.baseTerrain != waterTerrainName }) continue
            if (center.getTilesInDistance(5).none { it.baseTerrain == landTerrainName }) continue

            // Compact groups give a better settlement opportunity than isolated
            // single-tile islands, without blocking a full ocean corridor.
            val group = listOf(center) + neighbors.shuffled(randomness.RNG).take(3)
            for (tile in group) {
                tile.baseTerrain = landTerrainName
                createdIslands.add(tile)
            }
        }
        return createdIslands
    }

    /** Open a few one-tile land bridges into potential straits or inlets. */
    private fun carveMaritimeStraits(protectedIslands: Set<Tile>) {
        val maxCuts = (tileMap.values.size / 500).coerceAtMost(90)
        if (maxCuts <= 0) return
        val cuts = HashSet<Tile>()
        val candidates = tileMap.values.filter { it.baseTerrain == landTerrainName && it !in protectedIslands }
            .shuffled(randomness.RNG)
        for (tile in candidates) {
            if (cuts.size >= maxCuts) break
            if (tile.neighbors.count() != 6 || tile.neighbors.any { it in cuts }) continue
            val waterSides = tile.neighbors.filter { it.baseTerrain == waterTerrainName }.toList()
            if (waterSides.size !in 2..4) continue
            // Water on two non-adjacent sides makes this a narrow neck, rather
            // than converting long segments of ordinary coastline into water.
            val spansNeck = waterSides.any { first ->
                waterSides.any { second -> first != second && first.aerialDistanceTo(second) >= 2 }
            }
            if (!spansNeck) continue
            tile.baseTerrain = waterTerrainName
            cuts.add(tile)
        }
    }

'''


def patch_landmass(s: str) -> str:
    f = "MapLandmassGenerator.kt"
    s = replace_once(s,
        '            MapType.continentAndIslands -> createContinentAndIslands()\n',
        '            MapType.continentAndIslands -> createContinentAndIslands()\n'
        '            MapType.maritimeContinents -> createMaritimeContinents()\n', f)
    s = replace_once(s,
        '    private fun createTwoContinents() {',
        MARITIME_METHODS + '    private fun createTwoContinents() {', f)
    return s


def patch_regions(s: str) -> str:
    f = "MapRegions.kt"
    s = replace_once(s,
        'import com.unciv.logic.map.MapShape\n',
        'import com.unciv.logic.map.MapShape\nimport com.unciv.logic.map.MapType\n', f)
    old = '''        val sortedRegions = regions.sortedBy { it.totalFertility }
        for (region in sortedRegions) RegionStartFinder.findStart(region, tileData)
'''
    new = '''        val sortedRegions = regions.sortedBy { it.totalFertility }
        // GS_MARITIME_WORLD_V1: aim for >=85% ocean-coastal capitals, without
        // forcing invalid start sites. We count successful coastal starts rather
        // than reserving a fixed number of regions that might lack coast.
        val maritime = tileMap.mapParameters.type == MapType.maritimeContinents
        val desiredCoastalStarts = if (maritime) (sortedRegions.size * 85 + 99) / 100 else 0
        var coastalStarts = 0
        for (region in sortedRegions) {
            RegionStartFinder.findStart(region, tileData,
                preferCoast = maritime && coastalStarts < desiredCoastalStarts)
            if (maritime && tileMap[region.startPosition!!].isAdjacentToCoast()) coastalStarts++
        }
'''
    s = replace_once(s, old, new, f)
    return s


COAST_START = r'''    /**
     * GS_MARITIME_WORLD_V1: prefer viable coastal capitals in the maritime
     * preset, but retain original fertility, spacing and inland fallback.
     * Called only during map creation, and never for other map types.
     */
    private fun tryFindMaritimeCoast(region: Region, tileData: TileDataMap): Boolean {
        var best: Tile? = null
        var bestScore = Int.MIN_VALUE
        for (tile in region.tileMap.getTilesInRectangle(region.rect)) {
            if (!tile.isLand || tile.isImpassible() || !tile.isAdjacentToCoast()) continue
            if (region.continentID != -1 && region.continentID != tile.getContinent()) continue
            val data = tileData[tile] ?: continue
            evaluateTileForStart(tile, tileData)
            if (!data.isGoodStart || data.closeStartPenalty > 0) continue
            if (data.startScore > bestScore) {
                best = tile
                bestScore = data.startScore
            }
        }
        val chosen = best ?: return false
        setRegionStart(region, chosen.position, tileData)
        return true
    }

'''


def patch_start(s: str) -> str:
    f = "RegionStartFinder.kt"
    s = replace_once(s,
        '    internal fun findStart(region: Region, tileData: TileDataMap) {\n',
        '    internal fun findStart(region: Region, tileData: TileDataMap, preferCoast: Boolean = false) {\n'
        '        if (preferCoast && tryFindMaritimeCoast(region, tileData)) return\n', f)
    s = replace_once(s,
        '    private fun findGoodPosition(centerTiles: Set<Tile>, region: Region, tileData: TileDataMap, fallbackTiles: HashSet<Tile>): Boolean {',
        COAST_START + '    private fun findGoodPosition(centerTiles: Set<Tile>, region: Region, tileData: TileDataMap, fallbackTiles: HashSet<Tile>): Boolean {', f)
    return s


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='check anchors without modifying files')
    args = parser.parse_args()

    here = Path.cwd()
    try:
        current = subprocess.run(['git', 'branch', '--show-current'], cwd=here,
                                 capture_output=True, text=True, check=True).stdout.strip()
        if current != 'mobile-dev':
            raise RuntimeError(f"Expected 'mobile-dev' branch, got {current!r}")
        paths = [here / p for p in REPO_FILES]
        originals = {}
        for path in paths:
            if not path.is_file():
                raise RuntimeError(f'Missing source file: {path}')
            originals[path] = path.read_text(encoding='utf-8')

        if all(MARKER in originals[path] for path in paths):
            print('Maritime World v1 is already applied. No files changed.')
            return
        if any(MARKER in originals[path] for path in paths):
            raise RuntimeError('Partial Maritime World patch found; inspect git diff before retrying.')

        transformers = [patch_params, patch_landmass, patch_regions, patch_start]
        updates = {p: fn(originals[p]) for p, fn in zip(paths, transformers)}
        if args.check:
            print('OK: all four source files and anchors verified; no changes made.')
            return
        for path, value in updates.items():
            path.write_text(value, encoding='utf-8')
            print('Patched:', path.relative_to(here))
        print('Maritime World v1 code applied. Build Android APK and test new-map generation.')
    except (RuntimeError, OSError, subprocess.CalledProcessError) as error:
        print('ERROR:', error, file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
