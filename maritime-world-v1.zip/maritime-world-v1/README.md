# Grand Strategy — Maritime World v1

Target: `kilerjunny/Unciv`, branch `mobile-dev` (verified baseline commit `d169b36be7d08762883d4a74e1da7e42b3f4c149`).

## What is implemented

* New opt-in map type `Maritime Continents` in the new-game map-type picker.
* Existing `Continent and Islands`-inspired landmass generation: base elevation is ranked so **65% of tiles start as water** at default Water level. Existing advanced Water level setting shifts the target by up to approximately ±10 percentage points.
* Medium island density: at most `min(tiles / 320, 160)` new land tiles in compact 4-tile islands, generally near existing land.
* Medium strait density: at most `min(tiles / 500, 90)` narrow land-neck openings (one tile per opening), with adjacency limits to avoid chains of excavated tiles.
* Maritime starting locations: tries valid coastal starts until **85%** of major-civilization starting regions have coastal start positions. Existing food/production and start spacing requirements remain in force; where there is no valid coast, the stock inland fallback is used.
* No new saved fields; does not touch rulesets, world market, battle AI or existing maps. No per-turn map generation processing.

### Important limitations

* `65%` is a target for **initial terrain**. Island and strait changes are small and may shift the ratio slightly, as may special Flat Earth edge handling. For map types lacking valid water tiles (land-only rulesets), the existing land-only fallback takes precedence.
* `85%` is a **target**, not guaranteed: fertility, land size, spacing and the availability of coast can reduce it. Existing coastal start biases are still respected during civilization-to-region assignment.
* The number of major continents and genuinely strategic, navigable straits is **not guaranteed** yet. v2 should measure navigability, chokepoint importance and link sea chokepoints to trade routes. v1 does not create new gameplay toll mechanics or resource biases.
* **No Android full build or in-game integration test was run by this patch author.** The Kotlin landmass logic passed an isolated mock compile and 12,000-tile simulation; the patch installer passed synthetic fixture checks. These do not substitute for a real Unciv build.

## Install (Codespaces)

1. Upload `maritime-world-v1.zip` to the repository root on `mobile-dev`.
2. In Codespaces:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o maritime-world-v1.zip -d /tmp
python3 /tmp/maritime-world-v1/apply_maritime_world_v1.py --check
python3 /tmp/maritime-world-v1/apply_maritime_world_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

3. Only after `BUILD SUCCESSFUL`:

```bash
git add core/src/com/unciv/logic/map/MapParameters.kt
git add core/src/com/unciv/logic/map/mapgenerator/MapLandmassGenerator.kt
git add core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt
git add core/src/com/unciv/logic/map/mapgenerator/mapregions/RegionStartFinder.kt
git rm --ignore-unmatch maritime-world-v1.zip
git diff --cached --check
git commit -m "Add Maritime Continents map generator v1"
git push origin mobile-dev
```

4. Run your usual GitHub Actions APK workflow on the updated commit, download and install the new APK.
5. **Create a new game**, select Map Type → `Maritime Continents`, then verify a few seeds. Changes do **not** regenerate any ongoing saved game's map.

### Suggested test matrix

* Small, Medium, and Large maps; 3–5 seeds per size.
* Start with the default `Water level` (= 0) to check ~65% water.
* For high-civ-count custom maps, verify no uninhabitable/invalid starts and that naval bases and trade routes are navigable.
* Test `worldWrap` enabled/disabled; check narrow land bridges and new islands on the map.
* Confirm all older map types still generate and previously saved games still load.
* Record map-generation time and then compare turn-processing time on *identical* map sizes and settings (not between different games).

### Reverting

Before pushing, `git restore` the four edited Kotlin files. After pushing, revert the specific commit; do not delete save data.

### Files in the archive

* `apply_maritime_world_v1.py`: safe branch/anchor-checked installer (`--check` mode and idempotence guard).
* `selftest_patch.py`: synthetic installer test.
* `standalone_maritime_mock.kt`: isolated landmass Kotlin compilation / mock-water-ratio test (not a real Unciv build).
