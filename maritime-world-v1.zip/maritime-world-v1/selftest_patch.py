#!/usr/bin/env python3
"""Self-contained patch smoke test (synthetic Kotlin anchors; not Android build)."""
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
PATCHER = ROOT / 'apply_maritime_world_v1.py'

files = {
 'core/src/com/unciv/logic/map/MapParameters.kt':
 '''object MapType {
    const val continentAndIslands = "Continent and Islands"
    val allValues = listOf(
        continentAndIslands,
    )
}
''',
 'core/src/com/unciv/logic/map/mapgenerator/MapLandmassGenerator.kt':
 '''class MapLandmassGenerator {
    fun generateLand() {
      when (type) {
            MapType.continentAndIslands -> createContinentAndIslands()
      }
    }
    private fun createTwoContinents() { }
}
''',
 'core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt':
 '''import com.unciv.logic.map.MapShape
class MapRegions {
  fun assignRegions() {
        val sortedRegions = regions.sortedBy { it.totalFertility }
        for (region in sortedRegions) RegionStartFinder.findStart(region, tileData)
  }
}
''',
 'core/src/com/unciv/logic/map/mapgenerator/mapregions/RegionStartFinder.kt':
 '''object RegionStartFinder {
    internal fun findStart(region: Region, tileData: TileDataMap) {
    }
    private fun findGoodPosition(centerTiles: Set<Tile>, region: Region, tileData: TileDataMap, fallbackTiles: HashSet<Tile>): Boolean { return false }
}
'''
}
with tempfile.TemporaryDirectory() as temp:
  root = Path(temp)
  subprocess.run(['git','init','-q','-b','mobile-dev'], cwd=root, check=True)
  for filename, source in files.items():
    dest = root/filename
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(source)
  def run(*args):
    return subprocess.run(['python3',str(PATCHER),*args],cwd=root,capture_output=True,text=True)
  check=run('--check')
  assert check.returncode == 0, check.stderr
  assert 'no changes' in check.stdout
  for f,src in files.items(): assert (root/f).read_text()==src
  apply=run()
  assert apply.returncode == 0, apply.stderr
  for f in files:
    assert 'GS_MARITIME_WORLD_V1' in (root/f).read_text(), f
  again=run()
  assert again.returncode == 0 and 'already applied' in again.stdout, (again.stdout,again.stderr)
  wrong=subprocess.run(['git','switch','-q','-c','wrong-branch'],cwd=root,capture_output=True,text=True)
  assert wrong.returncode==0
  denied=run()
  assert denied.returncode!=0 and 'Expected' in denied.stderr
  print('PASS patch anchors, check mode, marker coverage, idempotency, branch guard')
