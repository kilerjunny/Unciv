#!/usr/bin/env python3
"""Apply Unciv GS trade map MVP to feature/trade-route-multimodal-v2.
Run at the repository root. Idempotent: markers prevent double application.
"""
from pathlib import Path

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent


def patch(path: str, replacements: list[tuple[str, str]], marker: str):
    target = ROOT / path
    if not target.is_file():
        raise SystemExit(f"Missing expected source: {path}. Select the v2 branch first.")
    text = target.read_text(encoding='utf-8-sig')
    if marker in text:
        print(f"Already patched: {path}")
        return
    for old, new in replacements:
        found = text.count(old)
        if found != 1:
            raise SystemExit(f"Refusing unsafe patch: {path}: expected 1 anchor, got {found}: {old[:90]!r}")
        text = text.replace(old, new, 1)
    target.write_text(text, encoding='utf-8')
    print(f"Patched: {path}")


def add(path: str):
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    source = HERE / target.name
    content = source.read_text(encoding='utf-8')
    if target.is_file() and target.read_text(encoding='utf-8') == content:
        print(f"Already installed: {path}")
        return
    if target.exists():
        raise SystemExit(f"Refusing to overwrite different file: {path}")
    target.write_text(content, encoding='utf-8')
    print(f"Added: {path}")


MARKER = 'GS_TRADE_MAP_SPEED_V1'

patch('core/src/com/unciv/logic/GameInfo.kt', [
    ('import com.unciv.logic.market.MarketTradeRecord\n',
     'import com.unciv.logic.market.MarketTradeRecord\nimport com.unciv.logic.market.MarketRouteStat\n'),
    ('    var worldMarketHistory = ArrayList<MarketTradeRecord>()\n',
     '    var worldMarketHistory = ArrayList<MarketTradeRecord>()\n'
     '    // GS_TRADE_MAP_SPEED_V1: persistent, bounded traffic summary\n'
     '    var worldMarketRouteStats = ArrayList<MarketRouteStat>()\n'
     '    var worldMarketRouteLifetime = ArrayList<MarketRouteStat>()\n'
     '    var worldMarketStatsInitialized = false\n'
     '    var worldMarketRouteLifetimeTruncated = false\n'),
    ('        toReturn.worldMarketHistory.addAll(worldMarketHistory.takeLast(100).map { it.copy() })\n',
     '        toReturn.worldMarketHistory.addAll(worldMarketHistory.takeLast(100).map { it.copy() })\n'
     '        toReturn.worldMarketRouteStats.addAll(worldMarketRouteStats.map { it.copy(routeTiles = ArrayList(it.routeTiles)) })\n'
     '        toReturn.worldMarketRouteLifetime.addAll(worldMarketRouteLifetime.map { it.copy(routeTiles = ArrayList(it.routeTiles)) })\n'
     '        toReturn.worldMarketStatsInitialized = worldMarketStatsInitialized\n'
     '        toReturn.worldMarketRouteLifetimeTruncated = worldMarketRouteLifetimeTruncated\n'),
], MARKER)

patch('core/src/com/unciv/logic/market/WorldMarketHistory.kt', [
    ('        val items = seller.gameInfo.worldMarketHistory\n',
     '        // GS_TRADE_MAP_SPEED_V1: recover any remaining old history once per save.\n'
     '        WorldMarketRouteStats.initializeIfNeeded(seller.gameInfo)\n'
     '        val items = seller.gameInfo.worldMarketHistory\n'),
    ('        items.add(item)\n',
     '        items.add(item)\n'
     '        WorldMarketRouteStats.record(seller.gameInfo, item)\n'),
], MARKER)

ui_path = 'core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt'
map_body = '''        // GS_TRADE_MAP_SPEED_V1: geographic summary; never runs the route planner.
        if (tradeMapOpen) {
            val viewer = playerView.getCiv()
            val game = viewer.gameInfo
            val spectator = playerView.isSpectator()
            val window = WorldMarketRouteStats.windowTurns(game)
            val scopeButton = TextButton(if (tradeMapOnlyMine) "내 거래만 ✓" else "전체 국가", BaseScreen.skin)
            scopeButton.onClick {
                tradeMapOnlyMine = !tradeMapOnlyMine
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            val periodButton = TextButton(if (tradeMapLifetime) "기록 전체" else "최근 ${window}턴", BaseScreen.skin)
            periodButton.onClick {
                tradeMapLifetime = !tradeMapLifetime
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            val modeButton = TextButton(when (tradeMapMode) {
                "LAND" -> "육로만"
                "SEA" -> "항로만"
                "MIXED" -> "복합만"
                else -> "모든 경로"
            }, BaseScreen.skin)
            modeButton.onClick {
                tradeMapMode = when (tradeMapMode) {
                    "ALL" -> "LAND"
                    "LAND" -> "SEA"
                    "SEA" -> "MIXED"
                    else -> "ALL"
                }
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            val switches = Table(BaseScreen.skin)
            switches.add(periodButton).padRight(5f)
            switches.add(scopeButton).padRight(5f)
            switches.add(modeButton)
            add(switches).left().row()

            val knownIds = viewer.getKnownCivs().map { it.civID }.toSet() + viewer.civID
            val entries = (if (tradeMapLifetime) WorldMarketRouteStats.lifetimeRows(game)
                else WorldMarketRouteStats.windowRows(game))
                .filter { row ->
                    (spectator || (row.sellerCivId in knownIds && row.buyerCivId in knownIds)) &&
                    (!tradeMapOnlyMine || row.sellerCivId == viewer.civID || row.buyerCivId == viewer.civID) &&
                    (tradeMapMode == "ALL" || row.routeMode == tradeMapMode)
                }
                .sortedByDescending { it.tradeCount }
            val visible = entries.take(60)
            val summary = "거래 ${entries.sumOf { it.tradeCount }}건 · 물동량 ${entries.sumOf { it.quantity }}개 · " +
                "교역로 ${entries.size}개 집계 항목 (최대 60개 경로 표시)"
            add(summary.toLabel(hideIcons = true)).left().growX().row()
            if (game.worldMarketRouteLifetimeTruncated && tradeMapLifetime)
                add("전체 누적 통계는 경로 400개 보존 제한으로 일부 누락되었습니다.".toLabel(hideIcons = true))
                    .left().growX().row()
            if (entries.isEmpty())
                add("표시할 무역로가 없습니다. 신규 세계 시장 거래 이후 기록됩니다.".toLabel(hideIcons = true))
                    .left().growX().row()
            val mapWidth = (parentTab.overviewScreen.stage.width - 65f).coerceIn(320f, 1100f)
            val mapHeight = (mapWidth * 0.54f).coerceIn(220f, 520f)
            add(WorldMarketRouteMapActor(game, viewer, spectator, visible))
                .width(mapWidth).height(mapHeight).left().row()
            add("육로: 노랑 · 항로: 하늘색 · 복합: 분홍 · 선 굵기: 거래 횟수".toLabel(hideIcons = true))
                .left().growX().row()
            add("탐험한 지도 칸만 표시하며, 과거 저장파일은 최근 거래 100건부터 복원됩니다.".toLabel(hideIcons = true))
                .left().growX().row()
            return
        }

'''
patch(ui_path, [
    ('import com.unciv.logic.market.WorldMarketHistory\n',
     'import com.unciv.logic.market.WorldMarketHistory\nimport com.unciv.logic.market.WorldMarketRouteStats\n'),
    ('    private var militaryMarketOpen = false\n',
     '    private var militaryMarketOpen = false\n'
     '    private var tradeMapOpen = false\n'
     '    private var tradeMapOnlyMine = false\n'
     '    private var tradeMapLifetime = false\n'
     '    private var tradeMapMode = "ALL"\n'),
    ('        val historyButton = TextButton(if (historyOpen)',
     '        val tradeMapButton = TextButton(if (tradeMapOpen) "시장 보기" else "무역 지도", BaseScreen.skin)\n'
     '        tradeMapButton.onClick {\n'
     '            tradeMapOpen = !tradeMapOpen\n'
     '            if (tradeMapOpen) { historyOpen = false; performanceOpen = false; militaryMarketOpen = false }\n'
     '            render()\n'
     '            parentTab.overviewScreen.resizePage(parentTab)\n'
     '        }\n'
     '        add(tradeMapButton).left().row()\n\n'
     '        val historyButton = TextButton(if (historyOpen)'),
    ('            if (historyOpen) { performanceOpen = false; militaryMarketOpen = false }\n',
     '            if (historyOpen) { performanceOpen = false; militaryMarketOpen = false; tradeMapOpen = false }\n'),
    ('            if (performanceOpen) { historyOpen = false; militaryMarketOpen = false }\n',
     '            if (performanceOpen) { historyOpen = false; militaryMarketOpen = false; tradeMapOpen = false }\n'),
    ('            if (militaryMarketOpen) { historyOpen = false; performanceOpen = false }\n',
     '            if (militaryMarketOpen) { historyOpen = false; performanceOpen = false; tradeMapOpen = false }\n'),
    ('        if (historyOpen) {\n', map_body + '        if (historyOpen) {\n'),
], MARKER)

add('core/src/com/unciv/logic/market/MarketRouteStat.kt')
add('core/src/com/unciv/logic/market/WorldMarketRouteStats.kt')
add('core/src/com/unciv/ui/screens/overviewscreen/WorldMarketRouteMapActor.kt')
print('Trade map patch installed. Review git diff, build and test on Android.')
