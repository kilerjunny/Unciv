# Unciv GS — 게임 속도 연동 무역 지도 v1

기준 브랜치: `feature/trade-route-multimodal-v2` (도시국가 시장 패치 포함)

## 목적

- 개요 > 거래 > 세계 시장에 `무역 지도` 추가. 지도는 탐험한 영토와 기존 거래 경로 타일을 표시합니다.
- 기본 최근 기간 `round(30 × game.speed.modifier)`턴 (최소 5 / 최대 360). 빠름/보통/서사/마라톤 등 규칙셋 배율 자동 적용.
- 필터: 속도 연동 최근 기간 또는 기록 전체, 모든 국가/내 거래, 모든 경로/육로/항로/복합.
- 세계 시장 거래 발생 시 `경로+턴`으로 통계를 합산해 별도 저장. 거래 내역 100건 제한과 별개로 동작.
- 저장된 마지막 100건으로 기존 저장파일의 통계를 *부분 복구* (그 전 기록은 불가능).
- `전체 기록`은 **이 기능 설치 후 관측된 데이터 + 마지막 100건**으로만 구성됩니다. 과거 플레이 전체 거래를 소급하여 복구하지 않습니다.
- 메모리 상한: 최근 1600개 경로·턴 집계, 전체 경로 최대 400개. 400 경로 초과 시 경고 출력.
- 지도의 거래 횟수는 표시 중인 집계의 거래 횟수. 가장 빈번한 경로 최대 60개 표시.
- 탐험하지 않은 지형과 해당 구간의 경로는 미표시. 월드랩 경계의 긴 선은 생략.
- 다른 시장 기능, 자원 이동, 구매/판매 가격, 무역로 탐색 로직은 수정하지 않습니다.

## GitHub Add file 경로 (사용자 기존 워크플로우)

1. `trade-map-speed-v1.zip`을 다운로드.
2. GitHub `kilerjunny/Unciv` > branch `feature/trade-route-multimodal-v2` > `Add file` > `Upload files` > ZIP 업로드 > Commit.
3. Codespaces에서:

```bash
git switch feature/trade-route-multimodal-v2
git pull --ff-only origin feature/trade-route-multimodal-v2
git switch -c feature/world-trade-map-speed-v1
unzip -o trade-map-speed-v1.zip -d /tmp
python3 /tmp/trade-map-speed-v1/apply_trade_map_speed_v1.py
git diff --check
git status --short
./gradlew :android:assembleDebug --no-daemon
```

4. 빌드가 성공한 뒤:

```bash
git add core/src/com/unciv/logic/GameInfo.kt \
    core/src/com/unciv/logic/market/WorldMarketHistory.kt \
    core/src/com/unciv/logic/market/MarketRouteStat.kt \
    core/src/com/unciv/logic/market/WorldMarketRouteStats.kt \
    core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt \
    core/src/com/unciv/ui/screens/overviewscreen/WorldMarketRouteMapActor.kt
git commit -m "Add speed-scaled world trade map and route traffic summaries"
git push -u origin feature/world-trade-map-speed-v1
```

5. GitHub Actions > Android build > Run workflow > `feature/world-trade-map-speed-v1`에서 APK 다운로드.

**중요:** ZIP 업로드 커밋은 기준 브랜치에 남지만 코드 패치는 새 브랜치에만 적용됩니다. 이미 `feature/world-trade-map-speed-v1`이 존재하면 `git switch -c` 대신 `git switch` 사용.

## 검증 체크리스트

1. 지도 표시, 빠름·보통 등 속도에 따라 누적 턴 달라지는지
2. 새 거래 후 지도에 육로·항로·복합 경로가 나타나는지
3. 100개 넘는 개별 거래가 발생해도 집계가 유지되는지
4. 저장/불러오기 후 무역 지도 통계 유지되는지
5. 기존 거래, 도시국가 자동 판매, 외교, Android 프레임 속도 유지되는지
6. 정찰하지 않은 지역 표시로 지도 정보가 누설되지 않는지

## 범위 제한

- 실거래 운송/상인 이동/통행료/보급료/실제 봉쇄는 미구현.
- 경로는 기존 세계 시장의 관측 기록에 기반. 일반 상인 활동은 아직 없으므로 표시하지 않음.
- 지도는 별도 카메라가 없는 간략 지리 지도. 실제 게임 맵 화면에서 확대/축소하는 오버레이는 후속 버전.
- 독립 소스 정합성 테스트는 진행했지만 전체 Gradle 빌드 및 게임 내 검증은 Codespaces에서 확인 필요.
