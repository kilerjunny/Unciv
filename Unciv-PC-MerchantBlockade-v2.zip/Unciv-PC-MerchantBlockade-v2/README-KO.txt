Unciv Grand Strategy — PC 일반 상단 v2: 목적지 국적 표시 + 해상 봉쇄
================================================================

이 패키지는 Windows 실행용 게임 ZIP이 아니라 Codespaces에서 Windows64 게임 ZIP을 만드는 빌드 도구입니다.
기존 pc-dev와 mobile-dev 원격 브랜치를 수정하지 않고 별도 임시 worktree에서 빌드합니다.

대상 저장소: https://github.com/kilerjunny/Unciv
기준: PC 전용 pc-dev 설정 + mobile-dev 최신 기능 (빌드 시 git fetch)
기존 기능: 일반 상단 v1.1 / 세계시장 / 통항료 5G / 항만 환적료 10G / 육로 통행료 등

[v2 기능]
1. 일반 상단의 화면상 이름을 '독일행 상단' 같은 목적지 국가 기준으로 표시합니다.
   실제 유닛 소유국, 소속 국기, 외교/전투 국적은 바꾸지 않습니다.
2. 전쟁 중인 국가의 군함이 적국 해안 항구 중심 2칸 이내 해역에 있으면 해당 항구는 봉쇄됩니다.
   - 적국 도착지를 가진 중립국 상단도 해당 항구에는 입항하지 않고 다른 목적지를 찾습니다.
   - 상단을 실제로 공격/나포하지 않고 목적지에 대한 입항을 차단합니다.
   - 봉쇄 중 취소된 방문은 영업 수입과 도착 도시 국가의 방문 보너스를 생성하지 않습니다.
   - 상단의 운영 국적이 바뀌지 않으므로 제3국을 상대로 자동 선전포고하지 않습니다.
3. 상단 탭에 봉쇄된 항구, 소속/목적지 국적, 상단별 회항 횟수,
   플레이어 시야에 보이는 외국 상단 목록을 추가합니다.
4. 기존 일반 상단의 생성 주기, 이동, 유닛 수 제한, 기본 서비스 수입, 통행료는 유지합니다.
5. 항구 봉쇄가 해제되면 상단은 다음 목적지 탐색에서 다시 해당 항구를 선택할 수 있습니다.

[아직 미구현/제한]
- 이 버전에서 봉쇄되는 것은 일반 상단의 항구 방문과 영업 보너스입니다.
- 별도 '세계시장 자원 거래'와 군수 시장의 거래까지 봉쇄하지는 않습니다.
- 중립국 상단의 실제 국기를 바꾸지 않습니다.
- 수익 누적의 도시별 귀속과 통항료 도시 순위 집계는 아직 미구현입니다.
- 외교 항의, 정선 명령, 추격/호위 AI, 수동 봉쇄 명령 버튼은 없습니다.
- 적국 해상 군함이 항구 2칸 이내에 있어야 자동으로 봉쇄 판정됩니다.
- 이전 저장 데이터의 개별 상단 전투/이동 행동은 게임에서 검증해야 합니다.

[빌드]
1. Unciv-PC-MerchantBlockade-v2.zip 파일을 GitHub 저장소의 pc-dev 브랜치 최상위에 업로드하고 Commit changes.
2. Codespaces 터미널에서:

    cd /workspaces/Unciv
    git switch pc-dev
    git pull --ff-only origin pc-dev
    unzip -o Unciv-PC-MerchantBlockade-v2.zip
    bash Unciv-PC-MerchantBlockade-v2/build_pc_merchant_blockade_v2.sh

3. 성공 후:
    /workspaces/Unciv/deploy/Unciv-Windows64-MerchantBlockade-v2-PC.zip

4. 포트 8765 브라우저 목록에서 위 ZIP을 다운로드합니다.
   포트 서버가 꺼져 있다면 별도 터미널에서:

    cd /workspaces/Unciv/deploy
    python3 -m http.server 8765 --bind 0.0.0.0

5. 기존 세이브는 별도 백업 후 새 실행 폴더의 SaveFiles에 복사하세요.
   기존 세이브 파일을 삭제하거나 덮어쓰지 마세요.

[검증]
- 기존 v1.1 patch + v2 patch 순차 적용: 통과 (모의 소스)
- Bash 문법 검사 / Python 문법 검사: 통과
- Kotlin 독립 타입 체크 및 시나리오 테스트: 통과 (모의 의존성)
- 전체 GitHub/Gradle Windows 빌드 및 실제 게임 플레이: 아직 검증하지 못함
