#!/usr/bin/env python3
"""Extend roaming merchants v1.1 with destination labels and wartime naval port blockade.

Must run after apply_merchants_v1.py, in an isolated Unciv build checkout.
All changes use exact checked anchors to avoid silently changing unrelated game code.
"""
from pathlib import Path

root = Path.cwd()


def replace_one(relative, old, new):
    path = root / relative
    code = path.read_text(encoding="utf-8")
    count = code.count(old)
    if count != 1:
        raise RuntimeError(f"{relative}: expected one occurrence of {old[:90]!r}; saw {count}")
    path.write_text(code.replace(old, new, 1), encoding="utf-8")
    print("Blockade v2 applied:", relative)

mapunit = 'core/src/com/unciv/logic/map/mapunit/MapUnit.kt'
replace_one(mapunit,
'''    var merchantTotalFeesPaid: Int = 0
    var merchantFeeKeys: ArrayList<String> = ArrayList()
''',
'''    var merchantTotalFeesPaid: Int = 0
    // GS_MERCHANT_BLOCKADE_V2: persist interdicted voyages without changing unit ownership.
    var merchantTripsBlocked: Int = 0
    var merchantLastBlockadeCivId: String = ""
    var merchantLastBlockadeCityName: String = ""
    var merchantFeeKeys: ArrayList<String> = ArrayList()
''')
replace_one(mapunit,
'''        toReturn.merchantTotalFeesPaid = merchantTotalFeesPaid
        toReturn.merchantFeeKeys = ArrayList(merchantFeeKeys)
''',
'''        toReturn.merchantTotalFeesPaid = merchantTotalFeesPaid
        toReturn.merchantTripsBlocked = merchantTripsBlocked
        toReturn.merchantLastBlockadeCivId = merchantLastBlockadeCivId
        toReturn.merchantLastBlockadeCityName = merchantLastBlockadeCityName
        toReturn.merchantFeeKeys = ArrayList(merchantFeeKeys)
''')

merchant = 'core/src/com/unciv/logic/market/RoamingMerchantAutomation.kt'
replace_one(merchant,
'''import com.unciv.logic.city.City
''',
'''import com.unciv.logic.GameInfo
import com.unciv.logic.city.City
''')
replace_one(merchant,
'''    private const val MaxFeesPerTrip = 30

    fun processTurn(civ: Civilization) {
''',
'''    private const val MaxFeesPerTrip = 30
    // A fleet must be operating near the harbor and actually at war with the harbor owner.
    private const val NavalBlockadeRadius = 2

    /** The navy enforcing a blockade of a coastal destination, if any.
     * This is destination-based. Neutral-country caravans can be denied access to
     * an enemy port without war being declared on the caravan's original owner.
     * The normal unit owner remains unchanged; only the destination display changes.
     */
    fun blockadeController(destination: City): Civilization? {
        if (!destination.isNaval() || destination.civ.isDefeated()) return null
        return destination.getCenterTile().getTilesInDistance(NavalBlockadeRadius)
            .filter { it.isWater }
            .mapNotNull { tile ->
                val warship = tile.militaryUnit ?: return@mapNotNull null
                if (warship.isDestroyed || !warship.isMilitary() || !warship.baseUnit.isWaterUnit)
                    return@mapNotNull null
                warship.civ.takeIf { navy -> navy != destination.civ && navy.isAtWarWith(destination.civ) }
            }
            .firstOrNull()
    }

    fun blockadedPortCount(game: GameInfo): Int = game.civilizations.sumOf { civ ->
        civ.cities.count { blockadeController(it) != null }
    }

    fun processTurn(civ: Civilization) {
''')
replace_one(merchant,
'''                distance in 4..40 &&
                    !(city.civ.civID == unit.merchantLastCityCivId && city.name == unit.merchantLastCityName)
''',
'''                distance in 4..40 &&
                    !(city.civ.civID == unit.merchantLastCityCivId && city.name == unit.merchantLastCityName) &&
                    blockadeController(city) == null
''')
replace_one(merchant,
'''        unit.merchantTargetCivId = city?.civ?.civID ?: ""
        unit.merchantTargetCityName = city?.name ?: ""
''',
'''        unit.merchantTargetCivId = city?.civ?.civID ?: ""
        unit.merchantTargetCityName = city?.name ?: ""
        // The unit's visible name follows the destination country, not its legal owner.
        // This does not transfer the unit, alter its flag, or affect diplomacy.
        unit.instanceName = city?.let { "${it.civ.civName}행 상단" }
''')
replace_one(merchant,
'''        var target = activeDestination(civ, unit)
        if (target == null) target = retarget(civ, unit)
        if (target == null) {
''',
'''        var target = activeDestination(civ, unit)
        // Re-label merchants restored from older saves even before their next trip.
        if (target != null) unit.instanceName = "${target.civ.civName}행 상단"
        if (target != null && blockadeController(target) != null) {
            // A warship closes an enemy port to *all* merchants bound there,
            // including those whose original owner is a neutral third country.
            // The voyage cannot settle a destination service fee or generate gold.
            unit.merchantTripsBlocked++
            unit.merchantLastBlockadeCivId = target.civ.civID
            unit.merchantLastBlockadeCityName = target.name
            target = retarget(civ, unit)
        }
        if (target == null) target = retarget(civ, unit)
        if (target == null) {
''')

ui = 'core/src/com/unciv/ui/screens/overviewscreen/RoamingMerchantSection.kt'
replace_one(ui,
'''        add("일반 상단 (자원 거래와 별개) · 전 세계 ${all}개 / 내 상단 ${mine.size}개".toLabel(hideIcons = true))
            .left().growX().row()
''',
'''        add("일반 상단 (자원 거래와 별개) · 전 세계 ${all}개 / 내 상단 ${mine.size}개".toLabel(hideIcons = true))
            .left().growX().row()
        val blockaded = game.civilizations.asSequence()
            .flatMap { it.cities.asSequence() }
            .filter { playerView.isSpectator() || it.civ == viewer || viewer.knows(it.civ) }
            .filter { RoamingMerchantAutomation.blockadeController(it) != null }
            .toList()
        add("확인된 봉쇄 항구 ${blockaded.size}곳 · 전쟁 중 적국 군함이 항구 2칸 이내에 있으면 해당 국가행 상단은 회항합니다.".toLabel(hideIcons = true))
            .left().growX().row()
        for (port in blockaded.take(5)) {
            val navy = RoamingMerchantAutomation.blockadeController(port)
            val name = navy?.civName?.tr() ?: "?"
            add("봉쇄: ${port.name} (${port.civ.civName.tr()}) · 해군 $name".toLabel(hideIcons = true))
                .left().growX().row()
        }
''')
replace_one(ui,
'''            add("상단 #${unit.id} · 현재 ${unit.currentTile.position} → $goal $country".toLabel(hideIcons = true))
                .left().growX().row()
            add("완료 ${unit.merchantTripsCompleted}회 · 영업 수입 ${unit.merchantIncomeEarned}G · 통행료 지출 ${unit.merchantTotalFeesPaid}G".toLabel(hideIcons = true))
                .left().growX().row()
''',
'''            add("상단 #${unit.id} · 현재 ${unit.currentTile.position} → $goal · 목적지 국적: ${country.ifEmpty { "미정" }} (운영: ${unit.civ.civName.tr()})".toLabel(hideIcons = true))
                .left().growX().row()
            add("완료 ${unit.merchantTripsCompleted}회 · 봉쇄로 회항 ${unit.merchantTripsBlocked}회 · 영업 수입 ${unit.merchantIncomeEarned}G · 통행료 지출 ${unit.merchantTotalFeesPaid}G".toLabel(hideIcons = true))
                .left().growX().row()
''')
replace_one(ui,
'''        }
    }
}
''',
'''        }
        // Show only foreign caravans on tiles the player can currently see.
        val visibleForeign = game.civilizations.asSequence()
            .filter { it != viewer }
            .flatMap { it.units.getCivUnits() }
            .filter { it.name == RoamingMerchantAutomation.UnitName && !it.isDestroyed }
            .filter { playerView.isSpectator() || it.currentTile in viewer.viewableTiles }
            .take(10).toList()
        if (visibleForeign.isNotEmpty()) {
            add("현재 발견한 외국 상단 (${visibleForeign.size}개까지 표시)".toLabel(hideIcons = true))
                .left().growX().row()
            for (unit in visibleForeign) {
                val target = game.getCivilizationOrNull(unit.merchantTargetCivId)?.civName?.tr() ?: "미정"
                add("#${unit.id} · ${unit.civ.civName.tr()} 운영 / $target 행 · ${unit.merchantTargetCityName.ifEmpty { "자유 이동" }}".toLabel(hideIcons = true))
                    .left().growX().row()
            }
        }
    }
}
''')

# Preflight assertions: enforced blockade is limited to merchants arriving at coastal cities.
code = (root / merchant).read_text(encoding='utf-8')
assert 'blockadeController(target) != null' in code
assert 'unit.merchantTripsBlocked++' in code
assert 'city?.let { "${it.civ.civName}행 상단" }' in code
assert 'if (target.civ != civ) target.civ.addGold(3)' in code
assert 'civ.addGold(cash)' in code
assert 'unit.civ = ' not in code  # Never change owner when targeting a port.
print('Destination-label / naval blockade v2 patch verified.')
