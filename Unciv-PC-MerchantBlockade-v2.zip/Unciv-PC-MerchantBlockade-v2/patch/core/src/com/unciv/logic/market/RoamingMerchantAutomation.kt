package com.unciv.logic.market

import com.unciv.logic.city.City
import com.unciv.logic.civilization.Civilization
import com.unciv.logic.map.mapunit.MapUnit
import com.unciv.logic.map.tile.Tile

/** GS_ROAMING_MERCHANTS_V1
 * Civilian caravans moving on actual map tiles, independently of all resource
 * stockpiles, market sell orders, and military-market contracts.
 *
 * Two caravans per large country at most. Regular movement/civilian border rules
 * apply. A trader may visit a friendly/foreign city approach tile, but never
 * teleports into a foreign city center. Each trip settles a small service fee
 * at destination and pays actual transit fees en route to third-party civs.
 *
 * Cargo, city-level customs ledger, escorts and autonomous ocean ships are
 * deliberately outside v1. Fields on MapUnit make active trips save-safe.
 */
object RoamingMerchantAutomation {
    const val UnitName = "Trade Caravan"
    private const val MaxCaravans = 2
    private const val MaxFeesPerTrip = 30

    fun processTurn(civ: Civilization) {
        if (civ.isBarbarian || civ.isSpectator() || civ.isDefeated() || civ.cities.isEmpty()) return
        if (!civ.gameInfo.ruleset.units.containsKey(UnitName)) return

        val existing = civ.units.getCivUnits()
            .filter { it.name == UnitName && !it.isDestroyed }.toList()
        val desired = if (civ.cities.size >= 3) MaxCaravans else 1
        // Cadence is per civilization, deterministic and independent of UI visits.
        val spawnPhase = (civ.civID.hashCode().toLong() and 0x7fffffffL) % 8L
        if (existing.size < desired && civ.gameInfo.turns.toLong() % 8L == spawnPhase) {
            val origin = civ.cities.minByOrNull { city ->
                existing.count { unit ->
                    unit.currentTile.aerialDistanceTo(city.getCenterTile()) <= 4
                }
            }
            val newborn = origin?.let { civ.units.addUnit(UnitName, it) }
            if (newborn != null) {
                newborn.merchantHomeCityName = origin.name
                newborn.merchantTripStartTurn = civ.gameInfo.turns
                newborn.due = false
            }
        }
        // Use a snapshot: creating/moving units can update UnitManager's list.
        for (merchant in civ.units.getCivUnits().filter { it.name == UnitName }.toList()) {
            if (merchant.isDestroyed || merchant.civ != civ) continue
            advance(civ, merchant)
            merchant.due = false // Do not interrupt the player's normal military turn.
        }
    }

    private fun findApproach(unit: MapUnit, city: City): Tile? {
        val center = city.getCenterTile()
        return (listOf(center) + center.neighbors)
            .asSequence()
            .filter { it.isLand && (it == unit.currentTile || unit.movement.canMoveTo(it)) }
            .sortedBy { it.aerialDistanceTo(unit.currentTile) }
            .firstOrNull { it == unit.currentTile || unit.movement.canReach(it) }
    }

    private fun chooseTarget(civ: Civilization, unit: MapUnit): City? {
        // Only known civilizations; no blind trades through unexplored kingdoms.
        val eligibleCivs = (listOf(civ) + civ.getKnownCivs().toList())
            .distinctBy { it.civID }
            .filter { !it.isDefeated() && !civ.isAtWarWith(it) }
        val start = unit.currentTile
        val cities = eligibleCivs.asSequence()
            .flatMap { it.cities.asSequence() }
            .filter { city ->
                val distance = start.aerialDistanceTo(city.getCenterTile())
                distance in 4..40 &&
                    !(city.civ.civID == unit.merchantLastCityCivId && city.name == unit.merchantLastCityName)
            }
            // Prefer foreign market centers, but keep geographical paths affordable.
            .sortedWith(compareBy<City> { if (it.civ == civ) 1 else 0 }
                .thenBy { it.getCenterTile().aerialDistanceTo(start) })
            .take(8)
            .toList()
        return cities.firstOrNull { findApproach(unit, it) != null }
    }

    private fun activeDestination(civ: Civilization, unit: MapUnit): City? {
        if (unit.merchantTargetCityName.isBlank()) return null
        val targetCiv = civ.gameInfo.getCivilizationOrNull(unit.merchantTargetCivId) ?: return null
        if (targetCiv.isDefeated() || civ.isAtWarWith(targetCiv)) return null
        return targetCiv.cities.firstOrNull { it.name == unit.merchantTargetCityName }
    }

    private fun retarget(civ: Civilization, unit: MapUnit): City? {
        val city = chooseTarget(civ, unit)
        unit.merchantTargetCivId = city?.civ?.civID ?: ""
        unit.merchantTargetCityName = city?.name ?: ""
        unit.merchantTripStartTurn = civ.gameInfo.turns
        unit.merchantNoProgressTurns = 0
        unit.merchantFeesThisTrip = 0
        unit.merchantFeeKeys.clear()
        return city
    }

    private fun advance(civ: Civilization, unit: MapUnit) {
        if (!unit.hasMovement()) return
        var target = activeDestination(civ, unit)
        if (target == null) target = retarget(civ, unit)
        if (target == null) {
            wander(unit)
            return
        }
        val approach = findApproach(unit, target)
        if (approach == null) {
            unit.merchantNoProgressTurns++
            if (unit.merchantNoProgressTurns >= 3) retarget(civ, unit)
            return
        }
        val before = unit.currentTile
        val destination = unit.movement.getTileToMoveToThisTurn(approach)
        if (destination != before) {
            val reachable = unit.movement.getDistanceToTiles()
            val route = if (destination in reachable) reachable.getPathToTile(destination)
                else emptyList()
            unit.movement.moveToTile(destination)
            if (unit.currentTile != before) {
                unit.merchantNoProgressTurns = 0
                // Only bill a path after movement succeeded; never bill for a blocked route.
                if (unit.currentTile == destination) {
                    var previous = before
                    for (tile in route) {
                        chargeTransit(civ, target.civ, unit, previous, tile)
                        previous = tile
                    }
                }
            } else unit.merchantNoProgressTurns++
        } else unit.merchantNoProgressTurns++

        if (unit.currentTile.aerialDistanceTo(target.getCenterTile()) <= 1) {
            // Do not mint gold on an instant/zero-distance target change.
            if (civ.gameInfo.turns - unit.merchantTripStartTurn >= 2) {
                val cash = 8 + minOf(12, civ.gameInfo.turns - unit.merchantTripStartTurn)
                civ.addGold(cash)
                if (target.civ != civ) target.civ.addGold(3)
                unit.merchantIncomeEarned += cash
                unit.merchantTripsCompleted++
            }
            unit.merchantLastCityCivId = target.civ.civID
            unit.merchantLastCityName = target.name
            retarget(civ, unit)
        } else if (unit.merchantNoProgressTurns >= 3) {
            retarget(civ, unit)
        }
    }

    private fun chargeTransit(
        sender: Civilization, recipient: Civilization, unit: MapUnit, from: Tile, to: Tile
    ) {
        if (unit.merchantFeesThisTrip >= MaxFeesPerTrip) return
        if (from == to || from !in to.neighbors) return
        // Reuse the world-market toll quote so a caravan pays exactly the same
        // land/sea/harbor rates as merchandise on a two-tile route segment.
        for (payment in WorldMarketCashTolls.quote(sender, recipient, listOf(from, to), 200)) {
            val controller = sender.gameInfo.getCivilizationOrNull(payment.civId) ?: continue
            if (controller == sender || controller == recipient) continue
            for ((kind, requested) in listOf(
                "land" to payment.landGold,
                "sea" to payment.seaGold,
                "harbor" to payment.harborGold
            )) {
                if (requested <= 0) continue
                val key = "${controller.civID}/$kind"
                if (key in unit.merchantFeeKeys) continue
                if (sender.gold < requested || controller.gold > Int.MAX_VALUE - requested) continue
                val paid = minOf(requested, MaxFeesPerTrip - unit.merchantFeesThisTrip)
                if (paid <= 0) return
                sender.addGold(-paid)
                controller.addGold(paid)
                unit.merchantFeesThisTrip += paid
                unit.merchantTotalFeesPaid += paid
                unit.merchantFeeKeys.add(key)
            }
        }
    }

    private fun wander(unit: MapUnit) {
        val options = unit.currentTile.neighbors.filter {
            it.isLand && unit.movement.canMoveTo(it) &&
                unit.movement.canReachInCurrentTurn(it) && unit.getDamageFromTerrain(it) == 0
        }.toList()
        if (options.isEmpty()) return
        val rng = unit.cache.state.stateBasedRandom("RoamingMerchantAutomation.wander")
        unit.movement.moveToTile(options.random(rng))
    }
}
