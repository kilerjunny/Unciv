#!/usr/bin/env bash
set -Eeuo pipefail
WORKTREE="${1:-/workspaces/unciv-pc-latest-20261122-121909-1926}"
FILE="$WORKTREE/core/src/com/unciv/logic/market/RoamingMerchantAutomation.kt"
if [[ ! -f "$FILE" ]]; then
  echo "Missing failed-build source: $FILE" >&2
  exit 1
fi
python3 - "$FILE" <<'PYFIX'
from pathlib import Path
import sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
old = '''        val options = unit.currentTile.neighbors.filter {
            it.isLand && unit.movement.canMoveTo(it) &&
                unit.movement.canReachInCurrentTurn(it) && unit.getDamageFromTerrain(it) == 0
        }
        if (options.isEmpty()) return'''
new = old.replace('        }\n        if', '        }.toList()\n        if')
if old in s:
    p.write_text(s.replace(old, new, 1), encoding='utf-8')
    print('Fixed Sequence<Tile> materialization')
elif new in s:
    print('Already fixed')
else:
    raise SystemExit('Expected code not found; no changes made')
PYFIX
cd "$WORKTREE"
./gradlew :desktop:dist :desktop:zipWindows64 --no-daemon
ZIP="$WORKTREE/deploy/Unciv-Windows64.zip"
test -s "$ZIP"
unzip -tqq "$ZIP"
mkdir -p /workspaces/Unciv/deploy
cp -f "$ZIP" /workspaces/Unciv/deploy/Unciv-Windows64-RoamingMerchants-v1.1-PC.zip
ls -lh /workspaces/Unciv/deploy/Unciv-Windows64-RoamingMerchants-v1.1-PC.zip
