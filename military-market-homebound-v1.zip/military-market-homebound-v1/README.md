# Military Market — AI Homebound v1

**Target:** `kilerjunny/Unciv`, `mobile-dev` (after military-market and performance v2 changes).

## Behavior

- Applies only to military units newly received by AI buyers via the Military Market.
- During peace, those units attempt to move by actual game paths to the buying country's nearest reachable owned territory (land, coastal waters, or airbase).
- On reaching their own territory, the return order is cleared, and ordinary AI resumes.
- While the buyer is at war, ordinary combat AI takes precedence; return resumes if still abroad once peace returns.
- Human-purchased units stay manually controlled. No forced unit spawning/teleportation, no changes to market gold or production.
- The minimal state `(unique unit ID -> buyer civ ID)` is saved and cloned; old saves without this field continue to load.
- Only **new deliveries** can be tracked. Old completed market history does not store unit IDs and cannot be safely retroactively identified.
- If no valid homeward path exists (e.g., borders closed, no embark capability, or landlocked navy), the ordinary AI is allowed to act; the homeward path is retried later.
- Reachability checks limited to six candidate destinations per pending unit per AI turn to protect large-map performance.

## Apply

Upload this ZIP to the root of `mobile-dev`, commit upload, pull in Codespaces, then:

```bash
unzip -o military-market-homebound-v1.zip -d /tmp
python3 /tmp/military-market-homebound-v1/apply_military_market_homebound_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

After **BUILD SUCCESSFUL**, stage **only** the following files (plus remove the uploaded ZIP):

```bash
git add core/src/com/unciv/logic/GameInfo.kt
git add core/src/com/unciv/logic/market/MilitaryMarket.kt
git add core/src/com/unciv/logic/market/MilitaryMarketReturnHome.kt
git add core/src/com/unciv/logic/automation/unit/UnitAutomation.kt
git rm --ignore-unmatch military-market-homebound-v1.zip
git diff --cached --check
git commit -m "Return AI military market purchases home in peacetime"
git push origin mobile-dev
```

## Test

1. In peace, let an AI country receive a newly ordered unit from a foreign producer.
2. Confirm it gains movement next turn and advances into the buyer's territory instead of lingering indefinitely at the seller.
3. Confirm it continues ordinary AI tasks after reaching buyer-owned territory.
4. Confirm the purchase does not reassign or teleport units, and gold settlement stays unchanged.
5. Save/load during a return journey and confirm the unit continues returning.
6. If a war breaks out, verify military AI is not blocked and returns are resumed after peace.

**Note:** Full Android APK build must be performed in Codespaces. This patch was statically checked against the GitHub branch and tested using isolated checks, not built as a complete Android app here.
