#!/usr/bin/env python3
"""Apply Military Market homebound AI v1 to Unciv mobile-dev (preflight + idempotent)."""
from pathlib import Path
import sys

ROOT = Path.cwd()
MARKER = "GS_MILITARY_MARKET_HOMEBOUND_V1"
GAME = Path("core/src/com/unciv/logic/GameInfo.kt")
MARKET = Path("core/src/com/unciv/logic/market/MilitaryMarket.kt")
AI = Path("core/src/com/unciv/logic/automation/unit/UnitAutomation.kt")
NEW = Path("core/src/com/unciv/logic/market/MilitaryMarketReturnHome.kt")

NEW_SOURCE = '''package com.unciv.logic.market

import com.unciv.logic.map.mapunit.MapUnit
import com.unciv.logic.map.tile.Tile

/**
 * GS_MILITARY_MARKET_HOMEBOUND_V1
 * AI-bought military units return to the buyer's owned territory in peacetime.
 * Only units actually delivered by MilitaryMarket.receive are tracked.
 * Real movement, never teleportation; no interference with AI wartime decisions.
 * At most six full reachability checks per homebound unit per AI decision.
 */
object MilitaryMarketReturnHome {
    private const val MaxPathChecks = 6

    /** True if homebound handling took this unit's action for this decision. */
    fun tryReturn(unit: MapUnit): Boolean {
        val civ = unit.civ
        val pending = civ.gameInfo.militaryMarketReturnHomeUnits
        val assignedCiv = pending[unit.id] ?: return false
        if (assignedCiv != civ.civID || unit.isDestroyed) {
            pending.remove(unit.id)
            return false
        }
        if (!civ.isAI()) return false // A human buyer always controls purchased units.
        if (unit.getTile().getOwner() == civ) {
            pending.remove(unit.id)
            return false // Arrived: resume ordinary AI from now on.
        }
        if (civ.isAtWar()) return false // War AI takes priority; resume after peace.
        if (!unit.hasMovement()) return true // Delivery turn has zero movement points.

        val origin = unit.getTile()
        val air = unit.baseUnit.isAirUnit()
        val water = unit.baseUnit.isWaterUnit
        // Choose the nearest legal OWNED destination; naval units can use coastal
        // owned water, and air units need a buyer-owned city/airbase.
        val destinations: Sequence<Tile> = civ.cities.asSequence()
            .flatMap { city ->
                if (air) sequenceOf(city.getCenterTile())
                else city.getCenterTile().getTilesInDistance(2).asSequence()
            }
            .filter { tile ->
                tile.getOwner() == civ && !tile.isImpassible() && when {
                    air -> tile.isCityCenter()
                    water -> tile.isWater || tile.isCityCenter()
                    else -> tile.isLand
                }
            }
            .distinct()
            .sortedBy { it.aerialDistanceTo(origin) }

        var checked = 0
        for (target in destinations) {
            if (!unit.movement.canMoveTo(target)) continue
            if (checked++ >= MaxPathChecks) break
            if (!unit.movement.canReach(target)) continue
            unit.movement.headTowards(target)
            if (unit.getTile().getOwner() == civ) pending.remove(unit.id)
            return true
        }
        // No reachable home tile: never teleport or freeze all AI behavior.
        // Ordinary AI can act this turn and we will retry on the next peaceful turn.
        return false
    }
}
'''

def replace_exact(source: str, before: str, after: str, label: str) -> str:
    found = source.count(before)
    if found != 1:
        raise RuntimeError(f"{label}: expected exactly one anchor, found {found}; NO files changed")
    return source.replace(before, after, 1)

def main() -> int:
    paths = (GAME, MARKET, AI)
    for path in paths:
        if not (ROOT / path).is_file():
            raise RuntimeError(f"Not an Unciv repository root or missing: {path}")
    texts = {path: (ROOT / path).read_text(encoding="utf-8") for path in paths}
    installed = [MARKER in texts[p] for p in paths]
    if all(installed) and (ROOT / NEW).is_file() and MARKER in (ROOT / NEW).read_text(encoding="utf-8"):
        print("Already applied: GS Military Market homebound v1. Nothing changed.")
        return 0
    if any(installed) or (ROOT / NEW).exists():
        raise RuntimeError("Partially installed or conflicting homebound v1 patch; NO files changed")

    s = texts[GAME]
    s = replace_exact(s,
        "    var militaryMarketAILastOrderTurn = HashMap<String, Int>()\n",
        "    var militaryMarketAILastOrderTurn = HashMap<String, Int>()\n"
        "    // GS_MILITARY_MARKET_HOMEBOUND_V1: global unique unit ID -> buyer civ ID.\n"
        "    var militaryMarketReturnHomeUnits = HashMap<Int, String>()\n", str(GAME))
    s = replace_exact(s,
        "        toReturn.militaryMarketAILastOrderTurn.putAll(militaryMarketAILastOrderTurn)\n",
        "        toReturn.militaryMarketAILastOrderTurn.putAll(militaryMarketAILastOrderTurn)\n"
        "        toReturn.militaryMarketReturnHomeUnits.putAll(militaryMarketReturnHomeUnits)\n", str(GAME))
    texts[GAME] = s

    s = texts[MARKET]
    s = replace_exact(s,
        "        unit.gift(buyer) // Transfer SAME unit without spawning or teleporting.\n"
        "        unit.currentMovement = 0f\n",
        "        unit.gift(buyer) // Transfer SAME unit without spawning or teleporting.\n"
        "        unit.currentMovement = 0f\n"
        "        // GS_MILITARY_MARKET_HOMEBOUND_V1: peacetime AI return order, persisted in GameInfo.\n"
        "        if (buyer.isAI() && unit.isMilitary())\n"
        "            game.militaryMarketReturnHomeUnits[unit.id] = buyer.civID\n", str(MARKET))
    s = replace_exact(s,
        "    fun reconcile(game: GameInfo) {\n        game.militaryMarketListings.removeAll { listing ->\n",
        "    fun reconcile(game: GameInfo) {\n"
        "        // GS_MILITARY_MARKET_HOMEBOUND_V1: discard orders for destroyed/transferred units.\n"
        "        if (game.militaryMarketReturnHomeUnits.isNotEmpty())\n"
        "            game.militaryMarketReturnHomeUnits.entries.removeAll { (unitId, buyerId) ->\n"
        "                val buyer = game.getCivilizationOrNull(buyerId)\n"
        "                buyer == null || buyer.isDefeated() ||\n"
        "                    buyer.units.getCivUnits().none { it.id == unitId && !it.isDestroyed }\n"
        "            }\n"
        "        game.militaryMarketListings.removeAll { listing ->\n", str(MARKET))
    texts[MARKET] = s

    s = texts[AI]
    s = replace_exact(s,
        "import com.unciv.logic.automation.civilization.GrandStrategyPerf\n",
        "import com.unciv.logic.automation.civilization.GrandStrategyPerf\n"
        "import com.unciv.logic.market.MilitaryMarketReturnHome\n", str(AI))
    s = replace_exact(s,
        "        if (unit.getDamageFromTerrain() > 0 && tryHealUnit(unit)) return\n",
        "        if (unit.getDamageFromTerrain() > 0 && tryHealUnit(unit)) return\n"
        "        // GS_MILITARY_MARKET_HOMEBOUND_V1: only recently delivered AI purchases.\n"
        "        if (unit.civ.isAI() && MilitaryMarketReturnHome.tryReturn(unit)) return\n", str(AI))
    texts[AI] = s

    # Preflight complete; write only after every source anchor has passed.
    for path in paths:
        (ROOT / path).write_text(texts[path], encoding="utf-8")
        print("PATCHED", path)
    (ROOT / NEW).write_text(NEW_SOURCE, encoding="utf-8")
    print("CREATED", NEW)
    print("Homebound v1 applied: new AI deliveries return home at peace; wartime AI unaffected.")
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as error:
        print("PATCH ABORTED:", error, file=sys.stderr)
        sys.exit(1)
