# Unciv – Merchant Overview Tab v1 (`mobile-dev`)

## Purpose

Separate **commerce** from **logistics** on the empire overview screen:

- Existing **거래 (Trades)**: world-market buying and listing, military market, existing diplomatic trade contracts. Add a shortcut button **상단 · 무역 지도**.
- New **상단 (Merchants)**: start on the existing trade map; retain map filters, main-route display, virtual land/coastal/ocean merchant segments, power-saving mode, route shipping history, actual toll/harbor fee settlement details, and performance diagnostics.
- New merchant-tab header: last-100-trades cargo volume and the viewer's toll earnings/expenses. This is not a lifetime account balance.
- No changes to world-market pricing, delivery settlement, trade-route computation, fee rates, or AI trade logic.
- Autonomous merchant-company AI and actual merchant ships are **not yet implemented**. Current land/coastal/ocean classification is virtual, as before.

## Apply in Codespaces

1. Choose branch `mobile-dev` on GitHub and upload `merchant-overview-tab-v1.zip` to the repository root; commit it.
2. In Codespaces, from the repository root:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o merchant-overview-tab-v1.zip -d /tmp
python3 /tmp/merchant-overview-tab-v1/apply_merchant_overview_tab_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

3. When BUILD SUCCESSFUL:

```bash
git add core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git add core/src/com/unciv/ui/screens/overviewscreen/EmpireOverviewCategories.kt
git add core/src/com/unciv/ui/screens/overviewscreen/EmpireOverviewScreen.kt
git add core/src/com/unciv/ui/screens/overviewscreen/MerchantOverviewTab.kt
git rm merchant-overview-tab-v1.zip
git commit -m "Move logistics and trade map to merchant overview tab"
git push origin mobile-dev
```

Build APK via `.github/workflows/androidBuild.yml` on branch `mobile-dev`.

## In-game checks

1. Empire overview includes **상단** tab. Opening it shows **무역 지도** by default.
2. Toggle map filters, main routes, and **가상 상선망 보기**; no new route-planning occurs on map open.
3. Open **운송 내역** to see route endpoints, movement segments, transport indices, real toll and transfer fees, recipient nations.
4. Open **성능 진단**; old diagnostics remain accessible.
5. Return to **거래**: market buying/listing, military market, diplomatic trade contracts continue working; no map/history controls inside it.
6. Reopen save and switch tabs repeatedly; no regression or missing controls.

## Compatibility and limits

Patch intentionally stops before writing if an expected source anchor changed. It is idempotent if the full patch is already installed. Must be run from the Unciv checkout root.

Kotlin compilation and Android runtime testing must be performed in Codespaces; the ZIP package is not an APK.
