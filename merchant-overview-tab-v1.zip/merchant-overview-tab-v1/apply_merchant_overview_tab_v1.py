#!/usr/bin/env python3
"""Unciv mobile-dev: split merchant route/intelligence from the trading screen.

Only the empire overview UI is changed. No market settlement or AI logic is edited.
"""
from pathlib import Path
import sys

ROOT = Path.cwd()
UI = Path('core/src/com/unciv/ui/screens/overviewscreen')
SECTION = UI / 'WorldMarketTradeSection.kt'
CATEGORIES = UI / 'EmpireOverviewCategories.kt'
SCREEN = UI / 'EmpireOverviewScreen.kt'
NEW_TAB = UI / 'MerchantOverviewTab.kt'
STAMP = 'GS_MERCHANT_OVERVIEW_TAB_V1'


def replace_one(content: str, old: str, new: str, label: str) -> str:
    n = content.count(old)
    if n != 1:
        raise RuntimeError(f'{label}: expected exactly one anchor; found {n}. No files written.')
    return content.replace(old, new, 1)


def replace_region(content: str, start: str, end: str, new: str, label: str) -> str:
    s = content.find(start)
    if s < 0 or content.find(start, s + 1) >= 0:
        raise RuntimeError(f'{label}: start anchor absent or duplicated. No files written.')
    e = content.find(end, s)
    if e < 0 or content.find(end, e + len(end)) >= 0:
        raise RuntimeError(f'{label}: end anchor absent or duplicated. No files written.')
    return content[:s] + new + content[e + len(end):]


def patch(section: str, categories: str, screen: str) -> tuple[str, str, str, str]:
    # Existing TradesOverviewTab(viewingPlayer, this) continues to use the default false mode.
    section = replace_one(
        section,
        '    private val parentTab: TradesOverviewTab\n) : Table(BaseScreen.skin) {',
        '    private val parentTab: EmpireOverviewTab,\n'
        '    private val merchantMode: Boolean = false // ' + STAMP + '\n'
        ') : Table(BaseScreen.skin) {',
        'WorldMarketTradeSection constructor',
    )
    section = replace_one(section, '    private var tradeMapOpen = false\n',
                          '    private var tradeMapOpen = merchantMode\n', 'default map on merchant tab')
    section = replace_one(
        section, '        header.add("세계 시장".toLabel(\n',
        '        header.add((if (merchantMode) "상단 · 무역 정보" else "세계 시장").toLabel(\n',
        'section header',
    )
    section = replace_one(
        section,
        '''        val resourcesButton =
            TextButton("자원 현황", BaseScreen.skin)
        resourcesButton.onClick {
            parentTab.overviewScreen.select(
                EmpireOverviewCategories.Resources, ""
            )
        }
        header.add(resourcesButton).padLeft(5f)
''',
        '''        if (!merchantMode) {
            val resourcesButton = TextButton("자원 현황", BaseScreen.skin)
            resourcesButton.onClick {
                parentTab.overviewScreen.select(EmpireOverviewCategories.Resources, "")
            }
            header.add(resourcesButton).padLeft(5f)
        }
''', 'market-only resource button',
    )

    new_controls = '''        // GS_MERCHANT_OVERVIEW_TAB_V1: trade contracts stay in Trades,
        // while routes, logistics, records and diagnostics live in Merchants.
        if (merchantMode) {
            val viewer = playerView.getCiv()
            val recentRecords = WorldMarketHistory.recent(viewer.gameInfo)
            val tollEarned = recentRecords.sumOf { record ->
                record.cashTollPayments.filter { it.civId == viewer.civID }.sumOf { it.gold }
            }
            val tollPaid = recentRecords.filter { it.sellerCivId == viewer.civID }
                .sumOf { it.cashTollGold }
            val amount = recentRecords.sumOf { it.quantity }
            add("최근 거래 기록 ${recentRecords.size}건 · 물동량 ${amount}개 · 내 통행료 수입 ${tollEarned}G / 지출 ${tollPaid}G".toLabel(hideIcons = true))
                .left().growX().row()
            add("현재 육상 상단·연안/원양 상선은 가상 운송 구간입니다. 독립적인 상단 AI 운항은 아직 미구현입니다.".toLabel(hideIcons = true))
                .left().growX().row()

            val pages = Table(BaseScreen.skin)
            val mapButton = TextButton(if (tradeMapOpen) "무역 지도 ✓" else "무역 지도", BaseScreen.skin)
            mapButton.onClick {
                tradeMapOpen = true
                historyOpen = false
                performanceOpen = false
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            pages.add(mapButton).padRight(5f)

            val historyButton = TextButton(if (historyOpen) "운송 내역 ✓" else "운송 내역", BaseScreen.skin)
            historyButton.onClick {
                historyOpen = true
                tradeMapOpen = false
                performanceOpen = false
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            pages.add(historyButton).padRight(5f)

            val perfButton = TextButton(if (performanceOpen) "성능 진단 ✓" else "성능 진단", BaseScreen.skin)
            perfButton.onClick {
                performanceOpen = true
                tradeMapOpen = false
                historyOpen = false
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            pages.add(perfButton)
            add(pages).left().row()
        } else {
            val merchantButton = TextButton("상단 · 무역 지도", BaseScreen.skin)
            merchantButton.onClick {
                parentTab.overviewScreen.select(EmpireOverviewCategories.Merchants, "")
            }
            add(merchantButton).left().row()

            val militaryButton = TextButton(
                if (militaryMarketOpen) "시장 보기" else "군수 시장", BaseScreen.skin
            )
            militaryButton.onClick {
                militaryMarketOpen = !militaryMarketOpen
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            add(militaryButton).left().row()
        }
'''
    section = replace_region(
        section,
        '        val tradeMapButton = TextButton(if (tradeMapOpen) "시장 보기" else "무역 지도", BaseScreen.skin)',
        '        add(militaryButton).left().row()\n',
        new_controls,
        'merchant/market mode controls',
    )
    # Existing map, trade-history and perf renderers remain intact, preserving
    # filtering, low-power mode, routes, tally and fee breakdown UI.

    categories = replace_one(
        categories,
        '''    Trades("StatIcons/Acquire", 'T', Align.top) {
        override fun createTab(viewingPlayer: CivView, overviewScreen: EmpireOverviewScreen, persistedData: EmpireOverviewTabPersistableData?) =
                TradesOverviewTab(viewingPlayer, overviewScreen)
        override fun showDisabled(viewingPlayer: CivView) = false
    },
''',
        '''    Trades("StatIcons/Acquire", 'T', Align.top) {
        override fun createTab(viewingPlayer: CivView, overviewScreen: EmpireOverviewScreen, persistedData: EmpireOverviewTabPersistableData?) =
                TradesOverviewTab(viewingPlayer, overviewScreen)
        override fun showDisabled(viewingPlayer: CivView) = false
    },
    // GS_MERCHANT_OVERVIEW_TAB_V1: logistics, trade map and merchant intelligence.
    Merchants("StatIcons/Acquire", 'B', Align.top) {
        override fun createTab(viewingPlayer: CivView, overviewScreen: EmpireOverviewScreen, persistedData: EmpireOverviewTabPersistableData?) =
                MerchantOverviewTab(viewingPlayer, overviewScreen)
        override fun showDisabled(viewingPlayer: CivView) = false
    },
''', 'add merchant overview category',
    )
    screen = replace_one(
        screen,
        '        if (category == EmpireOverviewCategories.Formations) "편제" else category.name',
        '''        when (category) {
            EmpireOverviewCategories.Formations -> "편제"
            EmpireOverviewCategories.Merchants -> "상단"
            else -> category.name
        }''',
        'Korean merchant tab caption',
    )
    new_tab = '''package com.unciv.ui.screens.overviewscreen

import com.unciv.view.CivView

/** GS_MERCHANT_OVERVIEW_TAB_V1
 * Merchant intelligence tab. The underlying market transactions remain in Trades.
 * This tab reports observed routes/fees; autonomous merchant AI is not implemented yet.
 */
class MerchantOverviewTab(
    viewingPlayer: CivView,
    overviewScreen: EmpireOverviewScreen
) : EmpireOverviewTab(viewingPlayer, overviewScreen) {
    init {
        top().left()
        defaults().pad(6f)
        add(WorldMarketTradeSection(viewingPlayer, this, merchantMode = true)).growX().row()
    }
}
'''
    return section, categories, screen, new_tab


def main() -> int:
    files = [SECTION, CATEGORIES, SCREEN]
    for relative in files:
        if not (ROOT / relative).is_file():
            raise RuntimeError(f'Missing {relative}. Run from the Unciv repository root on mobile-dev.')
    if (ROOT / NEW_TAB).exists():
        existing = (ROOT / NEW_TAB).read_text(encoding='utf-8')
        if STAMP in existing and STAMP in (ROOT / SECTION).read_text(encoding='utf-8'):
            print('Already applied; no files changed.')
            return 0
        raise RuntimeError(f'{NEW_TAB} already exists; refusing to overwrite it.')

    originals = [ (ROOT / relative).read_text(encoding='utf-8') for relative in files ]
    if any(STAMP in source for source in originals):
        raise RuntimeError('Partial patch detected; no files changed. Inspect git diff.')

    # All checks/patches are completed before writing, so no partial changes
    # occur when the source layout differs from the tested mobile-dev version.
    patched = patch(*originals)
    for relative, content in zip(files + [NEW_TAB], patched):
        dest = ROOT / relative
        dest.write_text(content, encoding='utf-8')
        print('Updated:', relative)
    print('Done: Trade market and military contracts stay in Trades; merchant logistics moved to the 상단 tab.')
    return 0

if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        print('ERROR:', exc, file=sys.stderr)
        sys.exit(1)
