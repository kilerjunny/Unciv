#!/usr/bin/env python3
"""Install observation-only Dijkstra shipping routes on world-main-routes-v1."""
from pathlib import Path
import sys

ROOT = Path.cwd()
MK = Path('core/src/com/unciv/logic/market')
PLANNER = MK / 'WorldMarketRoutePlanner.kt'
ECON = MK / 'WorldMarketEconomicRoutePlanner.kt'
RECORD = MK / 'MarketTradeRecord.kt'
HISTORY = MK / 'WorldMarketHistory.kt'
UI = Path('core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt')
PERF = Path('core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt')
SOURCE = Path(__file__).parent / 'WorldMarketEconomicRoutePlanner.kt'
MARK = 'GS_ECONOMIC_TRADE_ROUTES_V1'


def once(text, old, new, path):
    n = text.count(old)
    if n != 1:
        raise RuntimeError(f'{path}: expected 1 anchor, got {n}: {old[:90]!r}')
    return text.replace(old, new, 1)


def make_planner(s):
    p = PLANNER
    s = once(s, 'import com.unciv.logic.city.City\n',
        'import com.unciv.logic.city.City\n'
        'import com.unciv.logic.automation.civilization.GrandStrategyPerf\n', p)
    s = once(s, '        val tiles: List<HexCoord>\n    )',
        '        val tiles: List<HexCoord>,\n'
        '        val estimatedTransportCost: Int = -1 // GS_ECONOMIC_TRADE_ROUTES_V1\n'
        '    )', p)
    s = once(s, '''        if (startCities.isEmpty() || endCities.isEmpty()) return unresolved(seller, buyer)
        val targetTiles = endCities.keys''', '''        if (startCities.isEmpty() || endCities.isEmpty()) return unresolved(seller, buyer)

        // GS_ECONOMIC_TRADE_ROUTES_V1: minimum transport index, not minimum tile count.
        // Trade settlement has already happened. This records the observed route only.
        val cheapest = GrandStrategyPerf.measure("market_economic_route") {
            WorldMarketEconomicRoutePlanner.find(seller.gameInfo, startCities.keys, endCities.keys)
        }
        if (cheapest != null) {
            val path = cheapest.tiles
            val water = path.any { it.isWater }
            val inlandLeg = path.drop(1).dropLast(1).any { it.isLand }
            val mode = when {
                !water -> "LAND"
                inlandLeg -> "MIXED"
                else -> "SEA"
            }
            return Route(mode,
                startCities[path.first()]?.name.orEmpty(),
                endCities[path.last()]?.name.orEmpty(),
                path.map { it.position }, cheapest.estimatedCost)
        }
        // Fail-safe: if the new weighted search hits its work limit or finds no
        // route, the old BFS still works (with an unknown transport index).
        val targetTiles = endCities.keys''', p)
    return s


def make_record(s):
    return once(s, '''    var routeTiles: ArrayList<com.unciv.logic.map.HexCoord> = ArrayList()
''', '''    var routeTiles: ArrayList<com.unciv.logic.map.HexCoord> = ArrayList(),
    var estimatedTransportCost: Int = -1 // GS_ECONOMIC_TRADE_ROUTES_V1: optional for older saves
''', RECORD)


def make_history(s):
    return once(s, '''            item.routeTiles = ArrayList(route.tiles)
''', '''            item.routeTiles = ArrayList(route.tiles)
            item.estimatedTransportCost = route.estimatedTransportCost // GS_ECONOMIC_TRADE_ROUTES_V1
''', HISTORY)


def make_ui(s):
    s = once(s, '''                    add("무역로: $endpoints$routeLabel$steps".toLabel(hideIcons = true)).left().row()
''', '''                    add("무역로: $endpoints$routeLabel$steps".toLabel(hideIcons = true)).left().row()
                    // GS_ECONOMIC_TRADE_ROUTES_V1: index, not actual charged gold.
                    if (it.estimatedTransportCost >= 0)
                        add("추정 운송지수: ${it.estimatedTransportCost} (최단거리 아닌 최소 운송비)".toLabel(hideIcons = true)).left().row()
''', UI)
    s = once(s, '''            add("주무역로는 공유 구간의 임시 관측 결과이며, 상선 이동·금·자원에는 영향이 없습니다.".toLabel(hideIcons = true))
''', '''            add("세계 무역로는 최소 운송지수 경로로 기록됩니다. 운송지수는 실제 금 차감이 아닙니다.".toLabel(hideIcons = true))
''', UI)
    return s


def make_perf(s):
    return once(s, '''        for ((label, key) in groups) {
            val ns = result.durations[key] ?: 0L
            val count = result.counts[key] ?: 0
            lines.add("$label: ${ms(ns)} ms (${count}회)")
        }
''', '''        for ((label, key) in groups) {
            val ns = result.durations[key] ?: 0L
            val count = result.counts[key] ?: 0
            lines.add("$label: ${ms(ns)} ms (${count}회)")
        }
        // GS_ECONOMIC_TRADE_ROUTES_V1: nested in market activity; do not add to totals.
        lines.add("경제 경로 탐색: ${ms(result.durations["market_economic_route"] ?: 0L)} ms " +
            "(${result.counts["market_economic_route"] ?: 0}회, 시장 처리와 중복)")
''', PERF)


def main():
    required = (PLANNER, RECORD, HISTORY, UI, PERF, MK / 'WorldMarketMainRoutes.kt')
    missing = [str(p) for p in required if not p.is_file()]
    if missing:
        raise RuntimeError('Not at Unciv repository root or wrong branch. Missing: ' + ', '.join(missing))
    if ECON.exists() or any(MARK in p.read_text(encoding='utf-8-sig') for p in required):
        raise RuntimeError('Patch already applied or conflicting: no changes made')
    changes = {}
    for p, transform in [(PLANNER, make_planner), (RECORD, make_record),
                         (HISTORY, make_history), (UI, make_ui), (PERF, make_perf)]:
        src = p.read_text(encoding='utf-8-sig')
        changes[p] = transform(src)
    source = SOURCE.read_text()
    if MARK not in source:
        raise RuntimeError('Source payload invalid')
    # Validate all anchors above before modifying any repository files.
    for p, content in changes.items():
        p.write_text(content, encoding='utf-8')
    ECON.write_text(source, encoding='utf-8')
    print('GS economic trade routes v1 applied: six Kotlin files (1 new).')
    print('Run: git diff --check && ./gradlew :android:assembleDebug --no-daemon')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        sys.exit(f'PATCH STOPPED: {exc}')
