# Unciv Grand Strategy — Economic Trade Routes v1

Base branch: **`feature/world-main-routes-v1`** (the build in which thick lime-green global main routes appeared).

## What changes

World-market route *recording*, after a market trade has already settled, changes from multi-source BFS (fewest tiles) to multi-source Dijkstra (lowest estimated shipping-cost index). All seller cities and buyer cities are candidates; no forced capital-to-capital routing.

Provisional costs per segment (abstract **index points**, NOT gold):
- Inland tile: 12 units; coast water: 7; open ocean water: 4.
- Each segment is calculated using the two endpoints' averaged terrain costs, making A→B and B→A symmetrical.
- Land/water transfer is allowed only at an existing coastal city center, with a +16 index surcharge per transition.
- Existing **worldwide capped main-route segments** receive a 25% segment discount. Ordinary branch lanes are still available and may be preferable.
- Main route snapshot is calculated **at most once per game/turn** and reused. Dijkstra expansion is capped at 10,000 settled tiles. The old BFS is a fallback if weighted search fails.
- `MarketTradeRecord.estimatedTransportCost` is an **optional, backward-compatible** save field (`-1` for pre-patch transactions). The trade-history UI shows the new index; old history without cost will not show it.
- New diagnostic `경제 경로 탐색` is reported in performance diagnostics; its time is already part of market activity when called there and must **not** be added twice.

There are **no changes to actual market prices, money, resource transfer, AI buy/sell decisions, military units or game turn timing**. This is only a smarter *observation/path-recording* stage toward virtual ocean/coastal merchants. It does *not* yet form persistent main routes and feeder branches or charge tolls.

## Install from GitHub + Codespaces

1. GitHub repo **`kilerjunny/Unciv`**, select branch `feature/world-main-routes-v1`, choose **Add file → Upload files**, upload `economic-trade-routes-v1.zip` and commit.
2. In existing Codespaces terminal at `/workspaces/Unciv`:

```bash
git switch feature/world-main-routes-v1
git pull --ff-only origin feature/world-main-routes-v1
git switch -c feature/economic-trade-routes-v1
unzip -o economic-trade-routes-v1.zip -d /tmp
python3 /tmp/economic-trade-routes-v1/apply_economic_trade_routes_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

3. After `BUILD SUCCESSFUL`:

```bash
git add core/src/com/unciv/logic/market/WorldMarketEconomicRoutePlanner.kt \
        core/src/com/unciv/logic/market/WorldMarketRoutePlanner.kt \
        core/src/com/unciv/logic/market/MarketTradeRecord.kt \
        core/src/com/unciv/logic/market/WorldMarketHistory.kt \
        core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt \
        core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt
git commit -m "Use economic shipping-cost routes for world-market records"
git push -u origin feature/economic-trade-routes-v1
```

4. At **`https://github.com/kilerjunny/Unciv/actions/workflows/androidBuild.yml`** use `Run workflow` on branch `feature/economic-trade-routes-v1`, download/install the debug APK.

## Verify

- Complete a **new** world-market trade or advance turns to produce AI trades. Existing stored routes are **not retroactively rewritten**.
- Game → 개요 → 거래 → 세계 시장 → **거래 내역**. New trade should show `추정 운송지수` and its tile length.
- Game → 개요 → 거래 → 세계 시장 → **무역 지도**. New observed paths may differ from the shortest path as transport index prefers open ocean and shared global corridors.
- Game → 개요 → 거래 → 세계 시장 → **성능 진단**. Check `경제 경로 탐색` time; compare turns to baseline. Note that this can *increase* CPU load due to Dijkstra, so test on your R40–R50 maps.
- Existing gold balances, inventory, save/load, and real trade settlement must remain unchanged.

## Validation limits

The new weighted Kotlin routing file passed compilation and small synthetic graph tests for port constraints, transport index, multi-source routing and choosing a longer but cheaper trunk. All modified GitHub file anchors were verified against the actual base branch. **Full Android Gradle compile and in-game behavior still require testing in Codespaces/device**.
