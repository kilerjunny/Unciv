#!/usr/bin/env python3
"""Fail-closed, exact-anchor patch for Unciv mobile-dev cash transit tolls v1."""
from pathlib import Path
import sys

ROOT = Path.cwd()
SOURCE = Path(__file__).resolve().parent
BASE = Path("core/src/com/unciv/logic/market")
UI = Path("core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt")
MARK = "GS_WORLD_MARKET_CASH_TOLLS_V1"

changes = {}

def read(path):
    p=ROOT / path
    if not p.exists(): raise RuntimeError(f"Expected source file missing: {path}")
    return p.read_text(encoding="utf-8")

def replace_once(path, old, new):
    src = changes.get(path, read(path))
    n = src.count(old)
    if n != 1: raise RuntimeError(f"Conflict in {path}: expected exactly one anchor, found {n}: {old[:75]!r}")
    changes[path] = src.replace(old, new, 1)

try:
    if not (ROOT / "settings.gradle.kts").exists() and not (ROOT / "settings.gradle").exists():
        raise RuntimeError("Run from the Unciv repository root")
    paths = [BASE / x for x in (
        "MarketTradeRecord.kt", "WorldMarketHistory.kt", "WorldMarketAI.kt") ] + [UI]
    for path in paths:
        if MARK in read(path): raise RuntimeError(f"Patch already present: {path}")
    for name in ("WorldMarketCashTolls.kt", "MarketTollPayment.kt"):
        dest=ROOT / BASE / name
        if dest.exists(): raise RuntimeError(f"New file already exists: {dest}")

    p=BASE / "MarketTradeRecord.kt"
    replace_once(p, '    var portCost: Int = -1\n', '''    var portCost: Int = -1,
    // GS_WORLD_MARKET_CASH_TOLLS_V1: defaults keep old saves untaxed.
    var cashTollGold: Int = 0,
    var cashTollSettled: Boolean = false,
    var cashTollPayments: ArrayList<MarketTollPayment> = ArrayList()
''')

    p=BASE / "WorldMarketHistory.kt"
    replace_once(p, 'fun record(seller: Civilization, buyer: Civilization, resource: String, qty: Int, gold: Int) {\n        if (seller == buyer || qty <= 0 || gold <= 0) return',
'''fun record(seller: Civilization, buyer: Civilization, resource: String, qty: Int, gold: Int): MarketTradeRecord? {
        if (seller == buyer || qty <= 0 || gold <= 0) return null''')
    replace_once(p, '        items.add(item)\n        WorldMarketRouteStats.record(seller.gameInfo, item)\n',
'''        // GS_WORLD_MARKET_CASH_TOLLS_V1: the underlying TradeLogic transfer is already done.
        // A fee may only be paid on a newly completed, successfully routed trade.
        // A route/quote error may NOT undo the original sale or invent revenue.
        try {
            WorldMarketCashTolls.settle(seller, buyer, item)
        } catch (_: Exception) { /* Keep the already-settled trade intact. */ }
        items.add(item)
        WorldMarketRouteStats.record(seller.gameInfo, item)
''')
    replace_once(p, '        if (items.size > 100) items.subList(0, items.size - 100).clear()\n',
'''        if (items.size > 100) items.subList(0, items.size - 100).clear()
        return item
''')

    p=BASE / "WorldMarketAI.kt"
    replace_once(p, '            WorldMarketHistory.record(seller, buyer, resource.name, 1, order.unitPrice)\n\n            seller.addNotification(',
'''            val settledRecord = WorldMarketHistory.record(seller, buyer, resource.name, 1, order.unitPrice)
            val receivedGold = order.unitPrice - (settledRecord?.cashTollGold ?: 0)
            val paidToll = settledRecord?.cashTollGold ?: 0

            seller.addNotification(''')
    replace_once(p,
'''                "세계 시장: [${buyer.civName}]이 [${resource.name}] 1개를 구매했습니다. (+${order.unitPrice}G)",''',
'''                "세계 시장: [${buyer.civName}]이 [${resource.name}] 1개를 구매했습니다. (+${receivedGold}G, 통행료 ${paidToll}G)",''')

    p=UI
    replace_once(p, '추정 운송지수: ${it.estimatedTransportCost} (실제 금 차감 없음)',
                    '추정 운송지수: ${it.estimatedTransportCost} (운송지수는 골드가 아님)')
    replace_once(p,
'''                    // GS_VIRTUAL_MERCHANT_NETWORK_V1: classification of recorded legs.
''',
'''                    // GS_WORLD_MARKET_CASH_TOLLS_V1: actual gold from the seller's sale proceeds.
                    if (it.cashTollSettled) {
                        add("실제 통행료: ${it.cashTollGold}G · 판매국 순수입 ${it.totalGold - it.cashTollGold}G (구매국은 표기가격 지불)".toLabel(hideIcons = true)).left().row()
                        if (it.cashTollPayments.isNotEmpty()) {
                            val recipients = it.cashTollPayments.joinToString(" · ") { payout ->
                                val name = game.getCivilizationOrNull(payout.civId)?.civName?.tr() ?: payout.civId
                                "$name +${payout.gold}G"
                            }
                            add("통행국 국고 수입: $recipients".toLabel(hideIcons = true)).left().row()
                        }
                    }
                    // GS_VIRTUAL_MERCHANT_NETWORK_V1: classification of recorded legs.
''')
    replace_once(p,
'''            add("최근 세계 시장 거래 ${records.size}건 (최대 100건)".toLabel()).left().row()
''',
'''            add("최근 세계 시장 거래 ${records.size}건 (최대 100건)".toLabel()).left().row()
            // GS_WORLD_MARKET_CASH_TOLLS_V1: this is a recent-record subtotal, not lifetime income.
            val myCivId = playerView.getCiv().civID
            val myTollIncome = records.sumOf { record ->
                record.cashTollPayments.filter { it.civId == myCivId }.sumOf { it.gold }
            }
            val myTollPaid = records.filter { it.sellerCivId == myCivId }.sumOf { it.cashTollGold }
            add("최근 거래 기록 기준 내 통행료 수입 ${myTollIncome}G · 지출 ${myTollPaid}G".toLabel(hideIcons = true)).left().row()
''')

    # All assertions passed; only now write the modified sources. No broad git add .
    for path, content in changes.items(): (ROOT / path).write_text(content, encoding="utf-8")
    for name in ("WorldMarketCashTolls.kt", "MarketTollPayment.kt"):
        (ROOT / BASE / name).write_bytes((SOURCE / name).read_bytes())
    print("GS cash transit tolls v1 applied. Files:")
    for path in changes: print("  modified", path)
    for name in ("WorldMarketCashTolls.kt", "MarketTollPayment.kt"):
        print("  created", BASE / name)
    print("Next: git diff --check && ./gradlew :android:assembleDebug --no-daemon")
except Exception as e:
    sys.exit(f"PATCH STOPPED: {e}; no files changed")
