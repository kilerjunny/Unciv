# Unciv Grand Strategy — 실제 제3국 통행료 정산 v1

기준: `mobile-dev`, `territory-tolls-supply-v1` 이후. **기존 게임 저장파일을 먼저 백업하세요.**

## 적용 내용

- 세계 시장 거래가 정상적으로 완료된 **직후**, 기존 판매대금에서 제3국 영토 통행료/제3국 항만료를 공제해 통과국에 지급합니다.
- 구매국은 기존 표시 가격만 내며, 판매자는 `가격 - 실제 통행료`를 받습니다. 통과국 수입 총합은 판매자 공제액과 같습니다. **골드를 생성하지 않습니다.**
- 같은 제3국의 육상 영토에 여러 번 진입해도 국가당 육상 기본료 한 번(우호 1G, 그 외 2G). 제3국 도시 항구를 실제로 사용하면 국가당 추가 1G.
- 적대국, 판매국 및 구매국은 실제 통행료 수령 대상에서 제외합니다. 공해 통행료 없음.
- 총 수수료 상한: `min(6G, floor(거래가격 * 8 / 100))`: 25G→2G, 50G→4G, 300G→6G.
- 판매자의 이미 확정된 판매 수입을 공제하는 사후 분배 방식입니다. 판매국이 실제 통행료를 지불할 수 없는 경우 또는 경로 탐색이 실패한 경우에는 지급하지 않습니다.
- 보급료 및 기존 통행료 *지수*는 경로 선택에만 사용합니다. 이 패치로 지수=골드가 되지는 않습니다.
- 세계 시장의 플레이어 구매와 AI 자동 구매 양쪽에 적용합니다. 군수시장/일반 외교 거래에는 적용하지 않습니다.
- 이전 저장파일의 기록에는 소급 적용하지 않습니다. 새 거래 기록에만 `실제 통행료 0~6G`, 국가별 수령액이 추가됩니다.
- 거래 내역 상단에는 **최근 거래 기록 100건 기준** 내 통행료 수입/지출 소계가 표시됩니다. 이는 전 기간 누적 수익이 아닙니다.

## 경계

- 적대국 영토의 완전한 통과 금지 및 봉쇄 시스템은 아직 없음 (기존의 높은 추정 운송비 지수만 유지).
- 해협을 지나가기만 해서는 항만료 발생 안 함. 실제 외국 항구 진입/출항에만 적용.
- 경로가 완성되지 않았거나 과거 저장파일의 거래 기록에는 추가 지급 없음.
- Android 빌드 및 실제 장기 게임 동작은 별도 검증 필요.

## 적용

GitHub에서 `mobile-dev` 브랜치의 `Add file → Upload files`로 ZIP을 업로드해 커밋합니다.

Codespaces 저장소 루트에서 실행:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o world-market-cash-tolls-v1.zip -d /tmp
python3 /tmp/world-market-cash-tolls-v1/apply_world_market_cash_tolls_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

**`BUILD SUCCESSFUL`인 경우에만** 다음을 실행:

```bash
git add core/src/com/unciv/logic/market/MarketTradeRecord.kt
git add core/src/com/unciv/logic/market/MarketTollPayment.kt
git add core/src/com/unciv/logic/market/WorldMarketCashTolls.kt
git add core/src/com/unciv/logic/market/WorldMarketHistory.kt
git add core/src/com/unciv/logic/market/WorldMarketAI.kt
git add core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git rm world-market-cash-tolls-v1.zip
git diff --cached --stat
git commit -m "Settle small third-country transit tolls from market sales"
git push origin mobile-dev
```

GitHub Actions `androidBuild.yml`에서 브랜치 `mobile-dev`로 APK 빌드/설치.

## 테스트

1. 게임을 백업하고 신규 세계 시장 거래를 한 번 이상 생성.
2. `개요 → 거래 → 세계 시장 → 거래 내역`: 상품가격, 추정 운송지수, 실제 통행료(G), 통행국 이름과 수익, 판매국 순수입 확인.
3. 제3국 영토/외국 항구 경유 거래: 판매국 순수입 + 통행국 총수익 = 거래대금.
4. 양국 직항/공해만 운항하는 경우 실제 통행료 0G인 것이 정상.
5. 일반 외교 거래와 군수 시장이 영향받지 않는지, 자동 구매/게임 저장/불러오기가 되는지 확인.
6. `성능 진단`에서 턴 처리 시간, 기존 시장 자동 구매/경제 경로 탐색 시간 비교.

## 검증

- 실제 Kotlin 파일을 최소 가짜 게임 객체로 컴파일/실행: 상한, 분배, 적대국 제외, 총량 보존, 재호출 무효화, 경로 미확인 0G 통과.
- 실제 `mobile-dev` 파일과 수정 앵커 개수 일치 확인.
- 적용 스크립트를 테스트 저장소에 실행했고, 2회 실행은 수정 없이 중단됨을 확인.
- 전체 Unciv 프로젝트 Gradle 빌드 및 Android 런타임은 **확인 필요**.
