# Grand Strategy 시장 국가별 목록 패치 v1.5

기준: `feature/world-market-v14` (군수 시장 v1.3.7 포함)

## 변경 내용

- **세계 자원 시장:** 판매국별로 묶고, 국가를 클릭하면 그 국가의 자원 판매 목록을 펼칩니다. 기존 가격 정렬 버튼은 제거합니다.
- **군수 시장:** 판매국별로 묶고, 고유 병종을 판매하는 국가를 위에 배치합니다. 국가를 누르면 고유 병종이 일반 병종보다 먼저 나오며, 가격·도시·예상 생산 턴·발주 버튼은 유지합니다.
- 시장의 한글 검색, 예산·전략자원 필터, 거래 승인·거절, AI, 가격 계산 및 저장 데이터는 건드리지 않습니다.
- 처음에는 모든 국가가 접혀 있으며 검색 결과에 맞는 국가만 표시됩니다.

## 적용

1. 이 ZIP을 GitHub `feature/world-market-v14` 브랜치 루트에 업로드하고 커밋합니다.
2. Codespaces에서 `git pull --ff-only origin feature/world-market-v14` 실행
3. `unzip -o grand_strategy_market_country_groups_v15.zip`
4. `python3 gs_market_country_groups_v15/install.py --check`
5. `python3 gs_market_country_groups_v15/install.py --apply`
6. `python3 gs_market_country_groups_v15/install.py --verify`
7. `./gradlew :core:compileKotlin --no-daemon --console=plain`
8. 빌드가 성공한 경우 두 Kotlin 파일만 지정해 `git add` / `git commit` / `git push`

이 설치 프로그램의 사전 검증은 **Kotlin 컴파일을 대체하지 않습니다.**
