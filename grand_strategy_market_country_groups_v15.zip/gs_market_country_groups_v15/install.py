#!/usr/bin/env python3
"""Grand Strategy market UI v1.5 - expand by seller; show unique military units first.

Only touches two Kotlin UI sources. Does not change market logic, prices, saves, or AI.
Usage: python3 gs_market_country_groups_v15/install.py --check|--apply|--verify
"""
import argparse
import os
from pathlib import Path
import shutil
import tempfile

ROOT = Path(__file__).resolve().parent.parent
WORLD = Path('core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt')
MILITARY = Path('core/src/com/unciv/ui/screens/overviewscreen/MilitaryMarketSection.kt')
WORLD_MARKER = '// GS_MARKET_COUNTRY_GROUPS_V15_WORLD'
MILITARY_MARKER = '// GS_MARKET_COUNTRY_GROUPS_V15_MILITARY'


def once(src: str, old: str, new: str, desc: str) -> str:
    count = src.count(old)
    if count != 1:
        raise RuntimeError(f'{desc}: expected exactly one matching block, found {count}. No changes made.')
    return src.replace(old, new, 1)


def transform_world(s: str) -> str:
    s = once(s, '    private var priceSort = false\n',
        f'    {WORLD_MARKER}\n    private val expandedSellerIds = mutableSetOf<String>()\n',
        'world state')

    old_sort = '''        val sortButton = TextButton(if (priceSort) "가격순: 낮은 가격" else "정렬: 자원명", BaseScreen.skin)
        sortButton.onClick {
            priceSort = !priceSort
            render()
            parentTab.overviewScreen.resizePage(parentTab)
        }
        filters.add(sortButton)
'''
    s = once(s, old_sort, '', 'remove world price sorting control')

    old_order = '''            .sortedWith(
                if (priceSort) compareBy<com.unciv.logic.market.MarketSellOrder>(
                    { it.unitPrice }, { it.resourceName }, { it.id })
                else compareBy<com.unciv.logic.market.MarketSellOrder>(
                    { it.resourceName }, { it.unitPrice }, { it.sellerCivId }, { it.id })
            )
'''
    new_order = '''            .sortedWith(compareBy<com.unciv.logic.market.MarketSellOrder>(
                { it.sellerCivId }, { it.resourceName }, { it.unitPrice }, { it.id }))
'''
    s = once(s, old_order, new_order, 'world sorting by country')

    old_label = '        add("검색 결과 ${orders.size}건 · 자원 유형 및 가격 필터 적용".toLabel()).left().row()\n'
    new_label = '        add("검색 결과 ${orders.size}건 · 판매국을 눌러 상품 보기".toLabel()).left().row()\n'
    s = once(s, old_label, new_label, 'world section label')

    start_tag = '        for (order in orders.take(100)) {\n'
    footer = ('        if (orders.size > 100)\n'
              '            add("화면 성능을 위해 상품 100건만 표시합니다. 검색으로 범위를 좁혀주세요.".toLabel()).left().row()\n')
    start = s.find(start_tag)
    end = s.find(footer)
    if start < 0 or end < 0 or end <= start:
        raise RuntimeError('world: market rows or footer not found. No changes made.')
    old_loop = s[start:end]
    if not old_loop.endswith('        }\n') or old_loop.count(start_tag) != 1:
        raise RuntimeError('world: unexpected item loop ending. No changes made.')
    body = old_loop[len(start_tag):-len('        }\n')]
    seller_lookup = '''            val seller = gameInfo.civilizations.firstOrNull {
                it.civID == order.sellerCivId
            } ?: continue

'''
    if not body.startswith(seller_lookup):
        raise RuntimeError('world: seller lookup differs from expected layout. No changes made.')
    body = body[len(seller_lookup):]
    indented = ''.join(('    ' + line if line.strip() else line) for line in body.splitlines(keepends=True))
    new_loop = '''        // Seller groups are closed by default; expand one to see its purchasable resources.
        val visibleOrders = orders.take(500)
        val bySeller = visibleOrders.groupBy { it.sellerCivId }
        for ((sellerId, sellerOrders) in bySeller.toList().sortedBy { (id, _) ->
            gameInfo.civilizations.firstOrNull { it.civID == id }?.civName?.tr() ?: id
        }) {
            val seller = gameInfo.civilizations.firstOrNull { it.civID == sellerId } ?: continue
            val expanded = sellerId in expandedSellerIds
            val sellerButton = TextButton(
                "${if (expanded) "접기" else "펼치기"} · ${seller.civName.tr()} · ${sellerOrders.size}종",
                BaseScreen.skin)
            sellerButton.onClick {
                if (!expandedSellerIds.add(sellerId)) expandedSellerIds.remove(sellerId)
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            add(sellerButton).left().growX().padTop(6f).row()
            if (!expanded) continue
            for (order in sellerOrders) {
''' + indented + '''            }
        }
'''
    new_footer = ('        if (orders.size > 500)\n'
                  '            add("화면 성능을 위해 상품 500건만 표시합니다. 검색으로 범위를 좁혀주세요.".toLabel()).left().row()\n')
    return s[:start] + new_loop + new_footer + s[end + len(footer):]


def transform_military(s: str) -> str:
    s = once(s, '    private var searchQuery = ""\n',
        f'    private var searchQuery = ""\n    {MILITARY_MARKER}\n    private val expandedSellerIds = mutableSetOf<String>()\n',
        'military seller expansion state')
    s = once(s,
        'val offers = MilitaryMarket.offersFor(civ, limit = if (query.isEmpty()) 100 else 500)',
        'val offers = MilitaryMarket.offersFor(civ, limit = 500)',
        'military larger preview catalogue')
    s = once(s, '            }.take(100).toList()\n', '            }.toList()\n',
        'military filter no 100-item UI cap')
    start_tag = '        for (offer in offers) {\n'
    footer = '        if (offers.size >= 100) add("화면 성능을 위해 최대 100개 상품을 표시합니다.".toLabel()).left().row()\n'
    start = s.find(start_tag)
    end = s.find(footer)
    if start < 0 or end < 0 or end <= start:
        raise RuntimeError('military: offer rows or cap label not found. No changes made.')
    old_loop = s[start:end]
    if not old_loop.endswith('        }\n'):
        raise RuntimeError('military: unexpected offer loop ending. No changes made.')
    body = old_loop[len(start_tag):-len('        }\n')]
    seller_lookup = '            val seller = game.getCivilizationOrNull(offer.sellerId) ?: continue\n'
    if not body.startswith(seller_lookup):
        raise RuntimeError('military: seller lookup differs from expected layout. No changes made.')
    body = body[len(seller_lookup):]
    indented = ''.join(('    ' + line if line.strip() else line) for line in body.splitlines(keepends=True))
    new_loop = '''        // Unique units are displayed first within each seller, independent of price.
        val specialUnit: (MilitaryMarket.Offer) -> Boolean = { offer ->
            val unit = game.ruleset.units[offer.unitName]
            unit?.uniqueTo != null || unit?.replaces != null
        }
        val bySeller = offers.groupBy { it.sellerId }
            .toList()
            .sortedWith(compareByDescending<Pair<String, List<MilitaryMarket.Offer>>> { (_, list) ->
                list.count { specialUnit(it) }
            }.thenBy { (id, _) -> game.getCivilizationOrNull(id)?.civName?.tr() ?: id })
        add("판매국을 선택하세요 · 고유 병종 보유 국가 우선".toLabel()).left().row()
        for ((sellerId, sellerOffers) in bySeller) {
            val seller = game.getCivilizationOrNull(sellerId) ?: continue
            val specialCount = sellerOffers.count { specialUnit(it) }
            val expanded = sellerId in expandedSellerIds
            val sellerButton = TextButton(
                "${if (expanded) "접기" else "펼치기"} · ${seller.civName.tr()} · ${sellerOffers.size}종 · 고유 병종 ${specialCount}종",
                BaseScreen.skin)
            sellerButton.onClick {
                if (!expandedSellerIds.add(sellerId)) expandedSellerIds.remove(sellerId)
                refresh()
            }
            add(sellerButton).left().growX().padTop(6f).row()
            if (!expanded) continue
            val prioritized = sellerOffers.sortedWith(
                compareByDescending<MilitaryMarket.Offer> { specialUnit(it) }
                    .thenBy { it.unitName.tr() }
                    .thenBy { it.price })
            for (offer in prioritized) {
''' + indented + '''            }
        }
'''
    new_footer = '        if (offers.size >= 500) add("최대 500개 상품까지 조회합니다. 검색으로 범위를 좁혀주세요.".toLabel()).left().row()\n'
    return s[:start] + new_loop + new_footer + s[end + len(footer):]


def check_patched(world_text: str, military_text: str) -> None:
    assert world_text.count(WORLD_MARKER) == 1
    assert military_text.count(MILITARY_MARKER) == 1
    assert 'for ((sellerId, sellerOrders) in bySeller' in world_text
    assert 'for ((sellerId, sellerOffers) in bySeller)' in military_text
    assert 'sellerOffers.sortedWith(' in military_text
    assert 'private var priceSort' not in world_text
    assert 'if (offers.size >= 100)' not in military_text


def write_atomic(path: Path, content: str) -> None:
    fd, tmp = tempfile.mkstemp(prefix=path.name+'.', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(content)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def main() -> None:
    parser = argparse.ArgumentParser()
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--check', action='store_true')
    modes.add_argument('--apply', action='store_true')
    modes.add_argument('--verify', action='store_true')
    args = parser.parse_args()
    if not (ROOT / '.git').is_dir():
        raise SystemExit('ERROR: extract the ZIP at the Unciv repository root.')
    paths = [ROOT / WORLD, ROOT / MILITARY]
    if not all(p.is_file() for p in paths):
        raise SystemExit('ERROR: both Kotlin UI source files must exist. No changes made.')
    old = [p.read_text(encoding='utf-8') for p in paths]
    ready = [WORLD_MARKER in old[0], MILITARY_MARKER in old[1]]
    if args.verify:
        try:
            check_patched(*old)
        except AssertionError:
            raise SystemExit('VERIFY ERROR: seller grouping patch is incomplete.')
        print('VERIFY OK: country-grouped resources + unique-first military market.')
        return
    try:
        new = [old[0] if ready[0] else transform_world(old[0]),
               old[1] if ready[1] else transform_military(old[1])]
        check_patched(*new)
    except (RuntimeError, AssertionError) as exc:
        raise SystemExit(f'PATCH ERROR: {exc}')
    if args.check:
        print('CHECK OK: seller expansion + unique-first units patch applicable; no files changed.')
        return
    if all(ready):
        print('APPLY OK: already installed; no changes made.')
        return
    backup = Path('/tmp/gs_market_country_groups_v15_backup')
    backup.mkdir(exist_ok=True)
    for p, before, after in zip(paths, old, new):
        if before == after: continue
        (backup / p.name).write_text(before, encoding='utf-8')
        write_atomic(p, after)
        print('APPLY OK:', p.relative_to(ROOT))
    print('Backup:', backup)

if __name__ == '__main__':
    main()
