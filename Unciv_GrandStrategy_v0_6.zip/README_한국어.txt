Unciv Grand Strategy v0.6 / 단계별 편제 탐색 업데이트

적용 대상: kilerjunny/Unciv 저장소의 grand-strategy-formations 브랜치
원본 master 브랜치에 적용하지 마세요.

새 기능
- 선택한 편제의 바로 아래 하위 편제만 왼쪽 목록에 표시
- 해군성 -> 동방함대 -> 전위전대와 같이 한 단계씩 탐색
- 상단 경로 버튼으로 상위 편제로 즉시 이동
- 상위 편제 버튼으로 한 단계 뒤로 가기
- 전체 조직망 버튼: 모든 편제의 연결 관계를 ASCII 연결선으로 표시 (자유 이동 그래프는 아님)
- 오른쪽은 현재 선택한 편제의 직속 유닛, 배속/전속/편제 관리
- 종전의 유닛 터치 -> 지도 이동 기능 유지
- 깊은 하위 편제 유닛 목록은 현재 단계에서 숨기며, 해당 하위 편제로 들어가면 표시

기존 편제 및 저장 파일
- Civilization 저장 필드와 FormationManager는 변경하지 않습니다.
- 이미 생성한 편제/유닛 배속 데이터를 지우지 않습니다.
- 군사력 순위, AI, Tech Stopper 모드와 무관한 UI 한 파일만 변경합니다.

설치
1. GitHub 저장소 grand-strategy-formations 브랜치의 최상위 폴더에 ZIP 파일 업로드
2. Codespaces 터미널에서 grand-strategy-formations 브랜치인지 확인
3. 리포지토리 최상위 폴더에서 다음 한 줄 실행

   git pull --ff-only origin grand-strategy-formations && unzip -o Unciv_GrandStrategy_v0_6.zip && bash apply_v0_6.sh

4. SUCCESS 메시지가 나타나면 GitHub Actions > Android build 확인
5. 빌드가 성공한 후 APK ZIP을 다운로드, 압축 해제
6. 기존 Grand Strategy 앱을 삭제하지 말고 업데이트 설치

주의
- 앱 빌드/실기기 동작은 별도 확인이 필요합니다.
- v0.6은 저장 데이터 형식 변경이 없으나, 안전을 위해 중요 세이브 백업을 권장합니다.
- ZIP 파일은 압축해제 및 적용 스크립트 실행 전까지 앱을 바꾸지 않습니다.
