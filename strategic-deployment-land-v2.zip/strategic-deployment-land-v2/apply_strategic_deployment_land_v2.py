#!/usr/bin/env python3
"""Patch mobile-dev StrategicDeploymentAI V2 for land-only border defence.

Use after GS_STRATEGIC_DEPLOYMENT_AI_V2 naval deployment is already present.
No changes to saved game schema. Rejects unexpected file baselines before writing.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

TAG = "GS_STRATEGIC_DEPLOYMENT_LAND_V2"
ROOT = Path.cwd()
BASE = Path("core/src/com/unciv/logic")
STRATEGY = ROOT / BASE / "automation/civilization/StrategicDeploymentAI.kt"
UNIT = ROOT / BASE / "automation/unit/UnitAutomation.kt"
PERF = ROOT / BASE / "automation/civilization/GrandStrategyPerf.kt"


def replace_exact(src: str, old: str, new: str, label: str) -> str:
    n = src.count(old)
    if n != 1:
        raise RuntimeError(f"{label}: expected exactly one anchor, found {n}; no files changed")
    return src.replace(old, new, 1)


def branch_guard() -> None:
    p = subprocess.run(["git", "branch", "--show-current"], cwd=ROOT,
                       text=True, capture_output=True)
    if p.returncode or p.stdout.strip() != "mobile-dev":
        raise RuntimeError("Run only in the mobile-dev branch, at the Unciv repository root")


def main() -> None:
    branch_guard()
    paths = (STRATEGY, UNIT, PERF)
    for path in paths:
        if not path.is_file():
            raise RuntimeError(f"Missing expected file: {path}")
    a, b, c = (p.read_text(encoding="utf-8") for p in paths)
    if TAG in a or TAG in b or TAG in c:
        if TAG in a and TAG in b and TAG in c:
            print("Already applied: GS land deployment v2 (no changes)")
            return
        raise RuntimeError("Partial application detected; inspect git diff before retrying")
    if "GS_STRATEGIC_DEPLOYMENT_AI_V2" not in a:
        raise RuntimeError("Naval strategic deployment AI v2 is required first")

    a = replace_exact(a,
        "import com.unciv.logic.civilization.Civilization\n",
        "import com.unciv.logic.civilization.Civilization\n"
        "import com.unciv.logic.civilization.diplomacy.RelationshipLevel\n",
        "import relationship")

    a = replace_exact(a,
        "    // Weak keys + values containing IDs only avoid retaining discarded games.\n"
        "    private val plans = WeakHashMap<Civilization, Plan>()\n",
        "    // Weak keys + values containing IDs only avoid retaining discarded games.\n"
        "    private val plans = WeakHashMap<Civilization, Plan>()\n\n"
        "    // GS_STRATEGIC_DEPLOYMENT_LAND_V2: a coast across a strait is not a land border.\n"
        "    // A shared land continent is required; relationship adjusts the guard priority.\n"
        "    private fun landBorderRisk(civ: Civilization, center: Tile, continent: Int): Int {\n"
        "        if (!center.isLand || continent < 0) return 0\n"
        "        val neighbors = center.getTilesInDistance(5)\n"
        "            .filter { it.isLand && it.getContinent() == continent }\n"
        "            .mapNotNull { it.getOwner() }\n"
        "            .filter { it != civ && it.isMajorCiv() }\n"
        "            .distinct()\n"
        "        return neighbors.map { other ->\n"
        "            when (civ.getDiplomacyManager(other)?.relationshipIgnoreAfraid()) {\n"
        "                RelationshipLevel.Unforgivable, RelationshipLevel.Enemy -> 2\n"
        "                RelationshipLevel.Favorable, RelationshipLevel.Friend,\n"
        "                RelationshipLevel.Ally -> 0\n"
        "                else -> 1\n"
        "            }\n"
        "        }.maxOrNull() ?: 0\n"
        "    }\n",
        "insert border risk")

    a = replace_exact(a,
        "            val border = center.getTilesInDistance(5).any { tile ->\n"
        "                val owner = tile.getOwner()\n"
        "                owner != null && owner != civ && owner.isMajorCiv()\n"
        "            }\n"
        "            val priority = (if (city.isCapital()) 30 else 0) +\n"
        "                (if (border) 35 else 0) +\n"
        "                (if (overseas) 25 else 0) +\n"
        "                (if (city.isNaval()) 10 else 0)\n"
        "            val landSlots = if (border) 3 else if (city.isCapital() || overseas) 2 else 1\n"
        "            val navalSlots = if (city.isNaval()) {\n"
        "                if (border || overseas) 2 else 1\n"
        "            } else 0\n",
        "            val borderRisk = landBorderRisk(civ, center, continent)\n"
        "            // Keep sea-facing harbor defence even when there is no LAND border.\n"
        "            val seaBorder = city.isNaval() && center.getTilesInDistance(5).any { tile ->\n"
        "                val owner = tile.getOwner()\n"
        "                owner != null && owner != civ && owner.isMajorCiv()\n"
        "            }\n"
        "            val priority = (if (city.isCapital()) 30 else 0) +\n"
        "                (if (borderRisk == 2) 35 else if (borderRisk == 1) 15 else 0) +\n"
        "                (if (overseas) 25 else 0) +\n"
        "                (if (city.isNaval()) 10 else 0) +\n"
        "                (if (seaBorder && borderRisk == 0) 10 else 0)\n"
        "            val landSlots = when {\n"
        "                borderRisk == 2 -> 3\n"
        "                borderRisk == 1 -> 2\n"
        "                city.isCapital() || overseas -> 2\n"
        "                else -> 1\n"
        "            }\n"
        "            val navalSlots = if (city.isNaval()) {\n"
        "                if (seaBorder || overseas) 2 else 1\n"
        "            } else 0\n",
        "land/sea border split")

    a = replace_exact(a,
        "                val closest = pool.minWithOrNull(compareBy<MapUnit> { unit ->\n"
        "                    val otherContinent = !unit.baseUnit.isWaterUnit &&\n"
        "                        goal.continent >= 0 && unit.currentTile.getContinent() >= 0 &&\n"
        "                        unit.currentTile.getContinent() != goal.continent\n"
        "                    unit.currentTile.aerialDistanceTo(center) + if (otherContinent) 15 else 0\n"
        "                }.thenBy { it.id }) ?: return@repeat\n",
        "                // Land troops defend their existing landmass. No peacetime\n"
        "                // cross-sea reinforcement orders solely for a border garrison.\n"
        "                val closest = pool.asSequence().filter { unit ->\n"
        "                    unit.baseUnit.isWaterUnit || (goal.continent >= 0 &&\n"
        "                        unit.currentTile.isLand &&\n"
        "                        unit.currentTile.getContinent() == goal.continent)\n"
        "                }.minWithOrNull(compareBy<MapUnit> { unit ->\n"
        "                    unit.currentTile.aerialDistanceTo(center)\n"
        "                }.thenBy { it.id }) ?: return@repeat\n",
        "same-continent land assignments")

    a = replace_exact(a,
        "        val unreachableLand = HashSet<Int>()\n",
        "        val unreachableLand = HashSet<Int>()\n"
        "        // Never hand an embarked defensive assignment back to stock AI next turn.\n"
        "        val blockedLandEmbark = HashSet<Int>()\n",
        "blocked embark state")

    a = replace_exact(a,
        "    /** Return true when a defensive assignment handled the unit's decision. */\n",
        "    /**\n"
        "     * An existing embarked AI land unit is NOT a fresh overseas deployment.\n"
        "     * In peace, first try to disembark on reachable owned land. A failed\n"
        "     * check falls back to stock AI and is throttled until plan refresh.\n"
        "     */\n"
        "    private fun tryDisembarkToOwnedLand(unit: MapUnit, plan: Plan): Boolean {\n"
        "        if (unit.id in plan.unreachableLand) return false\n"
        "        if (!unit.hasMovement()) return true\n"
        "        val civ = unit.civ\n"
        "        val origin = unit.currentTile\n"
        "        val coast = civ.cities.asSequence()\n"
        "            .flatMap { it.getCenterTile().getTilesInDistance(2) }\n"
        "            .filter { it.isLand && it.getOwner() == civ && !it.isImpassible() &&\n"
        "                (it.militaryUnit == null || it.militaryUnit == unit) }\n"
        "            .distinct().sortedBy { it.aerialDistanceTo(origin) }\n"
        "        var checks = 0\n"
        "        for (target in coast) {\n"
        "            if (!unit.movement.canMoveTo(target)) continue\n"
        "            if (checks >= MAX_LAND_REACH_CHECKS) break\n"
        "            checks++\n"
        "            if (!unit.movement.canReach(target)) continue\n"
        "            try {\n"
        "                val before = unit.currentTile\n"
        "                unit.movement.headTowards(target)\n"
        "                if (unit.currentTile != before) {\n"
        "                    GrandStrategyPerf.addCount(\"strategic_land_sea_return_moves\", 1)\n"
        "                    return true\n"
        "                }\n"
        "            } catch (_: UnitMovement.UnreachableDestinationException) {\n"
        "                // An occupied coastal tile can invalidate a checked route.\n"
        "            }\n"
        "        }\n"
        "        plan.unreachableLand.add(unit.id)\n"
        "        GrandStrategyPerf.addCount(\"strategic_land_sea_return_failures\", 1)\n"
        "        return false\n"
        "    }\n\n"
        "    /** Return true when a defensive assignment handled the unit's decision. */\n",
        "embarked land recovery")

    a = replace_exact(a,
        "        val plan = planFor(civ)\n"
        "        val naval = unit.baseUnit.isWaterUnit\n"
        "        val destinationCityId = if (naval) {\n",
        "        val plan = planFor(civ)\n"
        "        val naval = unit.baseUnit.isWaterUnit\n"
        "        // GS_STRATEGIC_DEPLOYMENT_LAND_V2: recover existing embarked land troops.\n"
        "        if (!naval && unit.isEmbarked())\n"
        "            return tryDisembarkToOwnedLand(unit, plan)\n"
        "        val destinationCityId = if (naval) {\n",
        "invoke sea recovery")

    a = replace_exact(a,
        "        if (!naval && unit.id in plan.unreachableLand) return false\n",
        "        if (!naval && unit.id in plan.unreachableLand)\n"
        "            return unit.id in plan.blockedLandEmbark\n",
        "persistent blocked embark")

    a = replace_exact(a,
        "        var checks = 0\n"
        "        val maxChecks = if (naval) MAX_NAVAL_REACH_CHECKS else MAX_LAND_REACH_CHECKS\n",
        "        var checks = 0\n"
        "        var blockedEmbark = false\n"
        "        val maxChecks = if (naval) MAX_NAVAL_REACH_CHECKS else MAX_LAND_REACH_CHECKS\n",
        "new blocked flag")

    a = replace_exact(a,
        "            try {\n"
        "                val before = unit.currentTile\n"
        "                unit.movement.headTowards(tile)\n",
        "            try {\n"
        "                // Even on one continent the shortest route may cut across water.\n"
        "                // Guard moves must never issue a new embark order in peace.\n"
        "                if (!naval && origin.isLand &&\n"
        "                    unit.movement.getTileToMoveToThisTurn(tile).isWater) {\n"
        "                    blockedEmbark = true\n"
        "                    GrandStrategyPerf.addCount(\"strategic_land_embark_blocked\", 1)\n"
        "                    continue\n"
        "                }\n"
        "                val before = unit.currentTile\n"
        "                unit.movement.headTowards(tile)\n",
        "prevent new peacetime embark")

    a = replace_exact(a,
        "        plan.unreachableLand.add(unit.id)\n"
        "        GrandStrategyPerf.addCount(\"strategic_deploy_unreachable\", 1)\n"
        "        return false\n",
        "        plan.unreachableLand.add(unit.id)\n"
        "        if (blockedEmbark) plan.blockedLandEmbark.add(unit.id)\n"
        "        GrandStrategyPerf.addCount(\"strategic_deploy_unreachable\", 1)\n"
        "        // Holding a defensive position is better than boarding a ship solely\n"
        "        // because the shortest route cuts across a strait.\n"
        "        return blockedEmbark\n",
        "land fallback guard")

    # Move land deployment before optional barbarian camp searches. This also
    # allows stranded embarked troops to attempt a safe landing before roaming.
    b = replace_exact(b,
        "        if (tryHeadTowardsEncampment(unit)) return\n\n"
        "        // Land troops retain the v1 garrison decision priority.\n"
        "        if (unit.civ.isAI() && !unit.civ.isAtWar() && !unit.baseUnit.isWaterUnit &&\n"
        "            GrandStrategyPerf.measure(\"unit_strategic_deployment\") { StrategicDeploymentAI.tryDeploy(unit) }) return\n",
        "        // GS_STRATEGIC_DEPLOYMENT_LAND_V2: peacetime land defence and\n"
        "        // existing embarked-unit recovery precede optional camp roaming.\n"
        "        if (unit.civ.isAI() && !unit.civ.isAtWar() && !unit.baseUnit.isWaterUnit &&\n"
        "            GrandStrategyPerf.measure(\"unit_strategic_deployment\") { StrategicDeploymentAI.tryDeploy(unit) }) return\n\n"
        "        if (tryHeadTowardsEncampment(unit)) return\n",
        "land decision order")

    c = replace_exact(c,
        "        // GS_AI_PATH_PRECHECK_V2: counts are per checked military AI decision,\n",
        "        // GS_STRATEGIC_DEPLOYMENT_LAND_V2: these are diagnostic counts, not extra times.\n"
        "        lines.add(\"육군 불필요 승선 차단: ${result.counts[\"strategic_land_embark_blocked\"] ?: 0}회 / \" +\n"
        "            \"기존 승선 지상군 귀환 이동: ${result.counts[\"strategic_land_sea_return_moves\"] ?: 0}회 / \" +\n"
        "            \"귀환 경로 실패: ${result.counts[\"strategic_land_sea_return_failures\"] ?: 0}회\")\n"
        "        // GS_AI_PATH_PRECHECK_V2: counts are per checked military AI decision,\n",
        "append land metrics")

    # All preflight checks must have passed before any writes.
    for path, content in zip(paths, (a, b, c)):
        path.write_text(content, encoding="utf-8")
        print("PATCHED", path.relative_to(ROOT))
    print("OK - now run git diff --check and ./gradlew :android:assembleDebug --no-daemon")


if __name__ == "__main__":
    main()
