# Strategic Deployment AI — Land Border v2 (Android mobile-dev)

2026-11-10 · Intended baseline: `mobile-dev` after naval-deployment v2 and military return-home save key fix.

## Purpose

Prevent peacetime AI land defenders from embarking merely to garrison a city across a strait.

- Land-border detection now checks foreign **land** belonging to the same continent and adjusts garrison priority for relationships. Enemy/unforgivable: high, neutral/competitor: moderate, favorable/friend/ally: low.
- Sea-facing foreign coast still contributes to naval defense; naval v2 is preserved.
- Only land units **already on the target continent** may be assigned a peacetime land garrison on that continent. Overseas cities are supplied by existing local garrisons rather than automatically shipping mainland troops across seas.
- Peacetime land assignments check the next movement step; if the next step would enter water, the AI holds its defensive assignment and tries again at the next plan refresh (5 turns) instead of embarking on that path.
- Existing **embarked** AI land units attempt to land on the nearest reachable owned land within city vicinities, using at most 3 full reachability checks per decision. They are not teleported. If no route is found, the ordinary AI may try another action.
- Land placement now runs before optional barbarian-camp roaming, but **after** local combat/critical defensive logic. Wartime AI and player units are untouched.
- New counters in Merchant tab / performance diagnostic: blocked peacetime embark steps, existing embarked troop returns, and failed return paths. Counts can repeat across turns; they are not unique unit counts.
- No save format changes, no military unit deletion, no automatic orders for human units.

## Apply in GitHub Codespaces

Upload `strategic-deployment-land-v2.zip` to root of `mobile-dev` branch and commit that upload, then:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o strategic-deployment-land-v2.zip -d /tmp
python3 /tmp/strategic-deployment-land-v2/apply_strategic_deployment_land_v2.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

Only after **BUILD SUCCESSFUL**:

```bash
git add core/src/com/unciv/logic/automation/civilization/StrategicDeploymentAI.kt
git add core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt
git add core/src/com/unciv/logic/automation/unit/UnitAutomation.kt
git rm --ignore-unmatch strategic-deployment-land-v2.zip
git diff --cached --check
git commit -m "Constrain peacetime land border deployment v2"
git push origin mobile-dev
```

Build the Android APK from the new push, then install **without clearing app data**. Backup the important save and test by moving 5-10 turns in peace. Compare naval/land unit behavior and diagnostics; confirm no AI land unit boards a ship **solely for a new border garrison**.

## Limits and testing

- This only controls `StrategicDeploymentAI`'s peaceful defensive deployment and existing embarked-unit recovery. Other Unciv AI motives such as exploration, special unit missions and wartime strategy may still embark units.
- Some embarked troops cannot disembark if the shore is occupied, inaccessible or unreachable; they fall back to ordinary AI.
- Static Python parser checks and patch replay/branch safety tests passed; **full Android build and on-device runtime were not performed**. Do not commit if the local build fails.
- The script checks exact anchors and writes only after all anchors are found. Re-running after a successful apply is a no-op.
