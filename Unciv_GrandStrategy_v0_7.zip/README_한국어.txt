v0.7 UI: 좌우 독립 스크롤, 컴팩트 계층 목록, 유니코드 연결선.
이 패치는 v0.6 grand-strategy-formations 브랜치 전용입니다.
Codespaces 터미널: git pull --ff-only origin grand-strategy-formations && unzip -o Unciv_GrandStrategy_v0_7.zip && bash apply_v0_7.sh
주의: 그래픽 선/자유 배치 거미줄은 미구현. 실제 APK 컴파일은 GitHub Actions에서 확인.
