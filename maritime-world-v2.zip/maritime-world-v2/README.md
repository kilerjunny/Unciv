# Grand Strategy — Maritime World v2 (Small Continents 기반)

**대상:** `kilerjunny/Unciv`, 브랜치 `mobile-dev`, Maritime World v1 적용 완료 상태.

## 변경

- `Maritime Continents`에서 한쪽 대륙 편향을 만드는 `Continent and Islands` 지형 높이 계산 제거
- Unciv `Small Continents`와 동일한 능선형 지형 필드를 사용하여 중소형 대륙을 지도 전역에 분산
- 맵 생성 시 **후보 시드 2~3개**를 생성하고 육지 연결 성분을 분석해 초대형 대륙 편중을 줄이는 후보 선택
- **해양 비율 목표 65%** (기본 수위 0일 때, 지형 생성 초기 단계); 기존 수위 슬라이더 및 4타일 섬사슬·해협 보정 유지
- 기존 **해안 시작 목표 85%** 보정 유지
- 맵 선택 화면의 이름은 `Maritime Continents` 그대로 유지; 새 지도에서만 새 알고리즘 적용
- 기존 `Small Continents`, `Archipelago` 등 다른 지도 유형 및 기존 저장게임에는 영향 없음

**참고:** 모든 시드에서 특정 대륙 개수나 정확한 해양 비율, 정확한 해안 시작률을 보장하지 않음. 기존 섬/해협 후처리가 육지/바다 타일 수를 바꿀 수 있고, 실제 문명 시작 위치는 유효한 시작 후보 조건을 따른다.

## 적용 (Codespaces)

1. ZIP을 `mobile-dev` Codespaces 프로젝트 루트에 업로드
2. 아래 명령어 실행

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o maritime-world-v2.zip -d /tmp
python3 /tmp/maritime-world-v2/apply_maritime_world_v2.py --check
python3 /tmp/maritime-world-v2/apply_maritime_world_v2.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

빌드 성공 후:

```bash
git add core/src/com/unciv/logic/map/mapgenerator/MapLandmassGenerator.kt
git rm --ignore-unmatch maritime-world-v2.zip
git diff --cached --check
git commit -m "Use Small Continents terrain for Maritime World v2"
git push origin mobile-dev
```

이후 GitHub Actions에서 **최신 `mobile-dev` 커밋의 debug APK** 생성 및 설치.

## 테스트 권장

1. 새로운 게임 → `Maritime Continents` → **반경 60** 설정 후 미리보기 확인. 소대륙과 유사하게 육지가 여러 영역으로 분리되는지 관찰
2. 동일 시드/설정에서 같은 해안선 생성되는지 확인
3. 40개 도시국가와 선택한 주요 문명 수로 시작 위치 생성 성공하는지 확인
4. `Small Continents` 타입은 이전과 동일한 방식으로 생성되는지 확인
5. 실제 해양 비율과 해협 유효성은 지도 데이터를 통해 별도 검증 필요

## 검증 상태

패치 스크립트 기반 테스트 및 분리 Kotlin 모의 컴파일 가능. 전체 Unciv 프로젝트 Android 빌드와 시드별 지도 품질은 **Codespaces에서 확인 필요**.
