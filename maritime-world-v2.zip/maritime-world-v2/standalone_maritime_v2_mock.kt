import kotlin.random.Random
import kotlin.math.abs
import kotlin.math.sin

class MapShape {
    companion object { const val hexagonal="Hexagonal"; const val flatEarth="Flat Earth Hexagonal"; const val rectangular="Rectangular" }
}
data class MapSize(val width:Int, val height:Int)
data class MapParameters(val shape:String, val mapSize:MapSize, val waterThreshold:Float=0f)
class Tile(val x:Int,val y:Int) {
    var zeroBasedIndex:Int = -1
    var baseTerrain=""
    val neighbors = mutableListOf<Tile>()
    fun aerialDistanceTo(other:Tile):Int=abs(x-other.x)+abs(y-other.y)
    fun getTilesInDistance(radius:Int):Sequence<Tile> = sequence {
        val visited=mutableSetOf(this@Tile); val q=ArrayDeque<Pair<Tile,Int>>();q.add(this@Tile to 0)
        while(q.isNotEmpty()) {val (t,d)=q.removeFirst();yield(t);if(d<radius)for(n in t.neighbors)if(visited.add(n))q.add(n to d+1)}
    }
}
class TileMap(val values: List<Tile>, val mapParameters: MapParameters)
class Randomness(val RNG:Random) {
    fun getPerlinNoise(tile:Tile,seed:Double):Double =
        sin((tile.x*0.1+seed*0.00001))+sin((tile.y*0.08-seed*0.00001))
}
class MaritimeLand(private val tileMap:TileMap,private val randomness:Randomness) {
    private val landTerrainName="Land";private val waterTerrainName="Ocean"
    private fun getRidgedPerlinNoise(tile:Tile,seed:Double,nOctaves:Int=10,scale:Double=10.0):Double=
        sin(tile.x/scale+tile.y/scale+seed*0.00001)
    private fun getContinentAndIslandsTransform(tile:Tile, isNorth:Boolean, isLatitude:Boolean):Double {
        val part = if (isLatitude) tile.y else tile.x
        return sin(part/25.0) + randomness.RNG.nextDouble()*0.05
    }
    private fun getOceanEdgesTransform(tile:Tile):Double= 0.0
    /**
     * GS_MARITIME_WORLD_V2_SMALL_CONTINENTS
     * Draw geography from the same ridged Perlin landmass field as the stock
     * Small Continents map, NOT the one-sided Continent and Islands transform.
     * Try a bounded number of seeds and favor a spread of medium continents.
     * This only runs at map generation, never during turns.
     *
     * Keep the v1 water-level behavior (65% target at default settings) and
     * the same bounded islands/straits and 85%-target coast-start selection.
     */
    private fun createMaritimeContinents() {
        val tiles = tileMap.values.toList()
        if (tiles.isEmpty()) return
        val waterRatio = (0.65 + tileMap.mapParameters.waterThreshold.toDouble()).coerceIn(0.55, 0.75)
        val targetWater = (tiles.size * waterRatio).toInt().coerceIn(0, tiles.size)

        // Use one seed per candidate, so the selected layout is deterministic
        // for the map seed and the map's shape/size parameters.
        val samples = if (tiles.size >= 18000) 2 else 3
        var bestMask: BooleanArray? = null
        var bestScore = Int.MAX_VALUE
        repeat(samples) {
            val elevationSeed = randomness.RNG.nextInt().toDouble()
            val byElevation = tiles.map { tile ->
                // Exactly the stock Small Continents terrain field. Rank it
                // instead of using the default lowering-water-level retry:
                // this preserves a consistent, predictable 65% sea share.
                val elevation = getRidgedPerlinNoise(tile, elevationSeed, scale = 22.0) +
                    getOceanEdgesTransform(tile)
                tile.zeroBasedIndex to elevation
            }.sortedWith(compareBy<Pair<Int, Double>> { it.second }.thenBy { it.first })

            val land = BooleanArray(tiles.size)
            for (index in targetWater until byElevation.size)
                land[byElevation[index].first] = true

            val score = maritimeLandmassScore(tiles, land)
            if (score < bestScore) {
                bestScore = score
                bestMask = land
            }
        }

        val land = bestMask ?: return
        for (tile in tiles)
            tile.baseTerrain = if (land[tile.zeroBasedIndex]) landTerrainName else waterTerrainName

        // Keep the proven v1 bounded edits, including protection for new
        // island chains. These never rerun during turns or on loaded saves.
        val newIslands = addMaritimeIslandChains()
        carveMaritimeStraits(newIslands)
    }

    /**
     * Score connected landmasses without setting map transients. A single
     * enormous continent and a map made only of tiny isolated specks are both
     * less desirable than several viable medium-sized continents.
     * Bounded O(tiles + edges) flood-fill, run only on the seed candidates.
     */
    private fun maritimeLandmassScore(tiles: List<Tile>, land: BooleanArray): Int {
        val visited = BooleanArray(land.size)
        val componentSizes = ArrayList<Int>()
        val queue = ArrayDeque<Tile>()
        for (tile in tiles) {
            val index = tile.zeroBasedIndex
            if (!land[index] || visited[index]) continue
            visited[index] = true
            queue.add(tile)
            var size = 0
            while (queue.isNotEmpty()) {
                val current = queue.removeFirst()
                size++
                for (neighbor in current.neighbors) {
                    val neighborIndex = neighbor.zeroBasedIndex
                    if (!land[neighborIndex] || visited[neighborIndex]) continue
                    visited[neighborIndex] = true
                    queue.add(neighbor)
                }
            }
            componentSizes.add(size)
        }
        val totalLand = land.count { it }.coerceAtLeast(1)
        val largestPercent = ((componentSizes.maxOrNull() ?: 0) * 100) / totalLand
        val mediumThreshold = (totalLand / 70).coerceAtLeast(8)
        val mediumCount = componentSizes.count { it >= mediumThreshold }

        val giantPenalty = (largestPercent - 28).coerceAtLeast(0) * 12
        val tooFewPenalty = (4 - mediumCount).coerceAtLeast(0) * 35
        val tooManyPenalty = (mediumCount - 18).coerceAtLeast(0) * 12
        return giantPenalty + tooFewPenalty + tooManyPenalty + kotlin.math.abs(largestPercent - 19)
    }

    /** Bounded 4-tile island groups, generally within five tiles of existing land. */
    private fun addMaritimeIslandChains(): Set<Tile> {
        val createdIslands = HashSet<Tile>()
        val budget = (tileMap.values.size / 320).coerceAtMost(160)
        if (budget < 4) return createdIslands

        val candidates = tileMap.values.filter { it.baseTerrain == waterTerrainName }
            .shuffled(randomness.RNG)
        for (center in candidates) {
            if (createdIslands.size + 4 > budget) break
            if (center.baseTerrain != waterTerrainName) continue
            val neighbors = center.neighbors.toList()
            if (neighbors.size != 6 || neighbors.any { it.baseTerrain != waterTerrainName }) continue
            if (center.getTilesInDistance(5).none { it.baseTerrain == landTerrainName }) continue

            // Compact groups give a better settlement opportunity than isolated
            // single-tile islands, without blocking a full ocean corridor.
            val group = listOf(center) + neighbors.shuffled(randomness.RNG).take(3)
            for (tile in group) {
                tile.baseTerrain = landTerrainName
                createdIslands.add(tile)
            }
        }
        return createdIslands
    }

    /** Open a few one-tile land bridges into potential straits or inlets. */
    private fun carveMaritimeStraits(protectedIslands: Set<Tile>) {
        val maxCuts = (tileMap.values.size / 500).coerceAtMost(90)
        if (maxCuts <= 0) return
        val cuts = HashSet<Tile>()
        val candidates = tileMap.values.filter { it.baseTerrain == landTerrainName && it !in protectedIslands }
            .shuffled(randomness.RNG)
        for (tile in candidates) {
            if (cuts.size >= maxCuts) break
            if (tile.neighbors.count() != 6 || tile.neighbors.any { it in cuts }) continue
            val waterSides = tile.neighbors.filter { it.baseTerrain == waterTerrainName }.toList()
            if (waterSides.size !in 2..4) continue
            // Water on two non-adjacent sides makes this a narrow neck, rather
            // than converting long segments of ordinary coastline into water.
            val spansNeck = waterSides.any { first ->
                waterSides.any { second -> first != second && first.aerialDistanceTo(second) >= 2 }
            }
            if (!spansNeck) continue
            tile.baseTerrain = waterTerrainName
            cuts.add(tile)
        }
    }

    fun run():Double {createMaritimeContinents();return tileMap.values.count {it.baseTerrain=="Ocean"}.toDouble()/tileMap.values.size}
}
fun main() {
    val w=120;val h=100
    val tiles = (0 until h).flatMap { y -> (0 until w).map { x -> Tile(x,y) } }
    tiles.forEachIndexed { idx, tile -> tile.zeroBasedIndex = idx }
    for(t in tiles) for(dx in -1..1) for(dy in -1..1) {
        if (kotlin.math.abs(dx)+kotlin.math.abs(dy)!=1) continue
        val nx=t.x+dx; val ny=t.y+dy
        if (nx in 0 until w && ny in 0 until h) t.neighbors.add(tiles[ny*w+nx])
    }
    val fraction = MaritimeLand(TileMap(tiles,MapParameters(MapShape.rectangular,MapSize(w,h))), Randomness(Random(12345))).run()
    println("waterFraction="+fraction)
    fun seeded():List<String> {
        val ts = (0 until h).flatMap { y -> (0 until w).map { x -> Tile(x,y) } }
        ts.forEachIndexed { idx,t -> t.zeroBasedIndex=idx }
        for (t in ts) for (dx in -1..1) for (dy in -1..1) {
            if (kotlin.math.abs(dx)+kotlin.math.abs(dy)!=1) continue
            val nx=t.x+dx; val ny=t.y+dy
            if (nx in 0 until w && ny in 0 until h) t.neighbors.add(ts[ny*w+nx])
        }
        MaritimeLand(TileMap(ts,MapParameters(MapShape.rectangular,MapSize(w,h))), Randomness(Random(12345))).run()
        return ts.map { it.baseTerrain }
    }
    check(seeded() == seeded()) { "non-deterministic landmass" }
    check(fraction in 0.62..0.68) {"water fraction exceeds target"}
}
