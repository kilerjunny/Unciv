#!/usr/bin/env python3
"""Standalone patch safety tests (no Unciv checkout required)."""
from pathlib import Path
import importlib.util
import subprocess
import sys
import tempfile

script = Path(__file__).with_name('apply_maritime_world_v2.py')
spec = importlib.util.spec_from_file_location('maritime_v2', script)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

old = '''package com.unciv.logic.map.mapgenerator
class MapLandmassGenerator {
            MapType.maritimeContinents -> createMaritimeContinents()
    /**
     * GS_MARITIME_WORLD_V1
     */
    private fun createMaritimeContinents() {
        val broad = getContinentAndIslandsTransform(tile, true, true)
        val newIslands = addMaritimeIslandChains()
        carveMaritimeStraits(newIslands)
    }

    /** Bounded 4-tile island groups, generally within five tiles of existing land. */
    private fun addMaritimeIslandChains() = emptySet<Tile>()
    private fun carveMaritimeStraits(islands: Set<Tile>) {}
}
'''
new, changed = module.transform(old)
assert changed
assert module.VERSION in new
assert 'getContinentAndIslandsTransform' not in new
assert new.count('private fun createMaritimeContinents()') == 1
assert new.count('private fun addMaritimeIslandChains()') == 1
assert new.count('private fun carveMaritimeStraits(') == 1
assert module.transform(new) == (new, False)

try:
    module.transform(old.replace('getContinentAndIslandsTransform','not_original'))
except RuntimeError:
    pass
else:
    raise AssertionError('modified v1 accepted')

with tempfile.TemporaryDirectory() as temp:
    repo = Path(temp)
    dest = repo / module.FILE
    dest.parent.mkdir(parents=True)
    dest.write_text(old)
    subprocess.run(['git','init','-q'],cwd=repo,check=True)
    subprocess.run(['git','switch','-c','mobile-dev'],cwd=repo,check=True,capture_output=True)
    subprocess.run(['git','add','.'],cwd=repo,check=True)
    subprocess.run(['git','-c','user.email=test@example.com','-c','user.name=Test','commit','-qm','before'],cwd=repo,check=True)
    for args in [['--check'], []]:
        result = subprocess.run([sys.executable, str(script), *args],cwd=repo,capture_output=True,text=True)
        assert result.returncode == 0, result.stderr
    assert dest.read_text() == new
    result = subprocess.run([sys.executable, str(script)],cwd=repo,capture_output=True,text=True)
    assert result.returncode == 1 and 'Uncommitted changes' in result.stderr
    subprocess.run(['git','add','.'],cwd=repo,check=True)
    subprocess.run(['git','-c','user.email=test@example.com','-c','user.name=Test','commit','-qm','after'],cwd=repo,check=True)
    result = subprocess.run([sys.executable,str(script)],cwd=repo,capture_output=True,text=True)
    assert result.returncode == 0 and 'Already upgraded' in result.stdout
    subprocess.run(['git','switch','-c','unrelated'],cwd=repo,check=True,capture_output=True)
    result = subprocess.run([sys.executable,str(script)],cwd=repo,capture_output=True,text=True)
    assert result.returncode == 1 and 'Required branch' in result.stderr
print('PASS: v1-only upgrade, helpers preserved, no overwrite, branch guard, repeat-safe')
