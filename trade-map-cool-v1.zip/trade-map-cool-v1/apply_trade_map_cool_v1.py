#!/usr/bin/env python3
"""Low-overhead rendering for Unciv world trade map v1.

Apply on feature/world-trade-map-speed-v1 or a descendant.
The change is visual-only; no route finding, save model or trading changed.
"""
from pathlib import Path

ROOT = Path.cwd()
ACTOR = ROOT / 'core/src/com/unciv/ui/screens/overviewscreen/WorldMarketRouteMapActor.kt'
SECTION = ROOT / 'core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt'
MARKER = 'GS_TRADE_MAP_COOL_V1'


def replace_one(content, old, new, filename):
    occurrences = content.count(old)
    if occurrences != 1:
        raise SystemExit(f'{filename}: expected one anchor, got {occurrences}: {old[:120]!r}')
    return content.replace(old, new, 1)


def apply_actor(content):
    file = ACTOR.name
    content = replace_one(content,
        '    spectator: Boolean,\n    routes: List<MarketRouteStat>\n',
        '    spectator: Boolean,\n    routes: List<MarketRouteStat>,\n    private val lowPower: Boolean = true\n', file)
    content = replace_one(content,
        '    private data class PaintedRoute(val type: String, val count: Int, val segments: List<Segment>)\n',
        '    private data class PaintedRoute(val type: String, var count: Int, val segments: List<Segment>)\n'
        '    private data class EdgeKey(val mode: String, val a: HexCoord, val b: HexCoord)\n', file)
    content = replace_one(content,
        '''        // Derive fixed geographic bounds from the full map, without revealing unexplored land.
        for (tile in world.tileList) {
            val point = HexMath.hex2WorldCoords(tile.position)
            minX = min(minX, point.x)
            maxX = max(maxX, point.x)
            minY = min(minY, point.y)
            maxY = max(maxY, point.y)
            if (spectator || tile.isExplored(viewer))
                dots.add(Dot(point.x, point.y, tile.isWater))
        }
''',
        '''        // GS_TRADE_MAP_COOL_V1: Bound per-frame draw work on Android.
        // Counts are computed on map opening, never inside draw().
        val exploredCount = if (lowPower)
            world.tileList.count { spectator || it.isExplored(viewer) }
        else 0
        val sampleEvery = if (lowPower) ((exploredCount + 1599) / 1600).coerceAtLeast(1) else 1
        var exploredIndex = 0
        // Bounds are still calculated over the entire world, preserving map geometry.
        for (tile in world.tileList) {
            val point = HexMath.hex2WorldCoords(tile.position)
            minX = min(minX, point.x)
            maxX = max(maxX, point.x)
            minY = min(minY, point.y)
            maxY = max(maxY, point.y)
            if (spectator || tile.isExplored(viewer)) {
                if (exploredIndex % sampleEvery == 0)
                    dots.add(Dot(point.x, point.y, tile.isWater))
                exploredIndex++
            }
        }
''', file)
    content = replace_one(content,
        '''        for (route in routes) {
            val segments = ArrayList<Segment>()
            val points: List<HexCoord> = route.routeTiles
            for (i in 0 until points.size - 1) {
                val a = points[i]
                val b = points[i + 1]
                val tileA = world.getOrNull(a.x, a.y)
                val tileB = world.getOrNull(b.x, b.y)
                if (tileA == null || tileB == null) continue
                if (!spectator && (!tileA.isExplored(viewer) || !tileB.isExplored(viewer))) continue
                val p = HexMath.hex2WorldCoords(a)
                val q = HexMath.hex2WorldCoords(b)
                // Don't draw an erroneous line across the world-wrap seam.
                if (hypot((p.x - q.x).toDouble(), (p.y - q.y).toDouble()) > 3.0) continue
                segments.add(Segment(p.x, p.y, q.x, q.y))
            }
            if (segments.isNotEmpty()) lines.add(PaintedRoute(route.routeMode, route.tradeCount, segments))
        }
''',
        '''        // Multiple trade routes often share the same road/sea hex edge.
        // Draw each edge once, with a thicker stroke for accumulated traffic.
        // The key is directionless, so A→B and B→A overlap instead of stacking.
        val edges = LinkedHashMap<EdgeKey, PaintedRoute>()
        for (route in routes) {
            val points: List<HexCoord> = route.routeTiles
            for (i in 0 until points.size - 1) {
                val a = points[i]
                val b = points[i + 1]
                val tileA = world.getOrNull(a.x, a.y)
                val tileB = world.getOrNull(b.x, b.y)
                if (tileA == null || tileB == null) continue
                if (!spectator && (!tileA.isExplored(viewer) || !tileB.isExplored(viewer))) continue
                val p = HexMath.hex2WorldCoords(a)
                val q = HexMath.hex2WorldCoords(b)
                // Avoid fake lines across the horizontal world wrap.
                if (hypot((p.x - q.x).toDouble(), (p.y - q.y).toDouble()) > 3.0) continue
                val ordered = a.x < b.x || (a.x == b.x && a.y <= b.y)
                val key = if (ordered) EdgeKey(route.routeMode, a, b)
                    else EdgeKey(route.routeMode, b, a)
                val existing = edges[key]
                if (existing == null) {
                    edges[key] = PaintedRoute(
                        route.routeMode, route.tradeCount.coerceAtLeast(1),
                        listOf(Segment(p.x, p.y, q.x, q.y))
                    )
                } else {
                    existing.count += route.tradeCount.coerceAtLeast(1)
                }
            }
        }
        lines.addAll(edges.values)
''', file)
    return content


def apply_section(content):
    file = SECTION.name
    content = replace_one(content,
        '    private var tradeMapMode = "ALL"\n',
        '    private var tradeMapMode = "ALL"\n    private var tradeMapLowPower = true // GS_TRADE_MAP_COOL_V1: default low heat on mobile\n', file)
    content = replace_one(content,
        '''            switches.add(modeButton)
            add(switches).left().row()
''',
        '''            switches.add(modeButton)
            add(switches).left().row()
            // A separate row avoids overflowing narrow Android landscape layouts.
            val powerButton = TextButton(if (tradeMapLowPower) "절전 모드 ✓" else "절전 모드 OFF", BaseScreen.skin)
            powerButton.onClick {
                tradeMapLowPower = !tradeMapLowPower
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            add(powerButton).left().row()
''', file)
    content = replace_one(content,
        '''            val visible = entries.take(60)
            val summary = "거래 ${entries.sumOf { it.tradeCount }}건 · 물동량 ${entries.sumOf { it.quantity }}개 · " +
                "교역로 ${entries.size}개 집계 항목 (최대 60개 경로 표시)"
''',
        '''            val displayLimit = if (tradeMapLowPower) 24 else 60
            val visible = entries.take(displayLimit)
            val summary = "거래 ${entries.sumOf { it.tradeCount }}건 · 물동량 ${entries.sumOf { it.quantity }}개 · " +
                "교역로 ${entries.size}개 집계 항목 (최대 ${displayLimit}개 경로 표시)"
''', file)
    content = replace_one(content,
        '            add(WorldMarketRouteMapActor(game, viewer, spectator, visible))\n',
        '            add(WorldMarketRouteMapActor(game, viewer, spectator, visible, tradeMapLowPower))\n', file)
    return content


def main():
    if not ACTOR.is_file() or not SECTION.is_file():
        raise SystemExit('Missing trade-map v1 sources. Select feature/world-trade-map-speed-v1 first.')
    original_a = ACTOR.read_text(encoding='utf-8-sig')
    original_s = SECTION.read_text(encoding='utf-8-sig')
    if MARKER in original_a and MARKER in original_s:
        print('Already patched; nothing to do.')
        return
    if MARKER in original_a or MARKER in original_s:
        raise SystemExit('Partial patch detected; please inspect your working tree.')
    if 'GS_TRADE_MAP_SPEED_V1' not in original_s:
        raise SystemExit('Base trade map patch missing; expected feature/world-trade-map-speed-v1.')
    # Preflight BOTH files before writing to disk.
    updated_a = apply_actor(original_a)
    updated_s = apply_section(original_s)
    ACTOR.write_text(updated_a, encoding='utf-8')
    SECTION.write_text(updated_s, encoding='utf-8')
    print('Patched:', ACTOR.relative_to(ROOT))
    print('Patched:', SECTION.relative_to(ROOT))
    print('Low-power trade map enabled by default. Build, install and compare heat in-game.')

if __name__ == '__main__':
    main()
