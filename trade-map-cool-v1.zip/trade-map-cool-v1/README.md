# Unciv trade-map heat reduction v1

Applies on **feature/world-trade-map-speed-v1** or a clean descendant branch.

## What changes
- `절전 모드 ✓` switch is ON by default in `개요 > 거래 > 세계 시장 > 무역 지도`.
- Low power mode displays **up to 24** top-ranked route records (60 in detailed mode).
- Low power mode samples background explored tiles to **at most ~1,600** map dots (detailed mode uses full resolution).
- Repeated route edges are merged into a single drawn line, with thickness based on combined trade counts.
- World-market orders, gold, resources, pathfinding, game saves and route statistics are not modified.
- This reduces *render workload* while the map is open. Thermal gains are device-dependent; CPU/GPU overheating is not proven to be caused solely by the map.

## Apply via GitHub Add file
1. Upload this ZIP to `feature/world-trade-map-speed-v1` using GitHub **Add file -> Upload files**; commit.
2. In Codespaces:

```bash
git switch feature/world-trade-map-speed-v1
git pull --ff-only origin feature/world-trade-map-speed-v1
git switch -c feature/trade-map-cool-v1
unzip -o trade-map-cool-v1.zip -d /tmp
python3 /tmp/trade-map-cool-v1/apply_trade_map_cool_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

3. After a successful build:

```bash
git add core/src/com/unciv/ui/screens/overviewscreen/WorldMarketRouteMapActor.kt core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git commit -m "Reduce world trade map rendering overhead"
git push -u origin feature/trade-map-cool-v1
```

4. Use **Actions > Android build > Run workflow** and select `feature/trade-map-cool-v1`, download the APK and install it.
5. Test map open vs closed and `절전 모드 ✓` vs OFF under similar device and charging conditions.

**Caveats:** This is a best-effort rendering optimization. It does not reduce AI pathfinding workload during turn processing and does not change phone thermal limits. Build/runtime compatibility needs checking in your fork.
