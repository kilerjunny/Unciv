#!/usr/bin/env python3
"""Safely install the observational mixed land/sea trade-route planner."""
from pathlib import Path
import argparse
import sys

PLANNER = Path("core/src/com/unciv/logic/market/WorldMarketRoutePlanner.kt")
UI = Path("core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt")
MARKER = "GS_TRADE_ROUTE_MULTIMODAL_V2"
ORIGINAL_LABEL = '"SEA" -> "항로"\n                        else -> "경로 미확인"'
NEW_LABEL = '"SEA" -> "항로"\n                        "MIXED" -> "복합(육해상)"\n                        else -> "경로 미확인"'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, default=Path.cwd(), help="Path to Unciv source root")
    args = parser.parse_args()
    root = args.repo.resolve()
    planner, ui = root / PLANNER, root / UI
    payload = Path(__file__).resolve().parent / "payload" / "WorldMarketRoutePlanner.kt"
    for file in (planner, ui, payload):
        if not file.is_file():
            sys.exit(f"ERROR: Missing {file}")
    previous = planner.read_text(encoding="utf-8")
    old_ui = ui.read_text(encoding="utf-8")
    new_planner = payload.read_text(encoding="utf-8")
    if MARKER in previous and NEW_LABEL in old_ui:
        print("Already applied; nothing to change.")
        return
    if MARKER not in previous and "private fun closestPair(" not in previous:
        sys.exit("ERROR: Unexpected route planner version; refusing to overwrite.")
    if NEW_LABEL not in old_ui and old_ui.count(ORIGINAL_LABEL) != 1:
        sys.exit("ERROR: Cannot locate the expected route history UI label.")
    # Validate both targets before writing either one.
    next_ui = old_ui if NEW_LABEL in old_ui else old_ui.replace(ORIGINAL_LABEL, NEW_LABEL, 1)
    planner.write_text(new_planner, encoding="utf-8")
    ui.write_text(next_ui, encoding="utf-8")
    print("Applied: observational multimodal route planner + MIXED label")
    print("Changed: WorldMarketRoutePlanner.kt; WorldMarketTradeSection.kt")
    print("World-market prices, inventories and purchase logic are untouched.")


if __name__ == "__main__":
    main()
