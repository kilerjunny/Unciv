# Unciv Grand Strategy — 무역로 개선 1차 (v2)

대상 브랜치: `feature/citystate-market-v1` (도시국가 세계시장 수정까지 적용된 소스)

## 기능
- 현재: 기존 기록은 거래 발생 시 육로 또는 항로로만 분류. 가장 가까운 도시 쌍 하나만 조사.
- 변경: 모든 양국 도시를 시작점/종료점으로 평가하는 단일 BFS 경로 탐색.
- 항만(연안 도시 중심 타일)에서 육지↔물 이동 허용. `LAND`, `SEA`, `MIXED`, `UNRESOLVED` 판정.
- 거래 내역 화면에 `복합(육해상)` 표시.
- 동일 턴/동일 판매국-구매국은 경로 캐시를 재사용. 다른 턴은 갱신, 탐색 10,000칸 제한 및 캐시 128건 제한.
- 세계 시장의 자원/금/거래 내역/도시국가 자동 판매 처리에는 영향 없음.

**제한:** 자원의 실제 산지 도시와의 연계, 통행 허가, 운송비, 해상 봉쇄, 환적비, 배송 지연, 일반 상인 AI, 무역로 지도 탭은 미구현. 현재는 물리적 연결만 계산. 경로는 최소 `칸 수` 우선이므로 경제적 최적 경로와 다를 수 있음. 호수 수역도 수상 경로로 간주할 수 있음.

## 설치 (Codespaces)
ZIP을 프로젝트 최상위(`/workspaces/Unciv/`)에 업로드하거나 GitHub Add file 업로드 후 Codespaces에서 `git pull`로 받아온 뒤:

```sh
cd /workspaces/Unciv
git status --short
git switch -c feature/trade-route-multimodal-v2
unzip -o trade-route-v2.zip -d /tmp
python3 /tmp/trade-route-v2/apply_trade_route_v2.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

`git switch -c`에서 브랜치가 이미 있다면 그 명령은 생략하고 올바른 브랜치인지 확인하세요.

빌드 성공 시:
```sh
git add core/src/com/unciv/logic/market/WorldMarketRoutePlanner.kt core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git commit -m "Improve multimodal world-market route recognition"
git push -u origin feature/trade-route-multimodal-v2
```

GitHub Actions → Android build → Run workflow → `feature/trade-route-multimodal-v2` 선택.

## 게임 검사
1. 가까운 육지 도시 양국 거래 → `육로` 기록.
2. 연안 도시 두 국가간 해상 거래 → `항로` 기록.
3. 내륙 도시→연안 도시→바다→연안 도시→내륙 도시 연결인 경우 → `복합(육해상)` 기록.
4. 연결이 없다면 `경로 미확인`; 거래 자체는 정상 체결.
5. 기존 저장 게임, 도시국가 0종 목록, 도시국가 자원 구매, AI간 거래 유지.

주의: 둘 중 하나의 국가에 연안 도시가 없거나 외국 연안 도시를 경유할 수 없는 경우 `경로 미확인` 가능. 외교적 접근 권한은 현재 미반영.
