#!/usr/bin/env python3
"""GS_WORLD_MAIN_ROUTES_V1: observation-only world main-corridor preview.
Apply from repository root on feature/unit-ai-route-cache-v1.
"""
from pathlib import Path

ROOT = Path.cwd()
CORE = Path('core/src/com/unciv/logic/market/WorldMarketMainRoutes.kt')
ACTOR = Path('core/src/com/unciv/ui/screens/overviewscreen/WorldMarketRouteMapActor.kt')
UI = Path('core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt')
SOURCE = Path(__file__).parent / 'WorldMarketMainRoutes.kt'
MARK = 'GS_WORLD_MAIN_ROUTES_V1'


def once(text, old, new, name):
    occurrences = text.count(old)
    if occurrences != 1:
        raise SystemExit(f'{name}: expected exactly one anchor, found {occurrences}: {old[:100]!r}')
    return text.replace(old, new, 1)


def change_actor(s):
    p = str(ACTOR)
    s = once(s, 'import com.unciv.logic.market.MarketRouteStat\n',
        'import com.unciv.logic.market.MarketRouteStat\n'
        'import com.unciv.logic.market.WorldMarketMainRoutes.MainTradeCorridor\n', p)
    s = once(s,
        '    routes: List<MarketRouteStat>,\n    private val lowPower: Boolean = true\n',
        '    routes: List<MarketRouteStat>,\n    private val lowPower: Boolean = true,\n'
        '    mainRoutes: List<MainTradeCorridor> = emptyList(), // GS_WORLD_MAIN_ROUTES_V1\n', p)
    s = once(s,
        '    private val lines = ArrayList<PaintedRoute>()\n',
        '    private val lines = ArrayList<PaintedRoute>()\n'
        '    private val mainSegments = ArrayList<Segment>()\n', p)
    s = once(s,
        '    private val mixedPath = Color(0.98f, 0.51f, 0.82f, 1f)\n',
        '    private val mixedPath = Color(0.98f, 0.51f, 0.82f, 1f)\n'
        '    private val mainPath = Color(0.48f, 1f, 0.55f, 1f)\n', p)
    s = once(s,
        '        lines.addAll(edges.values)\n',
        '''        lines.addAll(edges.values)
        // GS_WORLD_MAIN_ROUTES_V1: build highlighted segments once, never in draw().
        // Fog-of-war and world-wrap protections are identical to ordinary routes.
        for (corridor in mainRoutes) {
            for (i in 0 until corridor.tiles.size - 1) {
                val a = corridor.tiles[i]
                val b = corridor.tiles[i + 1]
                val tileA = world.getOrNull(a.x, a.y)
                val tileB = world.getOrNull(b.x, b.y)
                if (tileA == null || tileB == null) continue
                if (!spectator && (!tileA.isExplored(viewer) || !tileB.isExplored(viewer))) continue
                val p = HexMath.hex2WorldCoords(a)
                val q = HexMath.hex2WorldCoords(b)
                if (hypot((p.x - q.x).toDouble(), (p.y - q.y).toDouble()) > 3.0) continue
                mainSegments.add(Segment(p.x, p.y, q.x, q.y))
            }
        }
''', p)
    s = once(s,
        '        batch.color = old\n',
        '''        // World main trade corridors are highlighted over the normal trade lanes.
        batch.color = mainPath
        val mainThickness = 5.2f
        for (segment in mainSegments) {
            val x1 = px(segment.fromX)
            val y1 = py(segment.fromY)
            val dx = px(segment.toX) - x1
            val dy = py(segment.toY) - y1
            val length = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (length <= 0.001f) continue
            val angle = atan2(dy, dx) * MathUtils.radiansToDegrees
            batch.draw(pixel, x1, y1 - mainThickness / 2f,
                0f, mainThickness / 2f, length, mainThickness, 1f, 1f, angle)
        }
        batch.color = old
''', p)
    return s


def change_ui(s):
    p = str(UI)
    s = once(s,
        'import com.unciv.logic.market.WorldMarketRouteStats\n',
        'import com.unciv.logic.market.WorldMarketRouteStats\n'
        'import com.unciv.logic.market.WorldMarketMainRoutes\n', p)
    s = once(s,
        '    private var tradeMapLowPower = true // GS_TRADE_MAP_COOL_V1: default low heat on mobile\n',
        '    private var tradeMapLowPower = true // GS_TRADE_MAP_COOL_V1: default low heat on mobile\n'
        '    private var tradeMapMainOnly = false // GS_WORLD_MAIN_ROUTES_V1\n', p)
    s = once(s,
        '''            add(powerButton).left().row()

            val knownIds''',
        '''            add(powerButton).left().row()
            // World routes share a global cap; player/country filters only affect
            // ordinary route rendering, not corridor discovery.
            val mainOnlyButton = TextButton(
                if (tradeMapMainOnly) "주무역로만 ✓" else "일반 경로 + 주무역로",
                BaseScreen.skin
            )
            mainOnlyButton.onClick {
                tradeMapMainOnly = !tradeMapMainOnly
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            add(mainOnlyButton).left().row()

            val knownIds''', p)
    s = once(s,
        '''            val displayLimit = if (tradeMapLowPower) 24 else 60
            val visible = entries.take(displayLimit)
''',
        '''            // GS_WORLD_MAIN_ROUTES_V1: global backbone from observed world traffic.
            // Compute only when opening/re-rendering the map, not during each turn or draw.
            val globalRows = WorldMarketRouteStats.windowRows(game)
            val maximumMain = WorldMarketMainRoutes.maximumCount(game)
            val mainRoutes = WorldMarketMainRoutes.select(game, globalRows)
            add("세계 주무역로 ${mainRoutes.size}/${maximumMain}개 · 최근 ${window}턴 전 세계 교역량 기준".toLabel(hideIcons = true))
                .left().growX().row()
            val displayLimit = if (tradeMapLowPower) 24 else 60
            val visible = if (tradeMapMainOnly) emptyList() else entries.take(displayLimit)
''', p)
    s = once(s,
        '''            add(WorldMarketRouteMapActor(game, viewer, spectator, visible, tradeMapLowPower))
''',
        '''            add(WorldMarketRouteMapActor(game, viewer, spectator, visible, tradeMapLowPower, mainRoutes))
''', p)
    s = once(s,
        '''            add("육로: 노랑 · 항로: 하늘색 · 복합: 분홍 · 선 굵기: 거래 횟수".toLabel(hideIcons = true))
''',
        '''            add("육로: 노랑 · 항로: 하늘색 · 복합: 분홍 · 세계 주무역로: 굵은 연두색".toLabel(hideIcons = true))
''', p)
    s = once(s,
        '''            add("탐험한 지도 칸만 표시하며, 과거 저장파일은 최근 거래 100건부터 복원됩니다.".toLabel(hideIcons = true))
''',
        '''            add("주무역로는 공유 구간의 임시 관측 결과이며, 상선 이동·금·자원에는 영향이 없습니다.".toLabel(hideIcons = true))
                .left().growX().row()
            add("탐험한 지도 칸만 표시하며, 과거 저장파일은 최근 거래 100건부터 복원됩니다.".toLabel(hideIcons = true))
''', p)
    return s


def main():
    for item in (ACTOR, UI):
        if not item.is_file():
            raise SystemExit(f'Run from Unciv repository root; missing {item}')
    before_a, before_ui = ACTOR.read_text(), UI.read_text()
    if MARK in before_a or MARK in before_ui or CORE.exists():
        raise SystemExit('Patch is already present or file conflicts: no changes made')
    # Validate both edited files before touching the working tree.
    after_a, after_ui = change_actor(before_a), change_ui(before_ui)
    CORE.parent.mkdir(parents=True, exist_ok=True)
    CORE.write_text(SOURCE.read_text())
    ACTOR.write_text(after_a)
    UI.write_text(after_ui)
    print('Applied world main routes v1 (3 Kotlin files, observation-only).')
    print('Next: git diff --check && ./gradlew :android:assembleDebug --no-daemon')


if __name__ == '__main__':
    main()
