# Unciv Grand Strategy — World Main Routes v1 (preview)

Base branch: `feature/unit-ai-route-cache-v1`.

## Features
- **Worldwide** shared main trade routes; not one quota per nation.
- Custom hex-map radius 40 = 8 main corridors max; 45 = 9; 50 = 10, using real map tiles and `round(8*sqrt(tiles/4681))` clamped 4...12.
- Aggregate already recorded trade-path edges **across all civilizations**, direction independently. To bound work on Android, analyze the 600 highest-traffic aggregate rows when the window is larger.
- Greedily chain the more-trafficked shared edges into a limited number of continuous trunk corridors. Short or isolated low-traffic segments remain ordinary branch routes.
- Trade Map: **일반 경로 + 주무역로** / **주무역로만 ✓**. Thick lime-green main routes over ordinary trade paths. Fog-of-war still applies.
- Observation only: no resources, gold, cargo ships, military, map pathfinding, market settlement, turn AI, or save-format changes.
- Nothing new runs per frame or every turn. Corridor ranking happens when the Trade Map renders.

## Important limitations
- V1 is a **transient visualization** of traffic from the most recent speed-scaled turn window. Main routes can fluctuate as the window advances; no persistent designation, customs, tolls or shipping yet.
- Routes require at least two traversals of a shared segment. Sparse early-game records may show `0/8` and that's intentional.
- Existing trade-path history is an observational approximation of shortest paths, not real ships. Main corridor output is a heuristic, **not yet** the full economic optimal-route model.
- A historical save may not have complete window statistics. Only explored map tiles appear to non-spectators. Selection considers all civilizations even if player's normal filters show only some routes.

## Installation — Codespaces repository root
1. On GitHub select `feature/unit-ai-route-cache-v1`, `Add file` -> `Upload files`, upload `world-main-routes-v1.zip` and commit.
2. In Codespaces terminal:

```sh
git switch feature/unit-ai-route-cache-v1
git pull --ff-only origin feature/unit-ai-route-cache-v1
git switch -c feature/world-main-routes-v1
unzip -o world-main-routes-v1.zip -d /tmp
python3 /tmp/world-main-routes-v1/apply_world_main_routes_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

3. After successful build:

```sh
git add core/src/com/unciv/logic/market/WorldMarketMainRoutes.kt core/src/com/unciv/ui/screens/overviewscreen/WorldMarketRouteMapActor.kt core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git commit -m "Add global shared main trade corridors preview"
git push -u origin feature/world-main-routes-v1
```

4. GitHub Actions -> `androidBuild.yml` -> Run workflow -> `feature/world-main-routes-v1` -> install debug APK.
5. In game: 개요 -> 거래 -> 세계 시장 -> 무역 지도 -> `일반 경로 + 주무역로` or `주무역로만`.

## Test points
- Correct global cap for custom radius (40=8, 45=9, 50=10).
- Observed major lanes highlighted lime-green while existing route colors remain.
- No hidden tiles shown to a non-spectator.
- Normal world market/turn progression/save unaffected.
- Compare Android rendering/performance to prior version.
