package com.unciv.logic.market

import kotlin.math.roundToInt
import kotlin.math.sqrt

data class HexCoord(val x: Int, val y: Int)
class TileMap(val tileList: List<Int>)
class GameInfo(val tileMap: TileMap)
class MarketRouteStat(
    val routeTiles: ArrayList<HexCoord>, val tradeCount: Int, val quantity: Int,
    val routeMode: String, val sellerCivId: String = "seller",
    val buyerCivId: String = "buyer", val routeHash: Int = routeTiles.hashCode()
)

object WorldMarketMainRoutes {
    data class MainTradeCorridor(val tiles: List<HexCoord>, val peakTrades: Int, val totalSegmentTrades: Int)
    private data class Edge(val a: HexCoord, val b: HexCoord)
    private class Traffic(var trades: Int = 0, var quantity: Int = 0)
    private const val MaxCorridorLength = 256
    private const val MinCorridorEdges = 8
    private const val MaxInputRows = 600
    fun maximumCount(game: GameInfo): Int {
        val tiles = game.tileMap.tileList.size.coerceAtLeast(1)
        return (8.0 * sqrt(tiles.toDouble() / 4681.0)).roundToInt().coerceIn(4, 12)
    }
    fun select(game: GameInfo, rows: List<MarketRouteStat>) = selectRows(rows, maximumCount(game))
    // GS_CONNECTED_TRADE_BACKBONE_V2
    // A main corridor follows a CONTINUOUS piece of an actual observed trade
    // route, including the lightly-used bridge between shared sections.
    // This avoids drawing small unrelated traffic fragments as main lines.
    internal fun selectRows(rows: List<MarketRouteStat>, maximum: Int): List<MainTradeCorridor> {
        if (maximum <= 0) return emptyList()
        // The input is deliberately capped. The only work done during turns is
        // on the first economic path request, which already caches the result.
        val inputs = rows.asSequence()
            .filter { it.tradeCount > 0 && it.routeTiles.size in (MinCorridorEdges + 1)..(MaxCorridorLength + 1) }
            .sortedWith(compareByDescending<MarketRouteStat> { it.tradeCount }
                .thenBy { it.sellerCivId }.thenBy { it.buyerCivId }
                .thenBy { it.routeHash })
            .take(MaxInputRows).toList()
        if (inputs.isEmpty()) return emptyList()

        val traffic = HashMap<Edge, Traffic>()
        for (row in inputs) for (i in 0 until row.routeTiles.size - 1) {
            val a = row.routeTiles[i]
            val b = row.routeTiles[i + 1]
            if (a == b) continue
            val flow = traffic.getOrPut(edge(a, b)) { Traffic() }
            flow.trades += row.tradeCount
            flow.quantity += row.quantity.coerceAtLeast(0)
        }
        if (traffic.isEmpty()) return emptyList()
        val peak = traffic.values.maxOf { it.trades }
        val threshold = maxOf(2, (peak * 0.35).roundToInt())

        data class Candidate(val tiles: List<HexCoord>, val edges: List<Edge>, val mode: String)
        val candidates = ArrayList<Candidate>()
        for (row in inputs) {
            val edges = (0 until row.routeTiles.size - 1).map { i ->
                edge(row.routeTiles[i], row.routeTiles[i + 1])
            }
            // Find repeat-used parts of this authentic route; include the
            // connecting lower-traffic segments so the resulting trunk is whole.
            val strong = edges.indices.filter { (traffic[edges[it]]?.trades ?: 0) >= threshold }
            if (strong.size < 4) continue
            val first = strong.first()
            val last = strong.last()
            if (last - first + 1 < MinCorridorEdges) continue
            val path = row.routeTiles.subList(first, last + 2).toList()
            val pathEdges = edges.subList(first, last + 1).toList()
            candidates.add(Candidate(path, pathEdges, row.routeMode))
        }
        if (candidates.isEmpty()) return emptyList()

        val occupied = HashSet<Edge>()
        val output = ArrayList<MainTradeCorridor>()
        val used = BooleanArray(candidates.size)
        while (output.size < maximum) {
            var selected = -1
            var highestScore = 0L
            for (i in candidates.indices) {
                if (used[i]) continue
                val candidate = candidates[i]
                var fresh = 0
                var score = 0L
                for (segment in candidate.edges) if (segment !in occupied) {
                    fresh++
                    val weight = traffic.getValue(segment)
                    score += weight.trades * 5L + weight.quantity.coerceAtMost(10)
                }
                // A second trunk must be substantially independent; otherwise
                // several overlapping versions of one international route use
                // up all world slots.
                if (fresh < MinCorridorEdges || fresh * 4 < candidate.edges.size) continue
                // When actual traffic is comparable, favour sea-capable routes.
                if (candidate.mode == "SEA" || candidate.mode == "MIXED")
                    score = score * 11 / 10
                if (score > highestScore) {
                    highestScore = score
                    selected = i
                }
            }
            if (selected < 0) break
            used[selected] = true
            val chosen = candidates[selected]
            occupied.addAll(chosen.edges)
            output.add(MainTradeCorridor(
                chosen.tiles,
                chosen.edges.maxOf { traffic.getValue(it).trades },
                chosen.edges.sumOf { traffic.getValue(it).trades }
            ))
        }
        return output
    }

    private fun other(edge: Edge, one: HexCoord): HexCoord = if (edge.a == one) edge.b else edge.a
    private fun edge(a: HexCoord, b: HexCoord): Edge =
        if (a.x < b.x || (a.x == b.x && a.y <= b.y)) Edge(a, b) else Edge(b, a)
}

fun main() {
    val common = (0..23).map { HexCoord(it, 0) }
    val second = (0..24).map { HexCoord(it, 3) }
    val a = MarketRouteStat(ArrayList(common), 4, 4, "SEA", routeHash=1)
    val b = MarketRouteStat(ArrayList(common), 1, 1, "SEA", routeHash=2)
    val c = MarketRouteStat(ArrayList(second), 3, 3, "MIXED", routeHash=3)
    val main = WorldMarketMainRoutes.selectRows(listOf(a,b,c), 2)
    require(main.size==2) {"Expected 2 corridors, got $main"}
    require(main.all { it.tiles.size >= 9 })
    require(main.any { it.tiles == common } && main.any { it.tiles == second })
    val noDemand = WorldMarketMainRoutes.selectRows(listOf(MarketRouteStat(ArrayList(common),1,1,"SEA")), 2)
    require(noDemand.isEmpty()) { "Single trade cannot form trunk" }
    require(WorldMarketMainRoutes.selectRows(listOf(a,b,c), 1).size==1)
    val duplicates = WorldMarketMainRoutes.selectRows(listOf(a,b,a,b), 4)
    require(duplicates.size==1) { "Duplicate paths must not consume all slots" }
    println("KOTLIN MAIN ROUTE TESTS PASSED: long continuous, distinct network, cap, sparse, dedup")
}
