#!/usr/bin/env python3
"""Apply connected long trade backbones to mobile-dev (virtual merchant network v1)."""
from pathlib import Path
import sys

ROOT = Path.cwd()
BASEDIR = Path(__file__).resolve().parent
PATCH_ID = "GS_CONNECTED_TRADE_BACKBONE_V2"
MAIN = ROOT / "core/src/com/unciv/logic/market/WorldMarketMainRoutes.kt"
ECON = ROOT / "core/src/com/unciv/logic/market/WorldMarketEconomicRoutePlanner.kt"
UI = ROOT / "core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt"


def once(haystack, needle, target, name):
    count = haystack.count(needle)
    if count != 1:
        raise ValueError(f"{name}: expected one anchor, found {count}: {needle[:70]!r}")
    return haystack.replace(needle, target, 1)


def patch_main(src):
    if PATCH_ID in src:
        raise ValueError("Main trade route v2 already applied")
    begin = "    internal fun selectRows(rows: List<MarketRouteStat>, maximum: Int): List<MainTradeCorridor> {"
    end = "    private fun other(edge: Edge, one: HexCoord): HexCoord ="
    if src.count(begin) != 1 or src.count(end) != 1:
        raise ValueError("main route function anchors mismatch")
    i, j = src.index(begin), src.index(end)
    if j <= i:
        raise ValueError("bad selection function boundaries")
    updated = src[:i] + (BASEDIR / "main_selection.ktpart").read_text() + src[j:]
    updated = once(updated, '    private const val MinCorridorEdges = 4\n',
                   '    private const val MinCorridorEdges = 8\n', "main corridor length")
    return updated


def patch_econ(src):
    if PATCH_ID in src:
        raise ValueError("Economic path tie preference already applied")
    src = once(src,
        '    private data class SearchNode(val tile: Tile, val cost: Int)\n',
        '    // GS_CONNECTED_TRADE_BACKBONE_V2: prefer a main line on equal-cost routes.\n'
        '    private data class SearchNode(val tile: Tile, val cost: Int, val mainSteps: Int)\n'
        '    private data class Score(val cost: Int, val mainSteps: Int)\n',
        "economic search node")
    src = once(src,
        '''        val best = HashMap<Tile, Int>()
        val parent = HashMap<Tile, Tile?>()
        val queue = PriorityQueue<SearchNode>(compareBy<SearchNode> { it.cost }
            .thenBy { it.tile.position.x }.thenBy { it.tile.position.y })
''',
        '''        val best = HashMap<Tile, Score>()
        val parent = HashMap<Tile, Tile?>()
        val queue = PriorityQueue<SearchNode>(compareBy<SearchNode> { it.cost }
            .thenByDescending { it.mainSteps }
            .thenBy { it.tile.position.x }.thenBy { it.tile.position.y })
''', "economic priority queue")
    src = once(src,
        '''            best[start] = 0
            parent[start] = null
            queue.add(SearchNode(start, 0))
''',
        '''            best[start] = Score(0, 0)
            parent[start] = null
            queue.add(SearchNode(start, 0, 0))
''', "economic origins")
    src = once(src,
        '''            if (best[current.tile] != current.cost) continue // stale queue entry
''',
        '''            if (best[current.tile] != Score(current.cost, current.mainSteps)) continue // stale queue entry
''', "economic stale queue")
    src = once(src,
        '''                val nextCost = current.cost + stepCost(current.tile, next, main)
                val previousCost = best[next]
                if (previousCost == null || nextCost < previousCost) {
                    best[next] = nextCost
                    parent[next] = current.tile
                    queue.add(SearchNode(next, nextCost))
                }
''',
        '''                val nextCost = current.cost + stepCost(current.tile, next, main)
                val nextMain = current.mainSteps +
                    (if (edge(current.tile.position, next.position) in main) 1 else 0)
                val previous = best[next]
                // Cost remains the PRIMARY objective. A connected main corridor
                // only wins a tie, never a more-expensive alternative.
                if (previous == null || nextCost < previous.cost ||
                    (nextCost == previous.cost && nextMain > previous.mainSteps)) {
                    best[next] = Score(nextCost, nextMain)
                    parent[next] = current.tile
                    queue.add(SearchNode(next, nextCost, nextMain))
                }
''', "economic update")
    return src


def patch_ui(src):
    if PATCH_ID in src:
        raise ValueError("Map v2 label already applied")
    anchor = '''            add("세계 주무역로 ${mainRoutes.size}/${maximumMain}개 · 최근 ${window}턴 전 세계 교역량 기준".toLabel(hideIcons = true))
                .left().growX().row()
'''
    extra = '''            // GS_CONNECTED_TRADE_BACKBONE_V2: summary only, never new pathfinding.
            add("연속 주무역로 총 ${mainRoutes.sumOf { it.tiles.size - 1 }}칸 · 긴 공유 항로 중심 선정".toLabel(hideIcons = true))
                .left().growX().row()
'''
    src = once(src, anchor, anchor + extra, "map summary")
    return src


def main():
    try:
        if not (ROOT / "settings.gradle.kts").exists():
            raise ValueError("Run from Unciv repository root")
        original = {path: path.read_text(encoding="utf-8-sig") for path in (MAIN, ECON, UI)}
        if "GS_VIRTUAL_MERCHANT_NETWORK_V1" not in original[UI]:
            raise ValueError("Expected mobile-dev with virtual merchant network v1")
        result = {
            MAIN: patch_main(original[MAIN]),
            ECON: patch_econ(original[ECON]),
            UI: patch_ui(original[UI]),
        }
        for path, content in result.items():
            if not content.endswith("\n"): raise ValueError(f"No ending newline: {path}")
        # ALL validation completed before changing any source file.
        for path, content in result.items():
            path.write_text(content, encoding="utf-8")
            print("UPDATED", path.relative_to(ROOT))
        print("GS connected trade backbone v2 applied")
    except (ValueError, OSError) as e:
        print("PATCH STOPPED:", e)
        sys.exit(1)

if __name__ == "__main__":
    main()
