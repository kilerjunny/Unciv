# Grand Strategy / Connected Global Trade Backbone v2

Base branch: `mobile-dev`, following `virtual-merchant-network-v1` and `production-city-capital-v1`.

- A **main corridor** is now a long **continuous piece of a real recorded trade path**, spanning repeated high-traffic segments instead of a set of nearby tiny segments.
- Up to the existing global maximum (radius 40 ≈ 8, radius 50 ≈ 10) are selected.
- New corridors require at least 8 new segments and at least 25% of their segments not yet covered by a selected corridor (to avoid exhausting global slots on duplicates).
- SEA/MIXED traffic is given a modest tie preference while choosing main corridors. Land corridors remain possible.
- Economic Dijkstra still minimizes the shipping cost index first (land/coast/ocean, transfer, main-corridor discount); **only equal-cost routes** favor more main corridor segments.
- Add displayed total connected main corridor length in world trade map.
- The existing production-city → buyer-capital endpoints and virtual merchant categorization remain unchanged.
- No changes to gold, resource stockpiles, merchant units, turn timing, AI combat, or map save format.
- Main route selection remains observational/traffic-driven and may fluctuate as recent trade history changes; it is *not* an explicit guaranteed hub-and-spoke routing mandate.

## Installation

Upload this ZIP to the `mobile-dev` branch in GitHub, pull, and from the Unciv repo root run:

```bash
unzip -o connected-trade-backbone-v2.zip -d /tmp
python3 /tmp/connected-trade-backbone-v2/apply_connected_trade_backbone_v2.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

Then stage only:

```
core/src/com/unciv/logic/market/WorldMarketMainRoutes.kt
core/src/com/unciv/logic/market/WorldMarketEconomicRoutePlanner.kt
core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
```

Remove the ZIP via `git rm connected-trade-backbone-v2.zip` if tracked, commit, push, and use Android Build GitHub Actions on `mobile-dev`.

## Testing

1. Overview > Trade > World Market > Trade Map: compare long green main corridor shapes and total lengths to v1.
2. Turn forward and check that new transactions still go from resource-producing city to buyer capital.
3. Check new virtual merchant route breakdown in history.
4. Performance diagnosis: compare several comparable turn times. Selecting a backbone runs once on first economic routing each turn and on tab refresh, not per animation frame.

Limitations: no actual ship movement, port cargo inventory, taxation, or guaranteed main/branch hub linkage yet. Full Android compile and runtime need verification in Codespaces/device.
