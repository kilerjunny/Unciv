# Grand Strategy — territory toll & supply costs v1

**Starting point:** `mobile-dev` **after** `connected-trade-backbone-v2`.

This patch adds border toll, overland/ocean supply, and foreign-harbor charges to **the existing economic route-finding weight**. The producer-city to buyer-capital endpoint model is unchanged. Routes are still observational; trades settle immediately; there is no revenue or expense in gold, no cargo, no stockpile, no actual merchant unit and no border permission restrictions. All amounts below are **abstract transport index units, not G**.

## Provisional index parameters
- Per entered land tile supply: seller country 2; buyer country 3; friendly third-party 3; neutral third-party 5; at-war third-party 8; unclaimed 7. Usable road reduces by 1 (minimum 1).
- Per entered sea tile supply: 1.
- Land-border toll on entering buyer territory 6; friendly third-party 7; neutral third-party 18; at-war third-party 60; seller/empty 0. Sea-to-land arrivals count as entries, but remaining inside the same land territory does not pay another border toll.
- Land/sea transfer: existing +16, plus port fee buyer 3; friendly third-party 3; neutral third-party 8; at-war third-party 20; seller/empty 0.
- Previous terrain index remains land 12 / coast 7 / open ocean 4; 25% main-lane discount on terrain component only; cost-based Dijkstra, main-lane preference only for ties.

The route history stores an explicit breakdown, defaulting to `-1` for legacy records. **No revenue is paid to transit states**; the intended progression is to validate path selection before linking these amounts to game treasury.

## Installation
1. Upload ZIP to the `mobile-dev` branch on GitHub using **Add file → Upload files**, commit.
2. In Codespaces, at repo root:
```
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o territory-tolls-supply-v1.zip -d /tmp
python3 /tmp/territory-tolls-supply-v1/apply_territory_tolls_supply_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```
3. If BUILD SUCCESSFUL:
```
git add core/src/com/unciv/logic/market/WorldMarketTerritoryCosts.kt
git add core/src/com/unciv/logic/market/WorldMarketEconomicRoutePlanner.kt
git add core/src/com/unciv/logic/market/WorldMarketRoutePlanner.kt
git add core/src/com/unciv/logic/market/WorldMarketHistory.kt
git add core/src/com/unciv/logic/market/MarketTradeRecord.kt
git add core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git rm territory-tolls-supply-v1.zip
git commit -m "Add territory supply and transit toll routing costs"
git push origin mobile-dev
```
4. Run GitHub Actions `androidBuild.yml` selecting `mobile-dev`, install APK.

## What to test
- Newly created trades: `Overview → Trade → World Market → Trade History` shows the decomposition and totals (older records will not show it).
- Seller city → buyer capital remains unchanged.
- Routes inside own land avoid foreign tolls if alternative cost is cheaper.
- Third-party crossing produces transit toll when the route enters their land; every entered land tile carries its own supply charge.
- World main backbone, coastal/ocean carrier visualization, market trading, military market stay unaffected.
- Compare turn processing latency and device thermal telemetry for 5–10 turns.
