#!/usr/bin/env python3
"""Apply Grand Strategy territory toll/supply route cost v1 on mobile-dev.

Patches are anchor-validated and prepared fully in memory before writing.
Do not run on a branch containing partially applied modifications.
"""
from pathlib import Path
import sys

ROOT = Path.cwd()
BASE = ROOT / 'core/src/com/unciv/logic/market'
UI = ROOT / 'core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt'
FILES = {
    'economic': BASE / 'WorldMarketEconomicRoutePlanner.kt',
    'route': BASE / 'WorldMarketRoutePlanner.kt',
    'history': BASE / 'WorldMarketHistory.kt',
    'record': BASE / 'MarketTradeRecord.kt',
    'ui': UI,
}
NEW = BASE / 'WorldMarketTerritoryCosts.kt'
SOURCE = Path(__file__).with_name('WorldMarketTerritoryCosts.kt')
MARK = 'GS_TERRITORY_TOLLS_SUPPLY_V1'

def replace(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise ValueError(f'{label}: expected exactly 1 anchor, found {count}: {old[:100]!r}')
    return text.replace(old, new, 1)

def main():
    if not (ROOT / 'settings.gradle.kts').exists():
        raise RuntimeError('Run from Unciv repository root (/workspaces/Unciv).')
    if NEW.exists():
        raise RuntimeError('Patch already applied or new file conflicts: ' + str(NEW))
    data = {key: f.read_text(encoding='utf-8') for key, f in FILES.items()}
    if any(MARK in content for content in data.values()):
        raise RuntimeError('Patch marker already present. No changes made.')
    if not SOURCE.is_file():
        raise RuntimeError('Missing Kotlin payload in unpacked ZIP.')

    economic = data['economic']
    economic = replace(economic,
        'import com.unciv.logic.GameInfo\n',
        'import com.unciv.logic.GameInfo\nimport com.unciv.logic.civilization.Civilization\n',
        'economic import')
    economic = replace(economic,
        '    data class Result(val tiles: List<Tile>, val estimatedCost: Int)\n',
        '''    // GS_TERRITORY_TOLLS_SUPPLY_V1: per-trade index cost breakdown.
    data class Result(
        val tiles: List<Tile>, val estimatedCost: Int,
        val terrainCost: Int, val mainSaving: Int,
        val supplyCost: Int, val tollCost: Int, val portCost: Int
    )
''', 'economic result')
    economic = replace(economic,
        '''    private const val InlandStep = 12
    private const val CoastalStep = 7
    private const val OpenOceanStep = 4
    private const val PortTransfer = 16
''',
        '''    // Terrain, main-route discount, supply, border toll and harbor costs
    // are now calculated together by WorldMarketTerritoryCosts.
''', 'economic constants')
    economic = replace(economic,
        '    fun find(game: GameInfo, origins: Collection<Tile>, destinations: Set<Tile>): Result? {\n',
        '''    fun find(seller: Civilization, buyer: Civilization,
             origins: Collection<Tile>, destinations: Set<Tile>): Result? {
        val game = seller.gameInfo
''', 'economic args')
    economic = replace(economic,
        '                return Result(reversed, current.cost)\n',
        '''                val detail = WorldMarketTerritoryCosts.breakdown(reversed, seller, buyer) { a, b ->
                    edge(a.position, b.position) in main
                }
                return Result(reversed, current.cost, detail.terrain, detail.mainSaving,
                    detail.supply, detail.toll, detail.port)
''', 'economic result creation')
    economic = replace(economic,
        '                val nextCost = current.cost + stepCost(current.tile, next, main)\n',
        '''                val isMain = edge(current.tile.position, next.position) in main
                val nextCost = current.cost + WorldMarketTerritoryCosts.stepCost(
                    current.tile, next, seller, buyer, isMain)
''', 'economic weighted edge')
    # Remove old cost engine, retaining the directionless edge helper.
    start = economic.index('    private fun stepCost(from: Tile, to: Tile, main: Set<Edge>): Int {')
    end = economic.index('    private fun edge(a: HexCoord, b: HexCoord): Edge =', start)
    economic = economic[:start] + economic[end:]
    data['economic'] = economic

    route = data['route']
    route = replace(route,
        '        val originKind: String = "UNKNOWN" // GS_PRODUCTION_CITY_CAPITAL_V1\n',
        '''        val originKind: String = "UNKNOWN", // GS_PRODUCTION_CITY_CAPITAL_V1
        val terrainCost: Int = -1, // GS_TERRITORY_TOLLS_SUPPLY_V1
        val mainSaving: Int = -1,
        val supplyCost: Int = -1,
        val tollCost: Int = -1,
        val portCost: Int = -1
''', 'route breakdown fields')
    route = replace(route,
        '            WorldMarketEconomicRoutePlanner.find(seller.gameInfo, startCities.keys, endCities.keys)\n',
        '            WorldMarketEconomicRoutePlanner.find(seller, buyer, startCities.keys, endCities.keys)\n',
        'route search call')
    route = replace(route,
        '                path.map { it.position }, cheapest.estimatedCost, originKind)\n',
        '''                path.map { it.position }, cheapest.estimatedCost, originKind,
                cheapest.terrainCost, cheapest.mainSaving, cheapest.supplyCost,
                cheapest.tollCost, cheapest.portCost)
''', 'route economic result')
    data['route'] = route

    history = data['history']
    history = replace(history,
        '            item.originKind = route.originKind // GS_PRODUCTION_CITY_CAPITAL_V1\n',
        '''            item.originKind = route.originKind // GS_PRODUCTION_CITY_CAPITAL_V1
            // GS_TERRITORY_TOLLS_SUPPLY_V1: index-only estimated costs.
            item.terrainCost = route.terrainCost
            item.mainSaving = route.mainSaving
            item.supplyCost = route.supplyCost
            item.tollCost = route.tollCost
            item.portCost = route.portCost
''', 'history breakdown')
    data['history'] = history

    record = data['record']
    record = replace(record,
        '    var originKind: String = "UNKNOWN" // GS_PRODUCTION_CITY_CAPITAL_V1: old saves stay UNKNOWN\n',
        '''    var originKind: String = "UNKNOWN", // GS_PRODUCTION_CITY_CAPITAL_V1
    // GS_TERRITORY_TOLLS_SUPPLY_V1: -1 means absent in old saves.
    var terrainCost: Int = -1,
    var mainSaving: Int = -1,
    var supplyCost: Int = -1,
    var tollCost: Int = -1,
    var portCost: Int = -1
''', 'record breakdown fields')
    data['record'] = record

    ui = data['ui']
    ui = replace(ui,
        '''                    if (it.estimatedTransportCost >= 0)
                        add("추정 운송지수: ${it.estimatedTransportCost} (최단거리 아닌 최소 운송비)".toLabel(hideIcons = true)).left().row()
''',
        '''                    if (it.estimatedTransportCost >= 0)
                        add("추정 운송지수: ${it.estimatedTransportCost} (실제 금 차감 없음)".toLabel(hideIcons = true)).left().row()
                    // GS_TERRITORY_TOLLS_SUPPLY_V1: route choice only, no gold transfers.
                    if (it.supplyCost >= 0 && it.tollCost >= 0) {
                        add("보급료 ${it.supplyCost} · 통행료 ${it.tollCost} · 항구/환적 ${it.portCost} (운송지수)".toLabel(hideIcons = true)).left().row()
                        add("기본 ${it.terrainCost} - 주무역로 절감 ${it.mainSaving} + 위 비용 = 총 ${it.estimatedTransportCost}".toLabel(hideIcons = true)).left().row()
                    }
''', 'ui breakdown')
    data['ui'] = ui

    # Require the v2 main-backbone tie-breaker to avoid silently patching old code.
    if 'GS_CONNECTED_TRADE_BACKBONE_V2' not in data['economic']:
        raise RuntimeError('This patch requires connected trade backbone v2 on mobile-dev.')

    # Atomic-ish preflight: do not write any files until every substitution passes.
    for key, text in data.items():
        if not text.endswith('\n'):
            raise RuntimeError(f'File {key} missing final newline')
    NEW.write_text(SOURCE.read_text(encoding='utf-8'), encoding='utf-8')
    for key, content in data.items():
        FILES[key].write_text(content, encoding='utf-8')
    print('GS territory tolls/supply v1 applied to mobile-dev.')
    print('Modified: '+ ', '.join(str(f.relative_to(ROOT)) for f in FILES.values()))
    print('Added: '+str(NEW.relative_to(ROOT)))
    print('No market money transfers, trade settlement, unit movement or city inventories changed.')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('PATCH STOPPED: ' + str(exc), file=sys.stderr)
        sys.exit(1)
