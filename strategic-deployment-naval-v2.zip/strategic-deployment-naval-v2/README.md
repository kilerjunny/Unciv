# Strategic Deployment AI v2 — AI naval homecoming (Android mobile-dev)

Upgrade the **existing v1** peacetime strategic deployment system. No source changes needed outside the three listed Kotlin files. The script refuses unexpected sources, dirty targets, the wrong branch, and partial installations.

## Changes

- Keep the existing **land** defensive garrison behavior and combat priority.
- On AI major-civilization peacetime turns, assign **all eligible navy** (including existing ships) to owned coastal/naval cities: principal harbor guards first, then distribute surplus ships as reserves among nearby ports.
- Naval guards hold within 2 tiles of their assigned base; reserves patrol/hold within 4 water tiles. No forced teleportation. Ships that already occupy a defensible nearby area stay put.
- If the planned port is blocked/unreachable, try another city on a later AI turn; at most 2 full reachability checks per naval decision and revisit failed destinations when the 5-turn plan renews.
- Navy deployment is considered **after** urgent combat checks but **before** optional barbarian-camp roaming. War returns control to the original military AI. Human-owned ships are never auto-commanded.
- Adds naval assignment, holding, movement, and port-failure counters to the existing diagnostic tab. They are not additional top-level turn times.

## Apply in GitHub Codespaces

1. Back up the game save (especially important when testing military AI). Upload this ZIP into the `mobile-dev` repository in GitHub, then in Codespaces:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o strategic-deployment-naval-v2.zip -d /tmp
python3 /tmp/strategic-deployment-naval-v2/apply_strategic_deployment_naval_v2.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

2. If the Android build succeeds:

```bash
git add core/src/com/unciv/logic/automation/civilization/StrategicDeploymentAI.kt \
        core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt \
        core/src/com/unciv/logic/automation/unit/UnitAutomation.kt
git rm --ignore-unmatch strategic-deployment-naval-v2.zip
git diff --cached --check
git commit -m "Expand peacetime naval deployment to all eligible AI ships v2"
git push origin mobile-dev
```

## Test

- Under peaceful conditions, follow ships of an **AI** major civilization for several turns. Check for actual movement toward its own coastal city or its overseas base, then holding station nearby.
- If there are no owned naval cities, ships are deliberately left to the original AI.
- Existing AI naval explorers are included in peacetime stationing. Exploring land units, air units, transported/escorting units, reserved military-market units, and human-controlled ships remain excluded.
- The original v1 had a 1–2 ship limit **per harbor**. v2 removes that limit for peacetime navy. It does **not** make every ship head to the capital, nor eliminate fleet congestion or impossible sea passages.
- New report counters are aggregated over the latest completed game turn; assigned counts sum assignments over any plan refreshes.

**Verification:** The patch's source guards and structural tests are provided; run the Android build and test in game before claiming performance or movement improvements.
