#!/usr/bin/env python3
"""Upgrade mobile-dev Strategic Deployment AI v1 to naval homecoming v2.

Checks the exact existing AI source and all anchors before ANY edits; twice is safe.
"""
from __future__ import annotations
import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path.cwd()
BASE = Path('core/src/com/unciv/logic')
DEP = BASE / 'automation/civilization/StrategicDeploymentAI.kt'
UNIT = BASE / 'automation/unit/UnitAutomation.kt'
PERF = BASE / 'automation/civilization/GrandStrategyPerf.kt'
NEW_SOURCE_PATH = Path(__file__).with_name('StrategicDeploymentAI.kt')
V1_SHA256 = 'eb4d77fb3a531119a3d3da27c18c6f464d2c76d795e2c424224a47a01b2436e1'
MARKER = 'GS_STRATEGIC_DEPLOYMENT_AI_V2'

OLD_UNIT = '''        if (tryHeadTowardsEncampment(unit)) return

        // GS_STRATEGIC_DEPLOYMENT_AI_V1: after combat, before default garrison/exploration.
        if (unit.civ.isAI() && !unit.civ.isAtWar() &&
            GrandStrategyPerf.measure("unit_strategic_deployment") { StrategicDeploymentAI.tryDeploy(unit) }) return

        if (tryGarrisoningLandUnit(unit)) return
'''
NEW_UNIT = '''        // GS_STRATEGIC_DEPLOYMENT_AI_V2: peaceful ships return to their assigned
        // naval bases before optional barbarian-camp roaming. Combat is above.
        if (unit.civ.isAI() && !unit.civ.isAtWar() && unit.baseUnit.isWaterUnit &&
            GrandStrategyPerf.measure("unit_strategic_deployment") { StrategicDeploymentAI.tryDeploy(unit) }) return

        if (tryHeadTowardsEncampment(unit)) return

        // Land troops retain the v1 garrison decision priority.
        if (unit.civ.isAI() && !unit.civ.isAtWar() && !unit.baseUnit.isWaterUnit &&
            GrandStrategyPerf.measure("unit_strategic_deployment") { StrategicDeploymentAI.tryDeploy(unit) }) return

        if (tryGarrisoningLandUnit(unit)) return
'''
PERF_ANCHOR = '''        lines.add("전략 주둔 유지: ${result.counts["strategic_deploy_holding"] ?: 0}회 / " +
            "전략 재배치 이동: ${result.counts["strategic_deploy_moves"] ?: 0}회 / " +
            "경로 불가: ${result.counts["strategic_deploy_unreachable"] ?: 0}회")
'''
PERF_NEW = PERF_ANCHOR + '''        // GS_STRATEGIC_DEPLOYMENT_AI_V2: already included in unit AI timing.
        lines.add("해군 귀항/거점 배정: ${result.counts["strategic_naval_assigned"] ?: 0}기 (계획 갱신 누적)")
        lines.add("해군 주둔 유지: ${result.counts["strategic_naval_holding"] ?: 0}회 / " +
            "귀항·재배치 이동: ${result.counts["strategic_naval_moves"] ?: 0}회 / " +
            "항구 경로 실패: ${result.counts["strategic_naval_port_failures"] ?: 0}회")
'''


def replace_exact(src: str, old: str, new: str, path: Path) -> str:
    n = src.count(old)
    if n != 1:
        raise RuntimeError(f'{path}: expected one exact anchor, found {n}. Nothing changed.')
    return src.replace(old, new, 1)


def main() -> None:
    branch = subprocess.run(['git', 'branch', '--show-current'], capture_output=True, text=True)
    if branch.returncode != 0 or branch.stdout.strip() != 'mobile-dev':
        raise RuntimeError(f'Wrong branch ({branch.stdout.strip() or "unknown"}). Switch to mobile-dev first.')
    for p in (DEP, UNIT, PERF):
        if not (ROOT / p).is_file():
            raise RuntimeError(f'Missing expected mobile source: {p}')
    if not NEW_SOURCE_PATH.is_file():
        raise RuntimeError(f'ZIP extraction incomplete: {NEW_SOURCE_PATH} not found')
    new_source = NEW_SOURCE_PATH.read_text(encoding='utf-8')
    if MARKER not in new_source:
        raise RuntimeError('Incorrect v2 source file in patch ZIP')

    original = {p: (ROOT / p).read_text(encoding='utf-8') for p in (DEP, UNIT, PERF)}
    if (MARKER in original[DEP] and 'GS_STRATEGIC_DEPLOYMENT_AI_V2' in original[UNIT]
            and 'GS_STRATEGIC_DEPLOYMENT_AI_V2' in original[PERF]):
        if original[DEP] == new_source:
            print('v2 already applied. No changes.')
            return
        raise RuntimeError('A different v2 is installed. Nothing changed.')
    if any(MARKER in original[p] for p in (DEP, UNIT, PERF)):
        raise RuntimeError('Partial v2 installation found. Nothing changed.')

    current_hash = hashlib.sha256(original[DEP].encode('utf-8')).hexdigest()
    if current_hash != V1_SHA256:
        raise RuntimeError('StrategicDeploymentAI.kt differs from known v1. Do not overwrite custom edits. Nothing changed.')

    edited_unit = replace_exact(original[UNIT], OLD_UNIT, NEW_UNIT, UNIT)
    edited_perf = replace_exact(original[PERF], PERF_ANCHOR, PERF_NEW, PERF)
    # Preflight staged/working-tree modifications: avoid overwriting anyone's edits.
    status = subprocess.run(['git', 'status', '--porcelain', '--', str(DEP), str(UNIT), str(PERF)],
                            capture_output=True, text=True, check=True)
    if status.stdout.strip():
        raise RuntimeError('One or more Kotlin targets have uncommitted changes. Commit/revert them first. Nothing changed.')

    # Writes happen only after all preconditions and exact anchors passed.
    (ROOT / DEP).write_text(new_source, encoding='utf-8')
    (ROOT / UNIT).write_text(edited_unit, encoding='utf-8')
    (ROOT / PERF).write_text(edited_perf, encoding='utf-8')
    for p in (DEP, UNIT, PERF):
        print('PATCHED', p)
    print('Naval homecoming AI v2 installed; build before committing.')


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print('PATCH ABORTED:', e, file=sys.stderr)
        sys.exit(1)
