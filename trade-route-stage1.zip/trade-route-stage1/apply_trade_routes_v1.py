#!/usr/bin/env python3
"""Apply phase-1 unobtrusive trade-route recognition to kilerjunny/Unciv.

Run at the repository root in a dedicated feature branch based on
feature/world-market-v14. Existing resource/gold settlement is not changed.
"""

from pathlib import Path
import subprocess
import sys
import textwrap

ROOT = Path.cwd()
BRANCH = "feature/trade-route-recognition-v1"
MARKET = Path("core/src/com/unciv/logic/market")
UI = Path("core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt")

PLANNER = textwrap.dedent('''\
    package com.unciv.logic.market

    import com.unciv.logic.city.City
    import com.unciv.logic.civilization.Civilization
    import com.unciv.logic.map.HexCoord
    import com.unciv.logic.map.tile.Tile
    import java.util.ArrayDeque

    /**
     * Phase 1: physical, observational routes only. Does not move resources, charge gold,
     * generate units or alter existing world-market trade acceptance.
     *
     * LAND: traversable land tiles. SEA: continuous water between coastal cities.
     * Diplomatic access, coastal canals, piracy, trade costs and multimodal transfer
     * are intentionally deferred to later phases.
     */
    object WorldMarketRoutePlanner {
        data class Route(
            val mode: String,
            val originCityName: String,
            val destinationCityName: String,
            val tiles: List<HexCoord>
        )

        // Bounded LRU: geographic path is stable until the map or endpoints change.
        // Empty lists cache searches with no route, avoiding repeated map-wide scans.
        private val cache = LinkedHashMap<String, List<HexCoord>>()
        private const val MaxCacheSize = 128
        private const val MaxVisitedTiles = 6000

        fun plan(seller: Civilization, buyer: Civilization): Route {
            val landPair = closestPair(seller, buyer, coastalOnly = false)
            val seaPair = closestPair(seller, buyer, coastalOnly = true)

            val land = landPair?.let { pair ->
                cached(seller, pair.first, pair.second, "LAND") {
                    val from = pair.first.getCenterTile()
                    val to = pair.second.getCenterTile()
                    search(listOf(from), setOf(to)) { it.isLand && !it.isImpassible() }
                }
            }.orEmpty()

            val sea = seaPair?.let { pair ->
                cached(seller, pair.first, pair.second, "SEA") {
                    val from = pair.first.getCenterTile()
                    val to = pair.second.getCenterTile()
                    val starts = from.neighbors.filter { it.isWater && !it.isImpassible() }.toList()
                    val ends = to.neighbors.filter { it.isWater && !it.isImpassible() }.toSet()
                    if (starts.isEmpty() || ends.isEmpty()) emptyList()
                    else {
                        val seaTiles = search(starts, ends) { it.isWater && !it.isImpassible() }
                        if (seaTiles.isEmpty()) emptyList()
                        else listOf(from.position) + seaTiles + listOf(to.position)
                    }
                }
            }.orEmpty()

            return when {
                land.isNotEmpty() && (sea.isEmpty() || land.size <= sea.size) -> {
                    val pair = landPair!!
                    Route("LAND", pair.first.name, pair.second.name, land)
                }
                sea.isNotEmpty() -> {
                    val pair = seaPair!!
                    Route("SEA", pair.first.name, pair.second.name, sea)
                }
                else -> {
                    val pair = landPair ?: seaPair
                    Route("UNRESOLVED", pair?.first?.name.orEmpty(), pair?.second?.name.orEmpty(), emptyList())
                }
            }
        }

        private fun closestPair(
            seller: Civilization,
            buyer: Civilization,
            coastalOnly: Boolean
        ): Pair<City, City>? {
            var best: Pair<City, City>? = null
            var shortest = Int.MAX_VALUE
            for (from in seller.cities) {
                val start = from.getCenterTile()
                if (coastalOnly && start.neighbors.none { it.isWater && !it.isImpassible() }) continue
                for (to in buyer.cities) {
                    val end = to.getCenterTile()
                    if (coastalOnly && end.neighbors.none { it.isWater && !it.isImpassible() }) continue
                    val distance = start.aerialDistanceTo(end)
                    if (distance < shortest) {
                        best = Pair(from, to)
                        shortest = distance
                    }
                }
            }
            return best
        }

        private fun cached(
            seller: Civilization,
            from: City,
            to: City,
            mode: String,
            compute: () -> List<HexCoord>
        ): List<HexCoord> {
            val key = "${seller.gameInfo.gameId}|$mode|${from.id}|${to.id}"
            synchronized(cache) {
                cache[key]?.let { return it }
                val route = compute()
                if (cache.size >= MaxCacheSize) cache.remove(cache.keys.first())
                cache[key] = route
                return route
            }
        }

        private fun search(
            starts: List<Tile>,
            targets: Set<Tile>,
            passable: (Tile) -> Boolean
        ): List<HexCoord> {
            if (starts.isEmpty() || targets.isEmpty()) return emptyList()
            val queue = ArrayDeque<Tile>()
            val parent = HashMap<Tile, Tile?>()
            for (start in starts) {
                if (!passable(start) || parent.containsKey(start)) continue
                parent[start] = null
                queue.addLast(start)
            }
            while (queue.isNotEmpty()) {
                val tile = queue.removeFirst()
                if (tile in targets) {
                    val result = ArrayList<HexCoord>()
                    var current: Tile? = tile
                    while (current != null) {
                        result.add(current.position)
                        current = parent[current]
                    }
                    result.reverse()
                    return result
                }
                if (parent.size >= MaxVisitedTiles) return emptyList()
                for (next in tile.neighbors) {
                    if (!passable(next) || parent.containsKey(next)) continue
                    parent[next] = tile
                    queue.addLast(next)
                }
            }
            return emptyList()
        }
    }
''')

RECORD_OLD = '''data class MarketTradeRecord(
    var turn: Int, var sellerCivId: String, var buyerCivId: String,
    var resourceName: String, var quantity: Int, var totalGold: Int
) : IsPartOfGameInfoSerialization {
    constructor() : this(0, "", "", "", 0, 0)
}'''
RECORD_NEW = '''data class MarketTradeRecord(
    var turn: Int, var sellerCivId: String, var buyerCivId: String,
    var resourceName: String, var quantity: Int, var totalGold: Int,
    // Optional for old saves: observational route metadata, not delayed delivery.
    var routeMode: String = "UNKNOWN",
    var originCityName: String = "",
    var destinationCityName: String = "",
    var routeTiles: ArrayList<com.unciv.logic.map.HexCoord> = ArrayList()
) : IsPartOfGameInfoSerialization {
    constructor() : this(0, "", "", "", 0, 0)
}'''

HISTORY_OLD = '''        items.add(MarketTradeRecord(seller.gameInfo.turns, seller.civID, buyer.civID, resource, qty, gold))'''
HISTORY_NEW = '''        // The original trade has already settled; route recognition is best-effort only.
        // If the planner cannot recognize the path, keep the transaction record intact.
        val item = MarketTradeRecord(seller.gameInfo.turns, seller.civID, buyer.civID, resource, qty, gold)
        try {
            val route = WorldMarketRoutePlanner.plan(seller, buyer)
            item.routeMode = route.mode
            item.originCityName = route.originCityName
            item.destinationCityName = route.destinationCityName
            item.routeTiles = ArrayList(route.tiles)
        } catch (_: Exception) {
            item.routeMode = "UNRESOLVED"
        }
        items.add(item)'''

UI_OLD = '''                add("${it.resourceName.tr()} ${it.quantity}개 · ${it.totalGold}G".toLabel(hideIcons = true)).left().row()'''
UI_NEW = UI_OLD + '''
                // Phase-1 debug view, before the dedicated route-map tab is introduced.
                if (it.routeMode != "UNKNOWN") {
                    val routeLabel = when (it.routeMode) {
                        "LAND" -> "육로"
                        "SEA" -> "항로"
                        else -> "경로 미확인"
                    }
                    val endpoints = if (it.originCityName.isNotBlank() && it.destinationCityName.isNotBlank())
                        "${it.originCityName.tr()} → ${it.destinationCityName.tr()} · " else ""
                    val steps = if (it.routeTiles.size >= 2) " · ${it.routeTiles.size - 1}칸" else ""
                    add("무역로: $endpoints$routeLabel$steps".toLabel(hideIcons = true)).left().row()
                }'''


def git_output(*args):
    return subprocess.check_output(["git", *args], text=True, stderr=subprocess.STDOUT).strip()


def main():
    if not (ROOT / "gradlew").exists() or not (ROOT / MARKET).is_dir():
        sys.exit("오류: Unciv 저장소 최상위 디렉터리에서 실행해야 합니다.")
    try:
        current_branch = git_output("branch", "--show-current")
    except (OSError, subprocess.CalledProcessError) as exc:
        sys.exit(f"오류: Git 브랜치를 확인할 수 없습니다: {exc}")
    if current_branch != BRANCH:
        sys.exit(f"오류: '{BRANCH}' 브랜치에서 실행하세요. 현재: '{current_branch}'")
    edits = {
        MARKET / "MarketTradeRecord.kt": (RECORD_OLD, RECORD_NEW),
        MARKET / "WorldMarketHistory.kt": (HISTORY_OLD, HISTORY_NEW),
        UI: (UI_OLD, UI_NEW),
    }
    replacements = {}
    for path, (before, after) in edits.items():
        full = ROOT / path
        if not full.is_file():
            sys.exit(f"오류: 대상 파일 없음: {path}")
        original = full.read_text(encoding="utf-8")
        if after in original:
            print(f"이미 적용됨: {path}")
            continue
        if original.count(before) != 1:
            sys.exit(f"오류: 예상한 코드가 정확히 한 번 발견되지 않음: {path} (소스 버전 확인 필요)")
        replacements[full] = original.replace(before, after, 1)
    planner_path = ROOT / MARKET / "WorldMarketRoutePlanner.kt"
    if planner_path.exists() and planner_path.read_text(encoding="utf-8") != PLANNER:
        sys.exit(f"오류: 기존에 다른 경로 탐색 파일이 존재합니다: {planner_path}")
    # All checks passed: only now write changes.
    for path, content in replacements.items():
        path.write_text(content, encoding="utf-8")
        print(f"수정: {path.relative_to(ROOT)}")
    if not planner_path.exists():
        planner_path.write_text(PLANNER, encoding="utf-8")
        print(f"신규: {planner_path.relative_to(ROOT)}")
    print("적용 완료. 다음: git diff --check && ./gradlew :android:assembleDebug --no-daemon")


if __name__ == "__main__":
    main()
