# Unciv Grand Strategy — 무역로 인식 1단계

기준 소스: `kilerjunny/Unciv`, `feature/world-market-v14`.

## 목적

기존의 세계 시장 거래와 자원/금의 **즉시 정산은 변경하지 않고**, 완료된 거래마다 지도 타일을 기준으로 경로를 계산해 최근 거래 내역에 기록합니다. 지도상 상선/상단 유닛은 생성하지 않습니다.

## 적용 (GitHub Codespaces)

1. `trade-route-stage1.zip`을 Codespaces의 `/workspaces/Unciv`에 업로드합니다.
2. Codespaces 터미널에서 다음을 실행합니다.

```bash
cd /workspaces/Unciv
git status --short
git fetch origin feature/world-market-v14
git switch -c feature/trade-route-recognition-v1 origin/feature/world-market-v14
unzip -o trade-route-stage1.zip -d /tmp
python3 /tmp/trade-route-stage1/apply_trade_routes_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

`git status --short`에 기존 미커밋 변경사항이 있다면 먼저 확인하고 작업하세요. 이미 동일 이름의 작업 브랜치가 있다면 `git switch feature/trade-route-recognition-v1`로 전환합니다.

3. 빌드가 성공한 다음 원하는 경우 커밋·푸시합니다.

```bash
git add core/src/com/unciv/logic/market/MarketTradeRecord.kt \
        core/src/com/unciv/logic/market/WorldMarketHistory.kt \
        core/src/com/unciv/logic/market/WorldMarketRoutePlanner.kt \
        core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git commit -m "Record geography-based routes for world market trades"
git push -u origin feature/trade-route-recognition-v1
```

## 게임에서 확인할 것

- 기존 세계 시장에서 자원 1개를 구매하거나 AI 간 자동 거래를 발생시킵니다.
- 세계 시장의 **거래 내역**에서 `무역로: [도시] → [도시] · 육로/항로 · N칸` 표기를 확인합니다.
- 기존 거래 금액과 자원 수량이 바뀌지 않는지 확인합니다.
- 오래된 저장 파일의 기존 거래 기록은 경로가 없으므로 무역로 줄이 표시되지 않습니다.

## 1단계 한계 (설계상 의도)

- 판매/구매 국가의 **직선거리상 가장 가까운 도시 쌍**을 출발·도착 후보로 선정합니다. 항로는 해안에 접한 도시만 후보입니다. 실제 자원 산지나 최적 항구 선정은 다음 단계입니다.
- 육로는 연속된 통행 가능한 육지, 항로는 해안 도시 사이의 연속된 물 타일을 탐색합니다. **최대 6,000타일** 탐색 후 찾지 못하면 `경로 미확인`을 표시합니다.
- 외교적 통행권, 적대국 영토, 전쟁·해적 위험, 운송비, 강·운하, 육해상 환적은 아직 반영하지 않습니다.
- 경로는 동일 게임·도시쌍 기준으로 최대 128개를 메모리에 캐시합니다. 실제 지도에서 무역선 이동 애니메이션이나 새 지도 탭은 없습니다.
- 항로가 경로상 더 짧거나 육로가 불가능할 때 항로로 분류합니다. 완성된 비용 최적화 시스템은 아닙니다.

## 상태

- 적용 스크립트: 생성 및 Python 문법 검사 완료
- 실제 GitHub 직접 수정: 미실행 (GitHub 연동 권한 403)
- Kotlin/Android 빌드 및 게임 실행 테스트: **확인 필요** (Codespaces 실행 후 검증)
