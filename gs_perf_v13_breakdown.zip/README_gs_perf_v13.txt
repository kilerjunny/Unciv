Grand Strategy Android - performance profiler v1.3 (READ ONLY)
==============================================================

SOURCE
  Repository: https://github.com/kilerjunny/Unciv
  BASE branch: perf/profiler-v12
  TARGET branch: perf/profiler-v13-breakdown

CHANGES (engine decision logic is preserved)
  * AI unit detail: promotions, special moves, escort, city assault,
    normal movement, civilian/air/land-sea movements.
  * Pathfinding CPU time inside AI unit decisions: instruments
    UnitMovement.getMovementToTilesAtPosition(), getShortestPath(),
    getDistanceToTiles(). Nested path calls are counted only once.
  * Combat and target decisions: attack scan, city targets, advance.
  * Turn start / AI automation / turn end times.
  * Unit counts / AI civ count / major civilizations at war.
  * Existing Trade tab > Performance Diagnostics screen shows results.
  * No save-file format changes, no change to AI behavior, no market changes.

CODESPACES STEPS

1. Open the Codespace for kilerjunny/Unciv. Open a terminal and run:

   cd /workspaces/Unciv
   git status --short
   git fetch origin perf/profiler-v12
   git switch perf/profiler-v12
   git pull --ff-only origin perf/profiler-v12
   git switch -c perf/profiler-v13-breakdown

   If the branch name already exists locally, use:
     git switch perf/profiler-v13-breakdown
   Do not reset or discard uncommitted work.

2. Upload gs_perf_v13_breakdown.zip in the Codespaces Explorer or upload
   gs_perf_v13_breakdown.py directly. If ZIP, unzip at repo root:

   unzip -o gs_perf_v13_breakdown.zip gs_perf_v13_breakdown.py

3. Check and apply from repo root:

   python3 gs_perf_v13_breakdown.py --check
   python3 gs_perf_v13_breakdown.py --apply
   ./gradlew :core:compileKotlin --no-daemon

4. If Kotlin compilation succeeds:

   git add core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt \
      core/src/com/unciv/logic/automation/civilization/NextTurnAutomation.kt \
      core/src/com/unciv/logic/automation/unit/UnitAutomation.kt \
      core/src/com/unciv/logic/map/mapunit/movement/UnitMovement.kt \
      core/src/com/unciv/logic/GameInfo.kt
   git commit -m "Instrument AI pathfinding, combat and turn phases"
   git push -u origin perf/profiler-v13-breakdown

5. Build Android APK using the existing project Android build workflow.
   Inspect 1-3 consecutive turns using Trade > Performance Diagnostics.

LIMITATIONS
  * The patch was syntactically validated as Python, but NOT yet compiled
    against the GitHub Kotlin project or tested as an Android APK.
  * GitHub connector allowed source reads, but branch creation returned 403.
    Therefore no GitHub changes were made by ChatGPT.
  * Detail timers overlap parent timers; never add them to the overall total.
  * Pathfinding totals cover the three selected movement entry points during
    the normal unit AI phase, not every possible movement function.
  * Changes in duration across turns do not by themselves prove slowdown.
