# Unciv Grand Strategy — 도시별 무역 수익 순위 v1 (Android)

대상: `kilerjunny/Unciv`, 브랜치 `mobile-dev`.

## 기능

- `상단` → `도시 무역 통계` 페이지 추가
- `내 문명` / `전체 국가` 전환
- `최근 100건` / `최근 N턴` 전환. N턴은 기존 무역 경로 통계 기간(게임 속도 반영)
- `수출 순수입 순위` / `무역수지 순위` 정렬 전환
- 도시/소속국가, 수출 매출, **실제 지급된** 통행료, 수출 순수입, 수입 지출, 무역수지, 거래 건수, 물동량, 수도 대체 귀속 표시
- 전체 도시 통계 합계와 화면 상위 30개 도시만 표시해 Android 부하 제한
- 화면을 열 때 보존된 거래 기록만 집계하므로 매 턴 AI 연산 추가 없음
- 기존 저장파일 형식, 금화 정산, 시장 주문, AI 자동 매매, 경로 탐색 변경 없음

## 회계 기준 (중요)

`수출 순수입 = 세계시장 판매대금 - 실제 지급된 시장 통행료`
`무역수지 = 수출 순수입 - 세계시장 구매 지출`

이 수치는 **시장 거래로 오간 금화의 현금흐름**이며, 생산비를 포함한 경제학적 '순이익'이 아닙니다. `estimatedTransportCost`, `terrainCost`, `supplyCost` 등 경로 평가 점수는 실제 금화 지출이 아니므로 차감하지 않습니다. 제3자 통행료 수취는 **국가별**로만 기록되어 해당 도시의 수입이라고 임의로 배정하지 않습니다.

**집계는 게임에 남아 있는 최근 최대 100건만 대상**입니다. 따라서 게임 시작 이후의 모든 거래를 포괄하는 누적 통계가 아닙니다. 기존 기록에서 거래 도시가 확인되지 않는 건은 '귀속 정보 없음'으로 따로 셉니다. 일부 거래는 실제 생산 도시가 알려지지 않아 판매국 수도에 귀속될 수 있고, 그런 건은 '수도 대체 귀속'으로 표기합니다.

## Codespaces 설치

먼저 ZIP을 `/workspaces/Unciv`에 업로드해야 합니다.

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
ls -lh city-trade-stats-mobile-v1.zip
unzip -o city-trade-stats-mobile-v1.zip -d /tmp
python3 /tmp/city-trade-stats-mobile-v1/apply_city_trade_stats_v1.py --check
python3 /tmp/city-trade-stats-mobile-v1/apply_city_trade_stats_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

빌드 성공 후:

```bash
git add core/src/com/unciv/logic/market/WorldMarketCityStatistics.kt \
  core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git diff --cached --check
git commit -m "Add city trade revenue rankings to merchant overview"
git push origin mobile-dev
```

GitHub Actions에서 `mobile-dev` APK를 빌드하고 설치한 뒤 `상단 → 도시 무역 통계`를 확인하세요.

## 검증 및 한계

- Python 설치 스크립트 문법과 Kotlin 집계 모델의 **독립 스텁 컴파일/테스트**를 확인했습니다.
- 현재 `mobile-dev` (2026-11-20 기준)의 UI 앵커 7개가 각각 정확히 한 번 있는 것을 GitHub 소스로 확인했습니다.
- 전체 Unciv Android Gradle 빌드와 실기기 UI 테스트는 **미실행** 상태입니다.
- 적용 스크립트는 현재 브랜치가 `mobile-dev`가 아니면 변경을 거부합니다.

파일:
- `apply_city_trade_stats_v1.py`: 적용 스크립트 (중복 실행 방지)
- `WorldMarketCityStatistics.kt`: 순수 집계 로직
