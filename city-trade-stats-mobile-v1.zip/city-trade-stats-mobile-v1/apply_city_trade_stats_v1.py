#!/usr/bin/env python3
"""Apply the mobile city trade statistics v1 patch, safely and idempotently."""
from __future__ import annotations
import argparse
import pathlib
import subprocess
import sys

ROOT = pathlib.Path.cwd()
UI = pathlib.Path('core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt')
DATA = pathlib.Path('core/src/com/unciv/logic/market/WorldMarketCityStatistics.kt')
SOURCE = pathlib.Path(__file__).resolve().parent / 'WorldMarketCityStatistics.kt'


def replace_once(content: str, old: str, new: str, label: str) -> str:
    n = content.count(old)
    if n != 1:
        raise RuntimeError(f'{label}: expected exactly one anchor, found {n}. Branch/version mismatch; nothing written.')
    return content.replace(old, new, 1)


def transform(content: str) -> str:
    content = replace_once(content,
        'import com.unciv.logic.market.WorldMarketRouteStats\n',
        'import com.unciv.logic.market.WorldMarketRouteStats\n'
        'import com.unciv.logic.market.WorldMarketCityStatistics\n',
        'city stats import')
    content = replace_once(content,
        '    private var historyOpen = false\n',
        '    private var historyOpen = false\n'
        '    // GS_CITY_TRADE_STATS_V1: UI-only state; recalculated only on page open.\n'
        '    private var cityStatsOpen = false\n'
        '    private var cityStatsMineOnly = true\n'
        '    private var cityStatsRecentWindow = false\n'
        '    private var cityStatsSortBalance = false\n',
        'city stats state')
    content = replace_once(content,
        '                tradeMapOpen = true\n                historyOpen = false\n                performanceOpen = false\n',
        '                tradeMapOpen = true\n                historyOpen = false\n'
        '                cityStatsOpen = false\n                performanceOpen = false\n',
        'map switch')
    content = replace_once(content,
        '                historyOpen = true\n                tradeMapOpen = false\n                performanceOpen = false\n',
        '                historyOpen = true\n                tradeMapOpen = false\n'
        '                cityStatsOpen = false\n                performanceOpen = false\n',
        'history switch')
    content = replace_once(content,
        '                performanceOpen = true\n                tradeMapOpen = false\n                historyOpen = false\n',
        '                performanceOpen = true\n                tradeMapOpen = false\n'
        '                historyOpen = false\n                cityStatsOpen = false\n',
        'performance switch')
    content = replace_once(content,
        '            pages.add(historyButton).padRight(5f)\n\n            val perfButton',
        '            pages.add(historyButton).padRight(5f).row()\n\n'
        '            val cityStatsButton = TextButton(if (cityStatsOpen) "도시 무역 통계 ✓" else "도시 무역 통계", BaseScreen.skin)\n'
        '            cityStatsButton.onClick {\n'
        '                cityStatsOpen = true\n'
        '                tradeMapOpen = false\n'
        '                historyOpen = false\n'
        '                performanceOpen = false\n'
        '                render()\n'
        '                parentTab.overviewScreen.resizePage(parentTab)\n'
        '            }\n'
        '            pages.add(cityStatsButton).padRight(5f)\n\n'
        '            val perfButton',
        'stats page button')
    content = replace_once(content,
        '        // GS_TRADE_MAP_SPEED_V1: geographic summary; never runs the route planner.\n',
        '''        // GS_CITY_TRADE_STATS_V1: compute from settled records, never pathfind or change gold.
        if (cityStatsOpen) {
            val viewer = playerView.getCiv()
            val game = viewer.gameInfo
            val scopeCiv = if (cityStatsMineOnly && !playerView.isSpectator()) viewer.civID else null
            val period = if (cityStatsRecentWindow) WorldMarketRouteStats.windowTurns(game) else null
            val report = WorldMarketCityStatistics.calculate(game, scopeCiv, period)

            val choices = Table(BaseScreen.skin)
            val scopeButton = TextButton(
                if (scopeCiv != null) "내 문명 ✓" else "전체 국가", BaseScreen.skin)
            scopeButton.onClick {
                cityStatsMineOnly = !cityStatsMineOnly
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            choices.add(scopeButton).padRight(5f)
            val periodButton = TextButton(
                if (cityStatsRecentWindow) "최근 ${WorldMarketRouteStats.windowTurns(game)}턴 ✓" else "최근 100건", BaseScreen.skin)
            periodButton.onClick {
                cityStatsRecentWindow = !cityStatsRecentWindow
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            choices.add(periodButton).row()
            val sortButton = TextButton(
                if (cityStatsSortBalance) "무역수지 순위 ✓" else "수출 순수입 순위 ✓", BaseScreen.skin)
            sortButton.onClick {
                cityStatsSortBalance = !cityStatsSortBalance
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            choices.add(sortButton).colspan(2).left()
            add(choices).left().row()

            add("세계 시장 도시별 통계 · 기록된 거래 ${report.tradesInScope}건".toLabel(
                fontSize = Constants.headingFontSize, hideIcons = true)).left().growX().row()
            add("집계 범위: 저장된 최근 최대 100건${if (period != null) " 중 최근 ${period}턴" else ""}; 과거 전체 누적이 아닙니다.".toLabel(hideIcons = true))
                .left().growX().row()
            add("순수입 = 실제 판매대금 - 실제 통행료. 무역수지 = 판매 순수입 - 구매 지출.".toLabel(hideIcons = true))
                .left().growX().row()
            add("생산비·운송비 추정치는 실제 금화 지출이 아니므로 차감하지 않습니다. 통행료 수취는 국가 단위이며 도시별로 배분하지 않습니다.".toLabel(hideIcons = true))
                .left().growX().row()

            val sorted = if (cityStatsSortBalance)
                report.cities.sortedWith(compareByDescending<WorldMarketCityStatistics.CityTotals> { it.tradeBalanceGold }
                    .thenByDescending { it.netSalesGold }.thenBy { it.cityName }.thenBy { it.civId })
            else report.cities.sortedWith(compareByDescending<WorldMarketCityStatistics.CityTotals> { it.netSalesGold }
                .thenByDescending { it.tradeBalanceGold }.thenBy { it.cityName }.thenBy { it.civId })

            add("도시 ${sorted.size}곳 · 판매 순수입 합계 ${sorted.sumOf { it.netSalesGold }}G · 구매 지출 합계 ${sorted.sumOf { it.importSpendingGold }}G · 무역수지 합계 ${sorted.sumOf { it.tradeBalanceGold }}G".toLabel(hideIcons = true))
                .left().growX().row()
            if (report.exportWithoutCity > 0 || report.importWithoutCity > 0)
                add("도시 귀속 정보 없음: 수출 ${report.exportWithoutCity}건 / 수입 ${report.importWithoutCity}건 (합계에서 제외)".toLabel(hideIcons = true))
                    .left().growX().row()
            if (sorted.isEmpty()) {
                add("아직 도시 이름이 확인된 세계 시장 거래가 없습니다.".toLabel(hideIcons = true)).left().row()
            }

            // Limit widgets, not ledger counts, to keep large-map Android UI light.
            for ((rank, stat) in sorted.take(30).withIndex()) {
                val civName = game.civilizations.firstOrNull { it.civID == stat.civId }
                    ?.civName?.tr() ?: stat.civId
                add("${rank + 1}위 · ${stat.cityName} (${civName})".toLabel(hideIcons = true))
                    .left().growX().padTop(8f).row()
                add("판매 순수입 ${stat.netSalesGold}G (매출 ${stat.grossSalesGold}G - 통행료 ${stat.actualTollsPaidGold}G) · 구매 지출 ${stat.importSpendingGold}G · 무역수지 ${stat.tradeBalanceGold}G".toLabel(hideIcons = true))
                    .left().growX().row()
                add("수출 ${stat.exportTrades}건/${stat.exportedUnits}개 · 수입 ${stat.importTrades}건/${stat.importedUnits}개${if (stat.capitalFallbackTrades > 0) " · 수도 대체 귀속 ${stat.capitalFallbackTrades}건" else ""}".toLabel(hideIcons = true))
                    .left().growX().row()
            }
            if (sorted.size > 30)
                add("화면 성능을 위해 상위 30개 도시만 표시합니다. 위 합계에는 전체 도시가 포함됩니다.".toLabel(hideIcons = true))
                    .left().growX().row()
            return
        }

        // GS_TRADE_MAP_SPEED_V1: geographic summary; never runs the route planner.
''',
        'city stats page')
    return content


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true', help='validate patch anchors without writing')
    args = parser.parse_args()
    try:
        branch = subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip()
        if branch != 'mobile-dev':
            raise RuntimeError(f'Expected mobile-dev, found {branch!r}; refused to patch.')
        ui_path = ROOT / UI
        data_path = ROOT / DATA
        old = ui_path.read_text(encoding='utf-8')
        if 'GS_CITY_TRADE_STATS_V1' in old:
            if not data_path.exists() or 'GS_CITY_TRADE_STATS_V1' not in data_path.read_text(encoding='utf-8'):
                raise RuntimeError('UI is patched but model file is missing; please inspect files.')
            print('ALREADY APPLIED: city trade stats v1')
            return 0
        if not data_path.parent.is_dir():
            raise RuntimeError(f'Expected game market source directory missing: {data_path.parent}')
        if data_path.exists():
            raise RuntimeError(f'Unexpected existing {DATA}; will not overwrite it.')
        new = transform(old)
        model = SOURCE.read_text(encoding='utf-8')
        assert 'GS_CITY_TRADE_STATS_V1' in new and 'GS_CITY_TRADE_STATS_V1' in model
        if args.check:
            print('CHECK PASS: mobile-dev anchors, new Kotlin model, no files changed.')
            return 0
        # Both checks above finish before any write.
        ui_path.write_text(new, encoding='utf-8')
        data_path.write_text(model, encoding='utf-8')
        print(f'PATCHED {UI}')
        print(f'ADDED   {DATA}')
        print('City trade statistics page ready; run Gradle build and test on device.')
        return 0
    except Exception as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
