# Unciv Grand Strategy: Android thermal monitor v1

Based on branch `feature/trade-map-cool-v1`.

Adds *only diagnostics* (no gameplay, pathfinder, save, or market changes).

- Android reads battery temperature from the sticky `ACTION_BATTERY_CHANGED` broadcast, as tenths of degrees Celsius.
- Android 10+ reads `PowerManager.currentThermalStatus` (thermal throttling severity, **not temperature**).
- Samples every 15 seconds while Activity resumed. Stops on pause/destroy; no background service.
- Records the first, latest, minimum and peak observed battery temperatures, the current/worst throttling status, charging, sample count and time span **in memory only**. Session resets when app process exits.
- Access in the game: overview -> Trading -> World Market -> **성능 진단** -> **발열 새로고침**. The UI does not live-refresh by itself.
- If device does not provide sensor/status: "확인 불가"; does not silently make values up.

## Install via GitHub Add file

1. Upload `unciv-thermal-monitor-v1.zip` to branch `feature/trade-map-cool-v1`, using Add file -> Upload files, and commit it.
2. Run in Codespaces:

```bash
git switch feature/trade-map-cool-v1
git pull --ff-only origin feature/trade-map-cool-v1
git switch -c feature/android-thermal-monitor-v1
unzip -o unciv-thermal-monitor-v1.zip -d /tmp
python3 /tmp/unciv-thermal-monitor-v1/apply_thermal_monitor_v1.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

3. If build succeeds:

```bash
git add android/src/com/unciv/app/AndroidLauncher.kt core/src/com/unciv/logic/automation/civilization/GrandStrategyThermal.kt core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git commit -m "Add Android thermal monitoring to diagnostics"
git push -u origin feature/android-thermal-monitor-v1
```

4. Run GitHub Actions Android build on `feature/android-thermal-monitor-v1`, install APK.

## Caveats

Temperature is battery sensor data, not CPU, GPU, surface or ambient temperature; may lag or be missing.
Thermal status expresses *throttling severity* only; device-dependent. The monitor cannot independently establish why a device is heating. Compare like-for-like tests, and stop if uncomfortably hot. Device temperatures are not collected or transmitted.

For platform documentation: https://developer.android.com/reference/android/os/BatteryManager and https://developer.android.com/reference/android/os/PowerManager
