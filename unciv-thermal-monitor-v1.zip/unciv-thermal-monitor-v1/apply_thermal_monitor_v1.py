#!/usr/bin/env python3
"""Adds lightweight Android battery-temperature and thermal-status telemetry to GS perf UI.
Run from the root of kilerjunny/Unciv, branch feature/trade-map-cool-v1.
"""
from pathlib import Path

MARKER = "GS_THERMAL_MONITOR_V1"
root = Path.cwd()
launcher = root / "android/src/com/unciv/app/AndroidLauncher.kt"
ui = root / "core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt"
monitor = root / "core/src/com/unciv/logic/automation/civilization/GrandStrategyThermal.kt"

SOURCE = '''package com.unciv.logic.automation.civilization

/**
 * GS_THERMAL_MONITOR_V1
 * In-memory, low-frequency Android thermal readings. No save data or game rules affected.
 * Battery temperature is NOT CPU/GPU/skin temperature, and the Android thermal level
 * is a throttling severity signal rather than a temperature in degrees.
 */
object GrandStrategyThermal {
    private var samples = 0
    private var startedAtMs = 0L
    private var latestAtMs = 0L
    private var firstTemp: Float? = null
    private var latestTemp: Float? = null
    private var lowestTemp: Float? = null
    private var highestTemp: Float? = null
    private var currentStatus: Int? = null
    private var worstStatus: Int? = null
    private var charging: Boolean? = null

    @Synchronized
    fun record(batteryCelsius: Float?, thermalStatus: Int?, isCharging: Boolean?) {
        val now = System.currentTimeMillis()
        if (samples == 0) startedAtMs = now
        samples++
        latestAtMs = now
        batteryCelsius?.let { temperature ->
            if (temperature in -20f..100f) {
                if (firstTemp == null) firstTemp = temperature
                latestTemp = temperature
                lowestTemp = minOf(lowestTemp ?: temperature, temperature)
                highestTemp = maxOf(highestTemp ?: temperature, temperature)
            }
        }
        currentStatus = thermalStatus
        if (thermalStatus != null) worstStatus = maxOf(worstStatus ?: thermalStatus, thermalStatus)
        charging = isCharging
    }

    private fun temp(value: Float?): String =
        if (value == null) "확인 불가" else "${"%.1f".format(java.util.Locale.US, value)}°C"

    private fun status(value: Int?): String = when (value) {
        null -> "확인 불가"
        0 -> "없음(제한 없음)"
        1 -> "경미(LIGHT)"
        2 -> "중간(MODERATE)"
        3 -> "심함(SEVERE)"
        4 -> "위험(CRITICAL)"
        5 -> "긴급(EMERGENCY)"
        6 -> "종료 필요(SHUTDOWN)"
        else -> "알 수 없음($value)"
    }

    @Synchronized
    fun reportLines(): List<String> {
        if (samples == 0) return listOf(
            "---- Android 발열 측정 ----",
            "측정 데이터 없음 (Android 게임에서 실행 후 확인)",
            "배터리 온도는 CPU/GPU 온도가 아닙니다."
        )
        val elapsed = ((latestAtMs - startedAtMs) / 1000L).coerceAtLeast(0L)
        return listOf(
            "---- Android 발열 측정 (앱 실행 중 15초 간격) ----",
            "배터리 온도: 현재 ${temp(latestTemp)} · 시작 ${temp(firstTemp)}",
            "배터리 온도: 최저 ${temp(lowestTemp)} · 최고 ${temp(highestTemp)}",
            "Android 발열 제한: 현재 ${status(currentStatus)} · 최악 ${status(worstStatus)}",
            "충전 상태: ${when (charging) { true -> "충전 중"; false -> "충전 아님"; null -> "확인 불가" }}",
            "측정: ${samples}회 · 기록 구간 ${elapsed / 60}분 ${elapsed % 60}초",
            "※ 배터리 온도는 CPU/GPU 온도가 아닙니다. 기기별 센서 제공 여부에 따라 확인 불가할 수 있습니다.",
            "※ 최근 샘플은 화면 열기/새로고침 시 표시되며, 앱을 완전히 종료하면 기록은 초기화됩니다."
        )
    }
}
'''


def replace_once(src: str, before: str, after: str, where: str) -> str:
    n = src.count(before)
    if n != 1:
        raise SystemExit(f"ERROR {where}: expected exactly one anchor, found {n}: {before[:110]!r}")
    return src.replace(before, after, 1)


def patch_launcher(src: str) -> str:
    if MARKER in src:
        print("Already patched: AndroidLauncher.kt")
        return src
    src = replace_once(src, "import android.content.Intent\n", "import android.content.Context\nimport android.content.Intent\nimport android.content.IntentFilter\n", "Launcher imports")
    src = replace_once(src, "import android.os.Bundle\n", "import android.os.BatteryManager\nimport android.os.Build\nimport android.os.Bundle\nimport android.os.Handler\nimport android.os.Looper\nimport android.os.PowerManager\n", "Launcher Android imports")
    src = replace_once(src, "import com.unciv.logic.IdChecker\n", "import com.unciv.logic.IdChecker\nimport com.unciv.logic.automation.civilization.GrandStrategyThermal\n", "Launcher GS import")
    fields = '''    // GS_THERMAL_MONITOR_V1: Sampling only while the Activity is resumed, 1 read/15 seconds.
    // Does not keep the screen on, create a service, or run while the game is paused.
    private val thermalHandler = Handler(Looper.getMainLooper())
    private val thermalTask = object : Runnable {
        override fun run() {
            sampleThermalState()
            thermalHandler.postDelayed(this, 15_000L)
        }
    }

    private fun startThermalSampling() {
        thermalHandler.removeCallbacks(thermalTask)
        thermalTask.run()
    }

    private fun stopThermalSampling() {
        thermalHandler.removeCallbacks(thermalTask)
    }

    private fun sampleThermalState() {
        // ACTION_BATTERY_CHANGED is sticky: no broadcast receiver registration needed.
        val battery = try {
            applicationContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (_: Exception) {
            null
        }
        val rawTemp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val tempC = if (rawTemp > 0 && rawTemp < 1000) rawTemp / 10f else null
        val batteryStatus = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging: Boolean? = when (batteryStatus) {
            BatteryManager.BATTERY_STATUS_CHARGING, BatteryManager.BATTERY_STATUS_FULL -> true
            BatteryManager.BATTERY_STATUS_DISCHARGING, BatteryManager.BATTERY_STATUS_NOT_CHARGING -> false
            else -> null
        }
        val thermalLevel: Int? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                (getSystemService(Context.POWER_SERVICE) as? PowerManager)?.currentThermalStatus
            } catch (_: Exception) {
                null
            }
        } else null
        GrandStrategyThermal.record(tempC, thermalLevel, charging)
    }

'''
    src = replace_once(src, '    private var game: AndroidGame? = null\n\n', '    private var game: AndroidGame? = null\n\n'+fields, "Launcher field")
    src = replace_once(src, '    override fun onPause() {\n', '    override fun onPause() {\n        stopThermalSampling()\n', "Launcher pause")
    src = replace_once(src, '''        super.onResume()
    }

    override fun onNewIntent''', '''        super.onResume()
        startThermalSampling()
    }

    override fun onDestroy() {
        stopThermalSampling()
        super.onDestroy()
    }

    override fun onNewIntent''', "Launcher resume")
    return src


def patch_ui(src: str) -> str:
    if MARKER in src:
        print("Already patched: WorldMarketTradeSection.kt")
        return src
    src = replace_once(src, 'import com.unciv.logic.automation.civilization.GrandStrategyPerf\n', 'import com.unciv.logic.automation.civilization.GrandStrategyPerf\nimport com.unciv.logic.automation.civilization.GrandStrategyThermal\n', 'UI import')
    old = '''        if (performanceOpen) {
            val gameId = playerView.getCiv().gameInfo.gameId
            for (line in GrandStrategyPerf.reportLines(gameId)) {
                add(line.toLabel(hideIcons = true)).left().row()
            }
            return
        }
'''
    new = '''        if (performanceOpen) {
            // GS_THERMAL_MONITOR_V1: Refresh only on tap, not every render frame.
            val refresh = TextButton("발열 새로고침", BaseScreen.skin)
            refresh.onClick {
                render()
                parentTab.overviewScreen.resizePage(parentTab)
            }
            add(refresh).left().row()
            for (line in GrandStrategyThermal.reportLines()) {
                add(line.toLabel(hideIcons = true)).left().row()
            }
            add("---- 기존 턴 성능 진단 ----".toLabel(hideIcons = true)).left().row()
            val gameId = playerView.getCiv().gameInfo.gameId
            for (line in GrandStrategyPerf.reportLines(gameId)) {
                add(line.toLabel(hideIcons = true)).left().row()
            }
            return
        }
'''
    return replace_once(src, old, new, 'UI performance view')


def main():
    for path in (launcher, ui):
        if not path.is_file():
            raise SystemExit(f"ERROR: missing {path}")
    # All edits are verified before writing to avoid a partial patch.
    new_launcher = patch_launcher(launcher.read_text(encoding='utf-8'))
    new_ui = patch_ui(ui.read_text(encoding='utf-8'))
    if monitor.exists() and MARKER not in monitor.read_text(encoding='utf-8'):
        raise SystemExit(f"ERROR: file exists with different content: {monitor}")
    launcher.write_text(new_launcher, encoding='utf-8')
    ui.write_text(new_ui, encoding='utf-8')
    monitor.write_text(SOURCE, encoding='utf-8')
    print('Patched:', launcher.relative_to(root))
    print('Patched:', ui.relative_to(root))
    print('Created:', monitor.relative_to(root))
    print('Thermal monitoring patch applied. Build Android APK and test on device.')

if __name__ == '__main__':
    main()
