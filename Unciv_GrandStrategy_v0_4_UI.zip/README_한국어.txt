Unciv Grand Strategy v0.4 — 편제 화면 업데이트

이 파일은 공식 Unciv 게임이 아니라, 사용자의 개인 GitHub 저장소
kilerjunny/Unciv 의 grand-strategy-formations 브랜치에 적용하는 코드입니다.

주요 변화
- 편제 이름을 누르면 하위 편제와 직속 유닛이 펼쳐지는 트리 화면
- 모두 펼치기 / 모두 접기
- 소속 유닛 수 (하위 편제 포함) 표시
- 생성, 이름 변경, 편제 이동/삭제, 유닛 배속/해제 유지
- 배속 후보 목록 열기/닫기로 긴 화면 완화
- 깨지는 그림문자 제거
- 기존 편제 저장 데이터(형식 version 1) 유지
- 기존 Tech Stopper 르네상스 모드 파일 변경 없음

적용 방법 (GitHub Codespaces 터미널 /workspaces/Unciv)
1) 이 ZIP을 Codespaces 파일 목록의 Unciv 최상위 폴더에 업로드
2) 아래 한 줄 붙여넣고 실행

unzip -o Unciv_GrandStrategy_v0_4_UI.zip && bash apply_v0_4.sh

3) 성공하면 GitHub > Actions > Android build 에서 새 빌드 확인
4) 성공한 빌드의 grand-strategy-debug-apk 압축 파일 다운로드
5) 기존 Grand Strategy 앱 위에 업데이트 설치 (삭제 후 재설치하지 말 것)

참고
- 이 패키지의 Kotlin 코드에 대해 독립된 컴파일러 및 모의 의존성으로
  문법·타입 검사를 진행했습니다. 실제 Unciv 전체 빌드와 실제 앱 작동은
  GitHub Actions 및 기기에서 추가 확인해야 합니다.
- 적용 스크립트는 소스와 Actions workflow 두 파일만 git add/commit/push합니다.
- 기존 코드에 미커밋 변경이 있으면 덮어쓰지 않고 중단합니다.
