#!/usr/bin/env python3
"""Upgrade the England island-start preference to small 2-3-city islands on Unciv mobile-dev or pc-dev."""
from __future__ import annotations

import argparse
import re
import subprocess
from pathlib import Path

TARGET = Path("core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt")
NEW_MARKER = "GS_ENGLAND_ISLAND_START_V2_SMALL_HOMELAND"
OLD_START = re.compile(r"(?m)^        // GS_ENGLAND_ISLAND_START_(?:MOBILE|PC)_V1:\n")
OLD_END = "        // Avoid assigning England a second start through the regular bias buckets.\n"
NEW_CODE = '''        // GS_ENGLAND_ISLAND_START_V2_SMALL_HOMELAND:
        // England prefers an independent, compact island where the capital plus
        // one or two other cities can fit using the actual same-continent city
        // spacing rule. Never change map terrain or make any new starting spot.
        val unpickedRegions = regions.toMutableList()
        var islandAssignedEngland: Civilization? = null
        if (maritime && !gameParameters.noStartBias) {
            val england = civilizations.firstOrNull { it.civName == "England" }
            if (england != null) {
                // Core target 28..50 land tiles; 24..55 is a limited fallback.
                // The previous version could pick up to 60% of the main continent.
                val citySpacing = ruleset.modOptions.constants.minimalCityDistance
                val islandLand = tileMap.values.asSequence()
                    .filter { it.isLand && !it.isImpassible() }
                    .groupBy { it.getContinent() }
                val startsPerContinent = regions.groupingBy { region ->
                    tileMap[region.startPosition!!].getContinent()
                }.eachCount()

                val englishIsland = unpickedRegions.mapNotNull { region ->
                    val start = tileMap[region.startPosition!!]
                    val continent = start.getContinent()
                    val size = tileMap.continentSizes[continent] ?: 0
                    if (size !in 24..55 || !start.isAdjacentToCoast() ||
                        start.getTilesInDistanceRange(1..2).count { it.isLand } < 7
                    ) return@mapNotNull null

                    // A future city must be on the same connected island, on
                    // passable land, and outside London's minimum city spacing.
                    // Pre-settlement we cannot guarantee later ownership,
                    // foreign settlement, or future resource development.
                    val otherSites = (islandLand[continent] ?: emptyList())
                        .filter { it != start && start.aerialDistanceTo(it) > citySpacing }
                    if (otherSites.isEmpty()) return@mapNotNull null
                    val canFitThree = otherSites.any { one ->
                        otherSites.any { two -> one.aerialDistanceTo(two) > citySpacing }
                    }

                    // Give a dedicated British island preference over sharing
                    // one starting continent with a different major civ.
                    val exclusiveStart = startsPerContinent[continent] == 1
                    val idealSize = size in 28..50
                    val score = (if (idealSize) 1_000_000 else 0) +
                        (if (exclusiveStart) 100_000 else 0) +
                        (if (canFitThree) 10_000 else 0) +
                        (tileData[start]?.startScore ?: 0) -
                        kotlin.math.abs(size - 38) * 8
                    region to score
                }.maxByOrNull { it.second }?.first

                if (englishIsland != null) {
                    logAssignRegion(true, BiasTypes.Coastal, england, englishIsland)
                    assignCivToRegion(england, englishIsland)
                    unpickedRegions.remove(englishIsland)
                    islandAssignedEngland = england
                }
            }
        }

'''


def git(root: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["git", *args], cwd=root, capture_output=True, text=True)


def apply(source: str) -> str:
    if NEW_MARKER in source:
        return source
    m = list(OLD_START.finditer(source))
    if len(m) != 1 or source.count(OLD_END) != 1:
        raise ValueError("Expected exactly one v1 England-island block and its end marker")
    start = m[0].start()
    end = source.index(OLD_END, m[0].end())
    old = source[start:end]
    if old.count("val unpickedRegions = regions.toMutableList()") != 1 or old.count("islandAssignedEngland") < 2:
        raise ValueError("Unexpected England v1 source; refusing to replace code")
    if "MapType.maritimeContinents" not in source or "GS_MARITIME_WORLD_V1" not in source:
        raise ValueError("Maritime World v3 source was not found")
    out = source[:start] + NEW_CODE + source[end:]
    if out.count(NEW_MARKER) != 1 or out.count("val unpickedRegions = regions.toMutableList()") != 1:
        raise ValueError("Result consistency check failed")
    if out.count("val civBiases = civilizations.filterNot { it == islandAssignedEngland }") != 1:
        raise ValueError("England duplicate assignment prevention not found")
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--check", action="store_true", help="Check patch eligibility, don't modify")
    args = ap.parse_args()
    root = Path.cwd()
    branch = git(root, "branch", "--show-current")
    name = branch.stdout.strip()
    if branch.returncode or name not in ("mobile-dev", "pc-dev"):
        raise SystemExit(f"ERROR: Expected mobile-dev or pc-dev, found {name!r}")
    path = root / TARGET
    if not path.exists():
        raise SystemExit(f"ERROR: Missing file: {TARGET}")
    source = path.read_text(encoding="utf-8")
    if NEW_MARKER in source:
        print(f"ALREADY APPLIED: {name}: {NEW_MARKER}")
        return
    if git(root, "diff", "--quiet", "--", str(TARGET)).returncode != 0 or \
       git(root, "diff", "--cached", "--quiet", "--", str(TARGET)).returncode != 0:
        raise SystemExit(f"ERROR: {TARGET} has uncommitted changes; back up or commit first")
    try:
        changed = apply(source)
    except ValueError as e:
        raise SystemExit(f"ERROR: {e}") from e
    if args.check:
        print(f"PASS: {name}: ready to upgrade {TARGET}, other files untouched")
        return
    path.write_text(changed, encoding="utf-8")
    print(f"PATCHED: {name}: {TARGET}")
    print("England now prioritizes islands roughly 28-50 tiles with space for 2-3 cities; 24-55 fallback.")


if __name__ == "__main__":
    main()
