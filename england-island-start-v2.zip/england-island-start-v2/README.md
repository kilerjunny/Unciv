# England Island Start v2 — mobile + PC

**Supported branches:** `mobile-dev` and `pc-dev` only. Requires England Island Start v1 and Maritime World v3 already applied to that branch. Patch modifies exactly one tracked file:

`core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt`

## Design

- Target connected island size: **28–50 land hexes**, with limited fallback **24–55 hexes**. No large-continent fallback within the custom selection.
- Existing coastal starting tile must have **at least 7 land tiles within 2 hexes**.
- Check possible future settlement tiles on same connected island (`isLand && !isImpassible()`).
- For a second city, require city-to-London aerial hex distance **greater than** the ruleset's `minimalCityDistance`.
- For a third city, require two candidate city sites whose mutual distance also exceeds that minimum.
- Prefer an island with **only one major-civilization start region**, and capacity for three cities, rather than simply picking the largest island.
- Requires `Maritime Continents`, England as a selected civilization and **No start bias OFF**.
- If no suitable region exists, original Unciv start allocation remains in charge; the game doesn't alter terrain or guarantee the availability of an island.
- This is a **geometric pre-game feasibility check**, not a promise that future settlement will be possible after expansion, neighboring civilizations, or additional game rules. Land shape, water/coast, and existing start-region distribution all matter.
- This patch affects **newly generated games** only.

## Install on Android (`mobile-dev`)

Upload ZIP to the Unciv project root in Codespaces, then:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
ls -lh england-island-start-v2.zip
unzip -o england-island-start-v2.zip -d /tmp
python3 /tmp/england-island-start-v2/apply_england_island_start_v2.py --check
python3 /tmp/england-island-start-v2/apply_england_island_start_v2.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

If build succeeds:

```bash
git add core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt
git commit -m "Prefer compact 2-3 city islands for England mobile"
git push origin mobile-dev
```

## Install on Windows (`pc-dev`)

The same ZIP and patch script are used:

```bash
git switch pc-dev
git pull --ff-only origin pc-dev
ls -lh england-island-start-v2.zip
unzip -o england-island-start-v2.zip -d /tmp
python3 /tmp/england-island-start-v2/apply_england_island_start_v2.py --check
python3 /tmp/england-island-start-v2/apply_england_island_start_v2.py
git diff --check
./gradlew :desktop:dist :desktop:zipWindows64 --no-daemon
```

If build succeeds:

```bash
git add core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt
git commit -m "Prefer compact 2-3 city islands for England PC"
git push origin pc-dev
```

Windows ZIP is generated in `deploy/Unciv-Windows64.zip`. For Android, use your normal GitHub Actions APK build.

## Verification

Python patch safety and idempotence checks and isolated Kotlin logic tests can validate that the patch structurally compiles and applies; the full Unciv Android and PC builds and island-start behavior must still be tested in Codespaces / the game.
