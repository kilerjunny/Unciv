#!/usr/bin/env python3
"""Offline patch checks using a minimal test Git repository and v2 fixture."""
from __future__ import annotations
import importlib.util
import pathlib
import subprocess
import sys
import tempfile
import zipfile

base = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('apply_v3', base / 'apply_maritime_world_v3.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

# The v2 method fixture is copied from the previous distributed v2 patch.
# We test a stand-in file containing its exact guarded anchors, not all Unciv.
v2 = '''package com.unciv.logic.map.mapgenerator
class MapLandmassGenerator {
    private fun stub() {
        MapType.maritimeContinents -> createMaritimeContinents()
    }
    /**
     * GS_MARITIME_WORLD_V2_SMALL_CONTINENTS
     * source fixture
     */
    private fun createMaritimeContinents() {
        val tiles = tileMap.values.toList()
        val byElevation = tiles.map { tile ->
            getRidgedPerlinNoise(tile, elevationSeed, scale = 22.0)
        }
        val score = maritimeLandmassScore(tiles, land)
        val newIslands = addMaritimeIslandChains()
        carveMaritimeStraits(newIslands)
    }
    private fun maritimeLandmassScore(tiles: List<Tile>, land: BooleanArray): Int = 0
    /** Bounded 4-tile island groups, generally within five tiles of existing land. */
    private fun addMaritimeIslandChains(): Set<Tile> {
        val createdIslands = HashSet<Tile>()
        for (center in candidates) {
            if (center.baseTerrain != waterTerrainName) continue
            val neighbors = center.neighbors.toList()
            if (neighbors.size != 6 || neighbors.any { it.baseTerrain != waterTerrainName }) continue
        }
        return createdIslands
    }
}
'''
patched, changed = module.transform(v2)
assert changed
assert module.VERSION in patched
assert 'private fun addMaritimeIslandChains(protectedOceanCore: Set<Tile>)' in patched
assert 'if (center in protectedOceanCore)' in patched
assert 'if (neighbors.any { it in protectedOceanCore })' in patched
assert module.transform(patched) == (patched, False)
for bad in (v2.replace('GS_MARITIME_WORLD_V2_SMALL_CONTINENTS','WRONG'),
            v2.replace('getRidgedPerlinNoise(tile, elevationSeed, scale = 22.0)','unexpected()'),
            v2.replace('addMaritimeIslandChains()','anotherHelper()')):
    try: module.transform(bad)
    except RuntimeError: pass
    else: raise AssertionError('Expected patch to reject mismatching source')

with tempfile.TemporaryDirectory() as tmp:
    root = pathlib.Path(tmp)
    path = root / module.FILE
    path.parent.mkdir(parents=True)
    path.write_text(v2)
    def cmd(*args, expect=0):
        p = subprocess.run(args, cwd=root, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, text=True)
        assert p.returncode == expect, (args, p.stdout, p.stderr)
        return p
    cmd('git','init','-q')
    cmd('git','checkout','-q','-b','mobile-dev')
    cmd('git','config','user.email','testing@example.com')
    cmd('git','config','user.name','Testing')
    cmd('git','add','.')
    cmd('git','commit','-q','-m','v2 fixture')
    cmd(sys.executable,str(base / 'apply_maritime_world_v3.py'),'--check')
    assert path.read_text()==v2
    cmd(sys.executable,str(base / 'apply_maritime_world_v3.py'))
    assert path.read_text()==patched
    cmd('git','diff','--check')
    cmd(sys.executable,str(base / 'apply_maritime_world_v3.py'))  # idempotency
    path.write_text(v2 + '\n// unexpected dirty change\n')
    cmd(sys.executable,str(base / 'apply_maritime_world_v3.py'),'--check',expect=1)
    cmd('git','checkout','--',str(module.FILE))
    cmd('git','checkout','-q','-b','some-other-branch')
    cmd(sys.executable,str(base / 'apply_maritime_world_v3.py'),'--check',expect=1)

print('PASS: v2 anchors, v3 idempotency, fail-closed conflicts, mobile-dev guard, git diff --check')
