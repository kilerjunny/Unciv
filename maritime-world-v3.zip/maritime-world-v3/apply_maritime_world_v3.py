#!/usr/bin/env python3
"""Upgrade Maritime Continents v2 to v3: wider naturally-shaped open oceans.

Only edits MapLandmassGenerator.kt on branch mobile-dev. Existing map types,
start location logic, and save schemas are left untouched. Refuses unexpected
source versions and dirty changes to the target Kotlin file.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import subprocess
import sys

FILE = Path('core/src/com/unciv/logic/map/mapgenerator/MapLandmassGenerator.kt')
OLD_START = '    /**\n     * GS_MARITIME_WORLD_V2_SMALL_CONTINENTS\n'
OLD_END = '    /** Bounded 4-tile island groups, generally within five tiles of existing land. */'
VERSION = 'GS_MARITIME_WORLD_V3_OPEN_OCEANS'

V3 = '''    /**
     * GS_MARITIME_WORLD_V3_OPEN_OCEANS
     * Keep the v2 Small Continents field and its best-of-2/3 candidate choice.
     * Then broaden one or two existing seas using smooth depressions in the
     * elevation field, re-quantizing to ~65% water (at default water level).
     * All work happens once at map creation. No turn-time AI computation.
     */
    private fun createMaritimeContinents() {
        val tiles = tileMap.values.toList()
        if (tiles.isEmpty()) return
        val waterRatio = (0.65 + tileMap.mapParameters.waterThreshold.toDouble()).coerceIn(0.55, 0.75)
        val targetWater = (tiles.size * waterRatio).toInt().coerceIn(0, tiles.size)

        val samples = if (tiles.size >= 18000) 2 else 3
        var bestMask: BooleanArray? = null
        var bestElevations: DoubleArray? = null
        var bestScore = Int.MAX_VALUE
        repeat(samples) {
            val elevationSeed = randomness.RNG.nextInt().toDouble()
            val elevationByIndex = DoubleArray(tiles.size)
            val byElevation = tiles.map { tile ->
                val elevation = getRidgedPerlinNoise(tile, elevationSeed, scale = 22.0) +
                    getOceanEdgesTransform(tile)
                elevationByIndex[tile.zeroBasedIndex] = elevation
                tile.zeroBasedIndex to elevation
            }.sortedWith(compareBy<Pair<Int, Double>> { it.second }.thenBy { it.first })

            val land = BooleanArray(tiles.size)
            for (index in targetWater until byElevation.size)
                land[byElevation[index].first] = true
            val score = maritimeLandmassScore(tiles, land)
            if (score < bestScore) {
                bestScore = score
                bestMask = land
                bestElevations = elevationByIndex
            }
        }

        val baseLand = bestMask ?: return
        val originalElevation = bestElevations ?: return
        val radius = (kotlin.math.sqrt(tiles.size.toDouble()) * 0.18).toInt().coerceIn(6, 24)
        val basins = chooseMaritimeOceanBasins(tiles, baseLand, radius)
        val land = widenMaritimeOceanBasins(tiles, baseLand, originalElevation,
            basins, radius, targetWater)
        for (tile in tiles)
            tile.baseTerrain = if (land[tile.zeroBasedIndex]) landTerrainName else waterTerrainName

        // No extra island groups in the central deep-water region. Existing
        // coastal island chains and optional narrow straits are kept intact.
        val protectedOceanCore = HashSet<Tile>()
        val coreRadius = (radius / 2).coerceAtLeast(2)
        for (center in basins) for (tile in center.getTilesInDistance(coreRadius))
            if (!land[tile.zeroBasedIndex]) protectedOceanCore.add(tile)
        val newIslands = addMaritimeIslandChains(protectedOceanCore)
        carveMaritimeStraits(newIslands)
    }

    /**
     * Select 1-2 WATER centers from v2's candidate layout. Prefer seas that
     * already contain considerable open water, instead of drilling a perfect
     * circle through an intact continent. Reject sites too close to map edges
     * and keep the two basins well separated.
     *
     * The number of samples is fixed, so large maps do not cause quadratic
     * placement searches or a new per-turn performance cost.
     */
    private fun chooseMaritimeOceanBasins(
        tiles: List<Tile>, land: BooleanArray, radius: Int
    ): List<Tile> {
        if (tiles.size < 1400) return emptyList()
        val count = if (tiles.size >= 6500) 2 else 1
        val expectedDisk = 1 + 3 * radius * (radius + 1)
        val possibilities = tiles.filter { !land[it.zeroBasedIndex] }
            .shuffled(randomness.RNG).take(100)
        val centers = ArrayList<Tile>(count)
        repeat(count) {
            var best: Tile? = null
            var bestScore = Int.MAX_VALUE
            for (candidate in possibilities) {
                if (centers.any { it.aerialDistanceTo(candidate) < radius * 2 }) continue
                val disk = candidate.getTilesInDistance(radius).toList()
                // Edge basins look like empty margins, not traversable oceans.
                if (disk.size * 100 < expectedDisk * 72) continue
                val waterCount = disk.count { !land[it.zeroBasedIndex] }
                val waterPercent = waterCount * 100 / disk.size
                if (waterPercent < 52) continue
                // Roughly 78%-wet basins can be broadened naturally without
                // eating up large amounts of existing continental interiors.
                val score = kotlin.math.abs(waterPercent - 78) * 10 - disk.size / 10
                if (score < bestScore) {
                    best = candidate
                    bestScore = score
                }
            }
            if (best != null) centers.add(best)
        }
        return centers
    }

    /**
     * A smooth basin with the original ridged terrain underneath keeps the
     * coast irregular. Re-quantize after applying the basin to preserve the
     * target water fraction instead of just flooding more of the map.
     */
    private fun widenMaritimeOceanBasins(
        tiles: List<Tile>, land: BooleanArray, elevations: DoubleArray,
        basins: List<Tile>, radius: Int, targetWater: Int
    ): BooleanArray {
        if (basins.isEmpty()) return land
        val adjusted = elevations.copyOf()
        for (tile in tiles) for (basin in basins) {
            val distance = tile.aerialDistanceTo(basin)
            if (distance >= radius) continue
            val scaled = distance.toDouble() / radius
            val taper = 1.0 - scaled * scaled
            adjusted[tile.zeroBasedIndex] -= 0.45 * taper * taper
        }
        val sorted = tiles.map { it.zeroBasedIndex }
            .sortedWith(compareBy<Int> { adjusted[it] }.thenBy { it })
        val result = BooleanArray(land.size)
        for (index in targetWater until sorted.size) result[sorted[index]] = true
        // Keep v2's main continental distribution intact: at most 5% of the
        // map may switch land/water because of the ocean widening pass.
        val switches = result.indices.count { result[it] != land[it] }
        if (switches * 20 > tiles.size) return land
        return result
    }

    /**
     * Land component score from v2, unchanged: prefer several viable medium
     * landmasses over a single giant or countless one-tile islands.
     */
    private fun maritimeLandmassScore(tiles: List<Tile>, land: BooleanArray): Int {
        val visited = BooleanArray(land.size)
        val componentSizes = ArrayList<Int>()
        val queue = ArrayDeque<Tile>()
        for (tile in tiles) {
            val index = tile.zeroBasedIndex
            if (!land[index] || visited[index]) continue
            visited[index] = true
            queue.add(tile)
            var size = 0
            while (queue.isNotEmpty()) {
                val current = queue.removeFirst()
                size++
                for (neighbor in current.neighbors) {
                    val neighborIndex = neighbor.zeroBasedIndex
                    if (!land[neighborIndex] || visited[neighborIndex]) continue
                    visited[neighborIndex] = true
                    queue.add(neighbor)
                }
            }
            componentSizes.add(size)
        }
        val totalLand = land.count { it }.coerceAtLeast(1)
        val largestPercent = ((componentSizes.maxOrNull() ?: 0) * 100) / totalLand
        val mediumThreshold = (totalLand / 70).coerceAtLeast(8)
        val mediumCount = componentSizes.count { it >= mediumThreshold }

        val giantPenalty = (largestPercent - 28).coerceAtLeast(0) * 12
        val tooFewPenalty = (4 - mediumCount).coerceAtLeast(0) * 35
        val tooManyPenalty = (mediumCount - 18).coerceAtLeast(0) * 12
        return giantPenalty + tooFewPenalty + tooManyPenalty + kotlin.math.abs(largestPercent - 19)
    }

'''


def check_repo():
    cp = subprocess.run(['git', 'branch', '--show-current'], capture_output=True,
                        text=True, check=True)
    branch = cp.stdout.strip()
    if branch != 'mobile-dev':
        raise RuntimeError(f"Required mobile-dev branch, found {branch!r}")
    if not FILE.is_file():
        raise RuntimeError('Missing ' + str(FILE))
    diff = subprocess.run(['git', 'diff', '--name-only', '--', str(FILE)],
                          capture_output=True, text=True, check=True)
    if diff.stdout.strip():
        current = FILE.read_text(encoding='utf-8')
        if current.count(VERSION) == 1:
            return  # Already applied but not yet committed; a repeated run is safe.
        raise RuntimeError(f'Uncommitted changes in target file {FILE}')


def transform(source: str) -> tuple[str, bool]:
    if VERSION in source:
        if source.count(VERSION) != 1:
            raise RuntimeError('Unexpected partial or duplicated v3 marker')
        return source, False
    if source.count(OLD_START) != 1 or source.count(OLD_END) != 1:
        raise RuntimeError('Expected v2 map generator and unchanged v2 island helper')
    before, rem = source.split(OLD_START, 1)
    old_method, after = rem.split(OLD_END, 1)
    if ('private fun createMaritimeContinents()' not in old_method or
        'getRidgedPerlinNoise(tile, elevationSeed, scale = 22.0)' not in old_method or
        'private fun maritimeLandmassScore(' not in old_method or
        'addMaritimeIslandChains()' not in old_method or
        'carveMaritimeStraits(newIslands)' not in old_method):
        raise RuntimeError('Existing v2 code differs; refusing unsafe overwrite')
    if source.count('MapType.maritimeContinents -> createMaritimeContinents()') != 1:
        raise RuntimeError('Maritime type selection not found')
    new = before + V3 + OLD_END + after
    signature = '    private fun addMaritimeIslandChains(): Set<Tile> {'
    if new.count(signature) != 1:
        raise RuntimeError('v2 island helper signature differs')
    new = new.replace(signature,
        '    private fun addMaritimeIslandChains(protectedOceanCore: Set<Tile>): Set<Tile> {', 1)
    clause = '            if (center.baseTerrain != waterTerrainName) continue\n'
    if new.count(clause) != 1:
        raise RuntimeError('v2 island helper candidate clause differs')
    new = new.replace(clause,
        clause + '            if (center in protectedOceanCore) continue\n', 1)
    neighbor_clause = '            val neighbors = center.neighbors.toList()\n'
    if new.count(neighbor_clause) != 1:
        raise RuntimeError('v2 island helper neighbor clause differs')
    new = new.replace(neighbor_clause,
        neighbor_clause + '            if (neighbors.any { it in protectedOceanCore }) continue\n', 1)
    return new, True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='validate only; no edits')
    args = parser.parse_args()
    try:
        check_repo()
        original = FILE.read_text(encoding='utf-8')
        modified, changed = transform(original)
        if not changed:
            print('Maritime World v3 already applied. No changes made.')
        elif args.check:
            print('OK: Maritime World v2 anchors found; v3 can be applied safely.')
        else:
            FILE.write_text(modified, encoding='utf-8')
            print(f'Patched {FILE} with Maritime World v3 open-ocean generator')
            print('Next: git diff --check && ./gradlew :android:assembleDebug --no-daemon')
    except (RuntimeError, OSError, subprocess.CalledProcessError) as e:
        print('ERROR:', str(e), file=sys.stderr)
        raise SystemExit(1)

if __name__ == '__main__':
    main()
