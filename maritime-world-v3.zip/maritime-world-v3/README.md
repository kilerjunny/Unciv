# Grand Strategy — Maritime World v3 (대양 강화)

**대상:** `kilerjunny/Unciv` GitHub 저장소의 **`mobile-dev` 브랜치**, Maritime World v2가 이미 적용된 상태.

## 목표

- 기존 v2의 `Small Continents` 기반 중소형 대륙 배치를 최대한 유지.
- **대형 지도에서는 원양 중심지 최대 2곳** (작은 지도에서는 1곳) 선택.
- 기존 바다 주변의 높이값을 부드럽게 낮추어 **넓고 연결된 대양을 유도**. 원형 구멍처럼 지형을 잘라내지 않고 기존 노이즈를 유지.
- 대양 중심부에는 새로운 4타일 섬사슬이 생기지 않도록 보호.
- **해양 비율 기본 65%**, 기존 설정의 해수면 수위 `0.00`일 때. 고급 설정 `+0.10`은 목표 75%이므로 혼동 주의.
- 기존 **해안 시작 목표 85%** 로직, 기존 해협 생성, 자원 규칙, 지도 종류, 저장파일 유지.
- 지도 생성 시 한 번만 계산. 매 턴 성능에 추가 계산 없음.

v3 지형은 **새로운 게임/새로운 지도를 생성할 때만** 반영됩니다. 지도 유형 이름은 여전히 `Maritime Continents`입니다.

**제약:** 시드별로 완벽한 대양 2개를 보장하지 않습니다. 적합한 바다 중심을 찾지 못하면 선택된 대양 수가 줄고, 육지 변경량이 5% 초과할 경우 안전하게 기존 대륙 배치를 유지합니다. 최종 해양 비율은 섬/해협 후처리로 소폭 달라질 수 있습니다.

## Codespaces 적용 방법

1. 아래 `maritime-world-v3.zip`을 **태블릿에 다운로드**합니다.
2. Codespaces 왼쪽 파일 탐색기에서 `/workspaces/Unciv` 폴더를 열고 ZIP을 **Upload...**합니다.
3. `mobile-dev` 브랜치에서 터미널 명령 실행:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
ls -lh maritime-world-v3.zip
unzip -o maritime-world-v3.zip -d /tmp
python3 /tmp/maritime-world-v3/apply_maritime_world_v3.py --check
python3 /tmp/maritime-world-v3/apply_maritime_world_v3.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

빌드 성공 후:

```bash
git add core/src/com/unciv/logic/map/mapgenerator/MapLandmassGenerator.kt
git diff --cached --check
git commit -m "Broaden open oceans in Maritime World v3"
git push origin mobile-dev
```

이후 GitHub Actions의 Android APK 빌드로 설치합니다.

## 테스트 체크포인트

1. **새 게임**, 지도 유형 **`Maritime Continents`**, 반경 **60**, 고급 설정 해수면 높이 **`0.00`**.
2. 같은 시드/설정으로 두 번 생성해 지도 형태가 같은지 비교.
3. 서로 다른 시드 3~5개를 생성해 대양 폭/대륙 연결성/섬 분포 평가.
4. 대양 중심이 지나치게 둥근 형태로 잘리거나 육상 확장이 불가능하지 않은지 확인.
5. 문명 및 도시국가 시작 위치 정상 생성, 기존 저장파일 정상 불러오기 확인.

## 검증 결과와 한계

- ZIP 적용 스크립트: v2 코드 앵커 확인, `--check`, 재실행 방지, 브랜치/충돌 방지, Git diff 정적 검사 통과.
- **분리 Kotlin 모의 컴파일/실행:** 12,000타일 육각 연결 모의 지도에서 대양 후보 2곳 선택, 228개 타일의 육지·바다 분류 전환, 해양 비율 **64.8%**.
- **미검증:** 실제 Unciv 전체 `:android:assembleDebug`, 실제 지도 미리보기에서 대양 형태, 여러 시드/규모의 시작 위치 품질 및 성능. 이 부분은 Codespaces/APK 테스트 필요.
