#!/usr/bin/env python3
"""Patch Unciv mobile-dev with a semantics-preserving enemy precheck.

The old expensive movement search still runs unchanged whenever there is an
attackable enemy candidate in its original 5-tile target set. This patch only
skips searching when TargetHelper's own attackability predicate guarantees
there is no target. For large lists, the membership filter uses a HashSet.

Preflight validates all anchors before any source files are changed.
Requires gs-performance-safe-v1 already merged into the source branch.
"""
from pathlib import Path
import sys

ROOT = Path.cwd()
SRC = Path('core/src/com/unciv')
MARKER = 'GS_AI_PATH_PRECHECK_V2'

FILES = {
    'logic/automation/unit/UnitAutomation.kt': [
        (
'''    private fun tryAdvanceTowardsCloseEnemy(unit: MapUnit): Boolean {
        // this can be sped up if we check each layer separately
        val unitDistanceToTiles = unit.movement.getMovementToTilesAtPosition(
                unit.getTile().position,
                unit.getMaxMovement() * CLOSE_ENEMY_TURNS_AWAY_LIMIT
        )
        val closeEnemy = TargetHelper.getAttackableEnemies(unit, unitDistanceToTiles, tilesToCheck = unit.getTile().getTilesInDistance(CLOSE_ENEMY_TILES_AWAY_LIMIT).toList())
''',
'''    private fun tryAdvanceTowardsCloseEnemy(unit: MapUnit): Boolean {
        // GS_AI_PATH_PRECHECK_V2: TargetHelper will examine ONLY these tiles.
        // The usual movement flood-fill is unnecessary if none of them contains
        // an attackable enemy. Air-sweep and nuclear units return earlier from
        // automateUnitMoves, so they never reach this precheck.
        val nearbyTargets = unit.getTile()
            .getTilesInDistance(CLOSE_ENEMY_TILES_AWAY_LIMIT).toList()
        val attacker = MapUnitCombatant(unit)
        if (nearbyTargets.none { TargetHelper.containsAttackableEnemy(it, attacker) }) {
            GrandStrategyPerf.addCount("unit_advance_paths_skipped", 1)
            return false
        }
        // At least one candidate exists: retain the original movement limits,
        // combat filtering and final target choice without any AI rule changes.
        val unitDistanceToTiles = unit.movement.getMovementToTilesAtPosition(
                unit.getTile().position,
                unit.getMaxMovement() * CLOSE_ENEMY_TURNS_AWAY_LIMIT
        )
        val closeEnemy = TargetHelper.getAttackableEnemies(
            unit, unitDistanceToTiles, tilesToCheck = nearbyTargets
        )
'''
        ),
    ],
    'logic/battle/TargetHelper.kt': [
        (
'''        val rangeOfAttack = unit.getRange()
        val attackableTiles = ArrayList<AttackableTile>()

        val unitMustBeSetUp''',
'''        val rangeOfAttack = unit.getRange()
        val attackableTiles = ArrayList<AttackableTile>()

        // GS_AI_PATH_PRECHECK_V2: tilesToCheck is used for membership only.
        // Larger lists (e.g. a 5-tile search radius) were scanned linearly
        // for every candidate attack square. HashSet keeps identical membership
        // semantics; tiny target lists avoid the allocation overhead.
        val allowedTargets: Collection<Tile>? =
            if (tilesToCheck != null && tilesToCheck.size > 8)
                tilesToCheck.toHashSet()
            else tilesToCheck

        val unitMustBeSetUp'''
        ),
        (
'''                    tileContainsAttackableEnemy(unit, tile, tilesToCheck) || unit.isPreparingAirSweep() -> {''',
'''                    tileContainsAttackableEnemy(unit, tile, allowedTargets) || unit.isPreparingAirSweep() -> {'''
        ),
        (
'''    private fun tileContainsAttackableEnemy(unit: MapUnit, tile: Tile, tilesToCheck: List<Tile>?): Boolean {''',
'''    private fun tileContainsAttackableEnemy(unit: MapUnit, tile: Tile, tilesToCheck: Collection<Tile>?): Boolean {'''
        ),
    ],
    'logic/automation/civilization/GrandStrategyPerf.kt': [
        (
'''        item("적 접근 판단", "unit_attack_advance")
''',
'''        item("적 접근 판단", "unit_attack_advance")
        // GS_AI_PATH_PRECHECK_V2: counts are per checked military AI decision,
        // not a separate duration. Do not sum with pathfinding time.
        lines.add("근접 적 없음: 이동범위 경로 탐색 ${result.counts["unit_advance_paths_skipped"] ?: 0}회 생략")
'''
        ),
    ],
}


def preflight(path: Path, rules):
    if not path.is_file():
        raise RuntimeError(f'파일 없음: {path}. Unciv 저장소 루트에서 실행하세요.')
    old = path.read_text(encoding='utf-8')
    if MARKER in old:
        if all(old.count(new) == 1 for _, new in rules):
            return old, old, False
        raise RuntimeError(f'부분 적용/충돌 발견: {path}. 수정하지 않았습니다.')
    new_text = old
    for before, after in rules:
        count = new_text.count(before)
        if count != 1:
            raise RuntimeError(f'적용 위치 불일치({count}회): {path}: {before[:70]!r}. 수정하지 않았습니다.')
        new_text = new_text.replace(before, after, 1)
    return old, new_text, True


def main():
    candidates = {}
    for relative, rules in FILES.items():
        path = ROOT / SRC / relative
        candidates[path] = preflight(path, rules)
    written = []
    try:
        for path, (original, modified, change) in candidates.items():
            if change:
                path.write_text(modified, encoding='utf-8')
                written.append((path, original))
                print(f'PATCHED {path.relative_to(ROOT)}')
            else:
                print(f'ALREADY APPLIED {path.relative_to(ROOT)}')
    except OSError:
        for path, original in reversed(written):
            path.write_text(original, encoding='utf-8')
        raise
    print(f'GS military AI path precheck v2 complete: {len(written)} files changed.')
    print('Next: git diff --check && ./gradlew :android:assembleDebug --no-daemon')


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError) as exc:
        print(f'PATCH FAILED: {exc}', file=sys.stderr)
        sys.exit(1)
