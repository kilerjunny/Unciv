# Unciv mobile-dev — Military AI Path Precheck v2

This is an incremental patch to **gs-performance-safe-v1** (already installed, built and committed). It changes **three Kotlin files** only, with no save format changes.

## What it does

1. `UnitAutomation.tryAdvanceTowardsCloseEnemy`: Before the existing expensive 3-turn movement flood-fill, check whether **any currently attackable enemy is present among the exact 5-tile-radius target set**. If none, return `false` as before and avoid the flood-fill. If at least one is present, preserve the original search, attack filters, damage assessment and movement target selection.
2. `TargetHelper.getAttackableEnemies`: Replace repeated linear membership checks against a large `tilesToCheck` list with a HashSet. A list of <=8 tiles is left unchanged. Only a private argument widens from `List<Tile>?` to `Collection<Tile>?`.
3. `GrandStrategyPerf.reportLines`: Display `근접 적 없음: 이동범위 경로 탐색 N회 생략` as a diagnostic counter, **not added to other timer totals**.

No changes to market/merchant AI, resources, gold, city AI, unit orders or combat rules. No limits on unit count.

## Installation

In GitHub, upload the ZIP file to the root of the `mobile-dev` branch and commit. Open Codespaces and run:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o gs-ai-path-precheck-v2.zip -d /tmp
python3 /tmp/gs-ai-path-precheck-v2/apply_gs_ai_path_precheck_v2.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

If `BUILD SUCCESSFUL`:

```bash
git add core/src/com/unciv/logic/automation/unit/UnitAutomation.kt
git add core/src/com/unciv/logic/battle/TargetHelper.kt
git add core/src/com/unciv/logic/automation/civilization/GrandStrategyPerf.kt
git rm --ignore-unmatch gs-ai-path-precheck-v2.zip
git diff --cached --check
git commit -m "Avoid unnecessary military AI path searches v2"
git push origin mobile-dev
```

For a meaningful benchmark, start from an **identical save and turn** on old/new APKs and compare the next 3–5 turns. Check total turn time, unit AI time, `unit_pathfinding` count/time, advance-decision time, and the new skipped-search count. Variations in AI state are expected across non-identical saves.

## Safety / limits

- Fails before writing if source anchors don't match; repeated runs are idempotent.
- The optimization applies only to a nearby-enemy advance check, *not* every pathfinder entry point.
- Actual Android compilation and game-time improvements **require verification in Codespaces and on device**.
- An empty nearby target scan is safe here because the original `TargetHelper` only selects enemies from the same target set, and the unit types with air-sweep/nuclear behavior return earlier.
