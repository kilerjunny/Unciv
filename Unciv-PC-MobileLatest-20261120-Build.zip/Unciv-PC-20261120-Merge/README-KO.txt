Unciv 최신 모바일 기능 -> PC 버전 빌드 도구

목표:
- 기존 pc-dev 유지
- 최신 mobile-dev의 상단 탭, 세계시장, 통행료, 무역로 및 도시별 무역 수익 통계 적용
- PC 전용 Maritime World / 영국 섬 시작 / 배치 AI 관련 파일 보존
- Windows 64비트 게임 ZIP 생성

Codespaces에서 사용:
1. 이 ZIP을 PC에서 압축 해제
2. build_latest_pc.sh 파일을 Codespaces /workspaces/Unciv 디렉터리에 업로드
3. Codespaces 터미널에서 아래 실행:

   cd /workspaces/Unciv
   bash build_latest_pc.sh

4. 완료되면 아래 경로에서 ZIP 다운로드:
   /workspaces/Unciv/deploy/Unciv-Windows64-MobileLatest-PC.zip

주의:
- 이 배포 파일은 실제 게임 파일이 아닌, Codespaces에서 실제 게임 ZIP을 생성하는 도구다.
- 원본 pc-dev 브랜치에는 커밋/푸시/변경을 하지 않는다.
- 실제 전체 게임 빌드 및 실행은 Codespaces에서 검증해야 한다.
- 모바일과 PC가 다른 함수에서 충돌하면 PC 지도/배치 파일을 우선 보존한다.
- 기존 Unciv Windows64 바이너리는 위 새 ZIP이 성공하기 전까지 유지된다.
