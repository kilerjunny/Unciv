#!/usr/bin/env bash
# Unciv: Build Windows PC version using latest mobile-dev changes,
# while retaining pc-dev's PC-specific naval map/England start behavior.
# Run from a GitHub Codespace with kilerjunny/Unciv checked out.
set -Eeuo pipefail

REPO="${UNCIV_REPO:-/workspaces/Unciv}"
cd "$REPO"
if [[ ! -f gradlew || ! -d .git ]] && [[ ! -f gradlew || ! -f .git ]]; then
  echo "ERROR: Unciv Git repository not found at $REPO" >&2
  exit 1
fi

printf '\n[1/5] Fetch latest PC and mobile branches...\n'
git fetch --no-tags origin \
  '+refs/heads/pc-dev:refs/remotes/origin/pc-dev' \
  '+refs/heads/mobile-dev:refs/remotes/origin/mobile-dev'
PC_SHA=$(git rev-parse --short origin/pc-dev)
MOBILE_SHA=$(git rev-parse --short origin/mobile-dev)
printf 'PC: %s / Mobile: %s\n' "$PC_SHA" "$MOBILE_SHA"

# Use a separate worktree: NEVER overwrite the user's local edits or change their branch.
WORKTREE="/workspaces/unciv-pc-latest-$(date +%Y%m%d-%H%M%S)-$$"
trap 'echo "Build did not finish. Worktree retained at: '"$WORKTREE"'"' ERR
printf '\n[2/5] Create isolated PC build worktree: %s\n' "$WORKTREE"
git worktree add --detach "$WORKTREE" origin/pc-dev
cd "$WORKTREE"

# A three-way merge keeps all independent mobile features and most PC customizations.
# Prefer PC code only where exactly the same lines conflict; explicitly preserve
# PC-only map/England start customization files afterward.
echo "Merging mobile-dev into PC build copy (no remote branch changes)..."
if ! git -c user.name='Unciv PC Build' -c user.email='build@localhost' \
  merge --no-commit --no-ff -X ours origin/mobile-dev; then
  echo 'Merge needs conflict resolutions. Resolving remaining paths...'
  while IFS= read -r -d '' path; do
    case "$path" in
      core/src/com/unciv/logic/map/MapParameters.kt|\
      core/src/com/unciv/logic/map/mapgenerator/MapLandmassGenerator.kt|\
      core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt|\
      core/src/com/unciv/logic/map/mapgenerator/mapregions/RegionStartFinder.kt|\
      core/src/com/unciv/logic/automation/civilization/StrategicDeploymentAI.kt|\
      core/src/com/unciv/logic/automation/unit/UnitAutomation.kt)
        echo "  PC version: $path"
        git checkout --ours -- "$path" ;;
      *)
        echo "  Mobile version: $path"
        git checkout --theirs -- "$path" ;;
    esac
    git add -- "$path"
  done < <(git diff --name-only --diff-filter=U -z)
fi
if [[ -n "$(git diff --name-only --diff-filter=U)" ]]; then
  echo 'ERROR: Some merge conflicts remain. Stop rather than produce an incomplete ZIP.' >&2
  git status --short
  exit 1
fi

# Preserve PC-specific map generation and deployment behavior. This restoration is
# deliberate: mobile and PC have different map-start adjustments on these paths.
for path in \
  core/src/com/unciv/logic/map/MapParameters.kt \
  core/src/com/unciv/logic/map/mapgenerator/MapLandmassGenerator.kt \
  core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt \
  core/src/com/unciv/logic/map/mapgenerator/mapregions/RegionStartFinder.kt \
  core/src/com/unciv/logic/automation/civilization/StrategicDeploymentAI.kt \
  core/src/com/unciv/logic/automation/unit/UnitAutomation.kt
do
  git restore --source=origin/pc-dev --staged --worktree -- "$path"
done

# Check the latest-mobile features are now present in the PC build source.
printf '\n[3/5] Verify merchant, market, and trade statistics code...\n'
test -f core/src/com/unciv/ui/screens/overviewscreen/MerchantOverviewTab.kt
test -f core/src/com/unciv/ui/screens/overviewscreen/WorldMarketOverviewTab.kt
test -f core/src/com/unciv/logic/market/WorldMarketCityStatistics.kt
grep -Fq 'Merchants(' core/src/com/unciv/ui/screens/overviewscreen/EmpireOverviewCategories.kt
grep -Fq 'Market(' core/src/com/unciv/ui/screens/overviewscreen/EmpireOverviewCategories.kt
echo 'Merchant, World Market, and city trade statistics source found.'

printf '\n[4/5] Build PC Windows64 ZIP with Gradle...\n'
chmod +x gradlew
./gradlew :desktop:dist :desktop:zipWindows64 --no-daemon
ZIP="$WORKTREE/deploy/Unciv-Windows64.zip"
test -s "$ZIP"
unzip -tqq "$ZIP"

printf '\n[5/5] Copy finished ZIP to your usual deploy folder...\n'
mkdir -p "$REPO/deploy"
DEST="$REPO/deploy/Unciv-Windows64-MobileLatest-PC.zip"
cp -f "$ZIP" "$DEST"
cat > "$REPO/deploy/Unciv-Windows64-MobileLatest-PC.build-info.txt" <<INFO
PC branch: pc-dev ($PC_SHA)
Mobile branch: mobile-dev ($MOBILE_SHA)
Method: isolated worktree; merge mobile changes; preserve PC-specific map and deployment files
Source code checks: Merchant tab, World Market tab, city trade revenue statistics
Build command: ./gradlew :desktop:dist :desktop:zipWindows64 --no-daemon
NOTE: Only build and archive structure were verified. In-game behavior must be tested.
INFO
ls -lh "$DEST"
printf '\nSUCCESS! Download: %s\n' "$DEST"
printf 'Your original pc-dev branch was NOT modified.\n'
# Remove the temporary build checkout once the ZIP has been copied successfully.
cd "$REPO"
git worktree remove --force "$WORKTREE"
