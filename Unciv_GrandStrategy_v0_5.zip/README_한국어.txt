Unciv Grand Strategy v0.5 — 편제 UI · 유닛 위치 이동 · 군사력 순위

포함 사항
1. 태블릿에선 왼쪽 편제 트리 / 오른쪽 편제 관리. 좁은 화면은 세로 배열.
2. 편제와 직속 유닛을 접고 펼침. 유닛 이름을 탭하면 기존 Unciv 지도에서 그 유닛을 선택.
3. 기존 종합 군사력은 변경하지 않고 육군력 / 해군력 / 공군력 / 비대칭 전력 순위 추가.
4. 비대칭 전력 = 핵무기와 이름이 명시된 유도/순항/탄도미사일(ICBM 등). 특수부대는 육군력.
5. 공군력/비대칭 전력이 모두 0인 게임에서는 해당 순위 열을 표시하지 않음.
6. 이전 편제 저장 형식은 변경하지 않음. 기술 제한 모드 파일도 변경하지 않음.

코드 소스
- UI: core/src/com/unciv/ui/screens/overviewscreen/FormationOverviewTab.kt
- 순위: core/src/com/unciv/ui/screens/victoryscreen/RankingType.kt
- 순위 계산 연결: core/src/com/unciv/logic/civilization/Civilization.kt
- 순위 열 표시: core/src/com/unciv/ui/screens/victoryscreen/VictoryScreenCivRankings.kt
- 계산 모듈: core/src/grandstrategy/rankings/GrandStrategyMilitaryRankings.kt
- 빌드 트리거: .github/workflows/androidBuild.yml

적용 방법 (GitHub Codespaces, 브랜치 grand-strategy-formations)
1. ZIP을 해당 저장소 루트에 올리고 압축 해제합니다.
2. 명령: unzip -o Unciv_GrandStrategy_v0_5.zip && bash apply_v0_5.sh
3. GitHub Actions의 Android build가 Success가 되면 아티팩트 ZIP을 다운로드합니다.
4. APK를 기존 Grand Strategy 앱에 업데이트 설치합니다. 앱 삭제 금지.
5. 편제 보존 및 유닛 지도 이동 / 순위 표시를 게임에서 검증합니다.

안전 장치
- master 브랜치에서 적용 불가.
- 기존 v0.4 파일 해시가 다른 경우 덮어쓰기 거부.
- 수정 대상의 커밋되지 않은 파일이 있으면 중지.
- 변경된 코드 파일만 커밋. ZIP 파일/기존 payload는 자동으로 커밋하지 않음.
- 군사력 숫자: 개별 유닛의 기존 Unciv 전력 평가 합계(최소 1)이며 전략핵 실제 파괴력 계수는 아닙니다.
- 모드가 별도 이름으로 추가한 미사일은 목록에 추가해야 할 수 있습니다.

검증 범위
- Python 문법 및 패치 로직 테스트 / Kotlin 소스 정적 검증 가능.
- 실제 Android 전체 빌드는 GitHub Actions에서 확인 필요.
- 게임 내 편제·모드·랭킹 실사용은 APK 설치 후 확인 필요.
