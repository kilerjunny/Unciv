# England Island Start PC v1 — Unciv Grand Strategy

**Target:** `pc-dev` branch, after Maritime World v3 (`3444c5857` or later).

Changes **only** `core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt`.

- When generating a **new** `Maritime Continents` map and start biases are enabled, England (`civName == "England"`) gets first choice of a suitable **separate landmass** starting region.
- An island must be at least 24–65 connected land tiles (depending on map size), have land within two tiles around its city start, and be at most 60% of the largest landmass, so the choice favors a defensible island and not a huge mainland or single-tile rock.
- Existing region scoring/normalization, world resources, start spacing, other civilizations and other map types retain their original rules.
- If the generator produces no eligible island **starting region**, England falls back to the normal start allocation. This is a **preference, not a guaranteed island**. A later version could explicitly reserve a suitable island before creating start regions to raise reliability.
- When the **No Start Bias** option is enabled, this England-specific preference is disabled.
- Existing saves and maps do not change.

## Apply to `pc-dev` in Codespaces

Upload this ZIP to `/workspaces/Unciv` first, then:

```bash
git switch pc-dev
git pull --ff-only origin pc-dev
ls -lh england-island-start-pc-v1.zip
unzip -o england-island-start-pc-v1.zip -d /tmp
python3 /tmp/england-island-start-pc-v1/apply_england_island_start_pc_v1.py --check
python3 /tmp/england-island-start-pc-v1/apply_england_island_start_pc_v1.py
git diff --check
./gradlew :desktop:dist :desktop:zipWindows64 --no-daemon
```

After `BUILD SUCCESSFUL`:

```bash
git add core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt
git commit -m "Prefer England island starts on Maritime Continents"
git push origin pc-dev
```

Windows ZIP output: `deploy/Unciv-Windows64.zip`.

## Verify

Generate several new Maritime Continents maps with England and inspect the island size and spacing. Repeat across map seeds. If England still starts on a mainland, the chosen seed likely had no eligible island start region: this patch does not manufacture islands or override the game's safe starting sites.

Status: Patch and its Python preflight/idempotence tested locally. Full Unciv desktop build and real generated-map validation must be performed in Codespaces.
