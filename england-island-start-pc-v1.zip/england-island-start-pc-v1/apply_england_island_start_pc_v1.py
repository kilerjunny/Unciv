#!/usr/bin/env python3
"""Add England-specific island start preference to Unciv Maritime Continents (pc-dev)."""
from __future__ import annotations
import argparse
import subprocess
from pathlib import Path

TARGET = Path('core/src/com/unciv/logic/map/mapgenerator/mapregions/MapRegions.kt')
MARKER = 'GS_ENGLAND_ISLAND_START_PC_V1'
CIV_BIASES_ANCHOR = '        val civBiases = civilizations.associateWith {\n'
REGIONS_ANCHOR = '        val unpickedRegions = regions.toMutableList()\n'
BLOCK = '''        // GS_ENGLAND_ISLAND_START_PC_V1:
        // On Maritime Continents, give England first pick of a viable island
        // starting region rather than simply an arbitrary coastal start.
        // A smaller connected landmass is preferred over a one-tile island,
        // and no custom choice is made if no suitable region exists.
        val unpickedRegions = regions.toMutableList()
        var islandAssignedEngland: Civilization? = null
        if (maritime && !gameParameters.noStartBias) {
            val england = civilizations.firstOrNull { it.civName == "England" }
            if (england != null) {
                val largestLandmass = tileMap.continentSizes.values.maxOrNull() ?: 0
                val minimumIslandSize = (tileMap.values.size / 600).coerceIn(24, 65)
                val maximumIslandSize = largestLandmass * 60 / 100
                val eligibleIslands = if (maximumIslandSize < minimumIslandSize) emptyList()
                    else unpickedRegions.filter { region ->
                        val start = tileMap[region.startPosition!!]
                        val size = tileMap.continentSizes[start.getContinent()] ?: 0
                        start.isAdjacentToCoast() &&
                            size in minimumIslandSize..maximumIslandSize &&
                            start.getTilesInDistanceRange(1..2).count { it.isLand } >= 7
                    }
                val englishIsland = eligibleIslands.maxByOrNull { region ->
                    val start = tileMap[region.startPosition!!]
                    val size = tileMap.continentSizes[start.getContinent()] ?: 0
                    (tileData[start]?.startScore ?: 0) + size.coerceAtMost(150) / 3
                }
                if (englishIsland != null) {
                    logAssignRegion(true, BiasTypes.Coastal, england, englishIsland)
                    assignCivToRegion(england, englishIsland)
                    unpickedRegions.remove(englishIsland)
                    islandAssignedEngland = england
                }
            }
        }

        // Avoid assigning England a second start through the regular bias buckets.
        val civBiases = civilizations.filterNot { it == islandAssignedEngland }.associateWith {
'''


def run(*args: str, cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(list(args), cwd=cwd, text=True, capture_output=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true', help='Check eligibility without editing')
    args = parser.parse_args()
    root = Path.cwd()
    branch = run('git', 'branch', '--show-current', cwd=root)
    if branch.returncode != 0 or branch.stdout.strip() != 'pc-dev':
        raise SystemExit(f'ERROR: Expected pc-dev, found {branch.stdout.strip() or "(unknown)"!r}')
    path = root / TARGET
    if not path.is_file():
        raise SystemExit(f'ERROR: Missing {TARGET}')
    original = path.read_text(encoding='utf-8')
    if MARKER in original:
        print('ALREADY APPLIED: England island preference found. No changes made.')
        return
    if 'GS_MARITIME_WORLD_V1' not in original or 'MapType.maritimeContinents' not in original:
        raise SystemExit('ERROR: Maritime World v3 is missing; apply it to pc-dev first.')
    if original.count(CIV_BIASES_ANCHOR) != 1 or original.count(REGIONS_ANCHOR) != 1:
        raise SystemExit('ERROR: Source layout differs; patch safely aborted.')
    if run('git', 'diff', '--quiet', '--', str(TARGET), cwd=root).returncode != 0 or \
       run('git', 'diff', '--cached', '--quiet', '--', str(TARGET), cwd=root).returncode != 0:
        raise SystemExit('ERROR: MapRegions.kt has uncommitted changes; commit/back up before patching.')
    patched = original.replace(REGIONS_ANCHOR, '', 1).replace(CIV_BIASES_ANCHOR, BLOCK, 1)
    if patched.count(MARKER) != 1 or patched.count('val unpickedRegions = regions.toMutableList()') != 1:
        raise SystemExit('ERROR: Patch consistency check failed.')
    if args.check:
        print(f'PASS: pc-dev Maritime v3 source ready; will modify only {TARGET}')
        return
    path.write_text(patched, encoding='utf-8')
    print(f'PATCHED: {TARGET}')
    print('England will prefer a viable separate island on NEW Maritime Continents maps.')


if __name__ == '__main__':
    main()
