# Unciv Grand Strategy: maritime passage and transshipment fee rates v3

Based on the `mobile-dev` branch containing cash-tolls v1. This ZIP **replaces** the older `maritime-passage-transshipment-v2.zip`; you do not need to install v2 first. If v2 is already installed, the script upgrades the rates instead.

## Real-gold rules

- Ordinary third-country land passage: **2G**; friendly seller-to-landowner passage: **1G** (existing friendly discount).
- Third-country controlled coastal-sea passage: **2G** even without stopping at a port. Each third-country controller may charge once per transaction.
- Third-country city harbor used for a land/water cargo transfer: **4G** per country per trade.
- All real fees combined remain capped at **min(6G, floor(trade price × 8%))**. Thus, a 25G trade can pay max 2G, a 50G trade max 4G, and a 300G trade max 6G. When fees exceed the cap, **harbor transshipment gets priority**, then land passage, then sea passage; first encountered country wins ties. The 4G port rate is a nominal fee, not a guarantee for low-price trades.
- Third-country only: no fee for seller or buyer's own land, coastal waters or ports. Unowned deep ocean and ambiguous coastal waters have no controller and charge no fee. War opponents are not paid.
- Buyer continues to pay the listed price; seller pays fees from sale proceeds. Recipients receive exactly the gold deducted; gold is neither minted nor destroyed.
- Supply fee/transport index is separate and unchanged. No changes to routing, ship movement, game gold for supply, military market, or diplomacy trading.
- No retroactive charges to previous trades. Recorded payouts keep separate category totals. Old saved records remain readable.

## Install

Upload this ZIP to your GitHub `mobile-dev` branch (`Add file` → `Upload files`), then in Codespaces at repository root:

```bash
git switch mobile-dev
git pull --ff-only origin mobile-dev
unzip -o maritime-passage-transshipment-rates-v3.zip -d /tmp
python3 /tmp/maritime-passage-transshipment-rates-v3/apply_maritime_fees_rates_v3.py
git diff --check
./gradlew :android:assembleDebug --no-daemon
```

Once `BUILD SUCCESSFUL`, commit source changes and remove uploaded patch archive:

```bash
git add core/src/com/unciv/logic/market/WorldMarketCashTolls.kt
git add core/src/com/unciv/logic/market/MarketTollPayment.kt
git add core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt
git rm maritime-passage-transshipment-rates-v3.zip
git commit -m "Adjust transit and transshipment rates to 2G and 4G"
git push origin mobile-dev
```

If you already committed v2 and its ZIP was removed, just apply v3; it detects that state. Do not upload/apply the old v2 ZIP after v3.

## Test

After building and installing the `mobile-dev` APK, open `개요 → 거래 → 세계 시장 → 거래 내역`. Look for `실제 요금 구분` (not the transport index section). Transactions with no eligible third-country controllers may still display 0G actual fees. At least one third-country harbor transfer is necessary to observe nominal 4G (subject to overall cap). Android compile and in-game behavior require verification.
