#!/usr/bin/env python3
"""Apply v3 rates (transit 2G, harbor transshipment 4G) safely to Unciv mobile-dev.
Supports both cash-tolls v1 and passage v2 as input; writes only on full validation.
"""
from pathlib import Path
import hashlib
import sys

ROOT = Path.cwd()
SRC = Path(__file__).resolve().parent
MARK = "GS_MARITIME_FEES_RATES_V3"
BASE = Path("core/src/com/unciv/logic/market")
UI = Path("core/src/com/unciv/ui/screens/overviewscreen/WorldMarketTradeSection.kt")
EXPECTED = {'WorldMarketCashTolls.kt': {'v1': '6f38f33601412d9700dca7ed401800b00659b39f6728af8a68b42c9930462717', 'v2': 'f0729671f740e11e2eedb7e1cae628c0dd950d513cd6af0447ddccb5f1c86de7'}, 'MarketTollPayment.kt': {'v1': '9df6e572587ade07e4e4e159530dcfec8e9472e54fdbe1d4cf8af1c89bc11e86', 'v2': 'e729ac9c7399ce6b1a3c7d13c46d145902e9a21687d970c87578517ca162bfb0'}}

try:
    if not (ROOT / "settings.gradle.kts").exists():
        raise RuntimeError("Run this patch from the Unciv repository root")
    current = {}
    changes = {}
    for name, hashes in EXPECTED.items():
        target = ROOT / BASE / name
        if not target.is_file():
            raise RuntimeError(f"Missing source file: {target}")
        raw = target.read_bytes()
        if MARK.encode() in raw:
            raise RuntimeError(f"Patch already applied: {name}")
        sha = hashlib.sha256(raw).hexdigest()
        if sha not in hashes.values():
            raise RuntimeError(f"Unsupported source version for {name}: {sha}; no changes made")
        current[name] = "v1" if sha == hashes["v1"] else "v2"
        changes[BASE / name] = (SRC / name).read_bytes()
    if len(set(current.values())) != 1:
        raise RuntimeError(f"Mixed v1/v2 input state: {current}; no changes made")
    ui = (ROOT / UI).read_text(encoding="utf-8")
    if MARK in ui:
        raise RuntimeError("Already applied in UI")
    ui_anchor = '                            add("통행국 국고 수입: $recipients".toLabel(hideIcons = true)).left().row()\n'
    ui_added = '                            // GS_MARITIME_PASSAGE_TRANSSHIPMENT_V2: real gold, not route indices.\n                            val landCash = it.cashTollPayments.sumOf { p -> p.landGold }\n                            val seaCash = it.cashTollPayments.sumOf { p -> p.seaGold }\n                            val harborCash = it.cashTollPayments.sumOf { p -> p.harborGold }\n                            if (landCash + seaCash + harborCash > 0)\n                                add("실제 요금 구분: 육상 통행 ${landCash}G · 해상 통항 ${seaCash}G · 항구 환적 ${harborCash}G".toLabel(hideIcons = true)).left().row()\n'
    if current["WorldMarketCashTolls.kt"] == "v1":
        if ui.count(ui_anchor) != 1 or "GS_MARITIME_PASSAGE_TRANSSHIPMENT_V2" in ui:
            raise RuntimeError("Unexpected v1 UI; patch stopped without modifications")
        ui = ui.replace(ui_anchor, ui_anchor + ui_added, 1)
        changes[UI] = ui.encode("utf-8")
    else:
        if ui.count('val landCash = it.cashTollPayments.sumOf { p -> p.landGold }') != 1:
            raise RuntimeError("v2 UI breakdown is missing; patch stopped")
    # All validation done before any file changes.
    for relative, content in changes.items():
        (ROOT / relative).write_bytes(content)
        print("modified", relative)
    print("Maritime v3 rates applied: standard land/sea transit 2G, foreign harbor 4G; friend land 1G")
    print("Next: git diff --check && ./gradlew :android:assembleDebug --no-daemon")
except Exception as exc:
    sys.exit(f"PATCH STOPPED: {exc}")
